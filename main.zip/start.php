<?php
/**
 * 启动器 · 零扩展版（自动选择可用的启动方式）
 *
 * 用法：  php start.php            （默认 20056~20059 里自动挑一个）
 *        php start.php 9000       （指定其他端口）
 *
 * 关键：不会用 php -S。
 *   PocketMine-MP 的定制 PHP 带 pmmphthread，它拒绝 cli-server SAPI，
 *   一用 php -S 就 Fatal（还会把 MC 服务端一起带崩）。
 *   所以这里统一改成纯 PHP 常驻服务（stream_socket_server），
 *   SAPI 保持 cli，pmmphthread 不会拦。
 */

declare(strict_types=1);

$port = '';
if (!empty($argv[1]) && ctype_digit((string)$argv[1])) {
    $port = (string)$argv[1];
}

/* ---------------- 环境自检 ---------------- */
$problems = [];

foreach ([
    'json_encode'          => 'JSON（PHP 8 内置）',
    'json_decode'          => 'JSON（PHP 8 内置）',
    'file_get_contents'    => '文件读取',
    'file_put_contents'    => '文件写入',
    'flock'                => '文件锁',
    'random_bytes'         => '随机数',
    'stream_socket_server' => 'TCP 监听（本项目的服务方式）',
    'stream_select'        => '多路复用',
] as $fn => $desc) {
    if (!function_exists($fn)) $problems[] = "缺少函数 {$fn}（{$desc}）";
}

if (!function_exists('hash') || !in_array('sha256', hash_algos(), true)) {
    $problems[] = '缺少 sha256';
}
if (PHP_VERSION_ID < 70400) {
    $problems[] = 'PHP 版本过低：' . PHP_VERSION . '（需要 7.4+）';
}

$dataDir = getenv('PHYS_DATA_DIR') ?: (__DIR__ . '/data');
if (!is_dir($dataDir)) @mkdir($dataDir, 0777, true);
if (!is_dir($dataDir) || !is_writable($dataDir)) {
    $problems[] = "数据目录不可写：{$dataDir}";
}

if ($problems) {
    fwrite(STDERR, "启动失败，环境检查未通过：\n");
    foreach ($problems as $p) fwrite(STDERR, "  ✗ {$p}\n");
    exit(1);
}

/* ---------------- 交给常驻服务 ---------------- */
$server = __DIR__ . '/server.php';
fwrite(STDOUT, "使用纯 PHP 常驻服务启动（不使用 php -S，避开 pmmphthread 限制）\n");

$cmd = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($server) . ' ' . escapeshellarg($port);
passthru($cmd, $code);
exit($code);
