<?php
/**
 * 物理练习系统 · 纯 PHP 常驻服务（不依赖 php -S）
 * ==================================================================
 * 为什么不用 php -S：
 *   PocketMine-MP 自带的 PHP 装了 pmmphthread（多线程扩展），
 *   它只允许 cli / pthreads 两种 SAPI，遇到 cli-server 会直接 Fatal。
 *   所以这里用 stream_socket_server 自己监听端口，
 *   SAPI 始终是 cli，pmmphthread 不会拦。
 *
 * 用法：  php server.php            默认 20056（被占用自动试 20057~20059）
 *        php server.php 9000       指定端口
 *
 * 只用 PHP 内置能力：stream_socket_* / json / flock。零扩展。
 *
 * 两类响应：
 *   1) 普通请求  —— handle_http() 一次性拼出完整响应字符串，塞进 $c['out'] 慢慢发
 * ==================================================================
 */

declare(strict_types=1);

// 大文件上传需要更大内存与更长执行时间（需求：单文件最大 1GB）
@ini_set('memory_limit', '3072M');
@ini_set('max_execution_time', '0');
@set_time_limit(0);

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "请在命令行下运行：php server.php [端口]\n");
    exit(1);
}

/* ------------------------------------------------------------------ *
 *  参数
 * ------------------------------------------------------------------ */
/* 端口：指定了就用指定的；没指定就在 20056~20059 里挑一个能用的。
   这几个端口是预留区间，连号的好处是起不来时能自动往后挪，
   不用人工改配置。 */
const PORT_RANGE = [20056, 20057, 20058, 20059];

$port = 0;
if (!empty($argv[1]) && ctype_digit((string)$argv[1])) {
    $port = (int)$argv[1];                       // 显式指定，失败就报错
} else {
    // 非交互环境（systemd/docker/nohup）不要等输入，直接自动挑
    $interactive = function_exists('posix_isatty') ? @posix_isatty(STDIN) : false;
    if ($interactive) {
        fwrite(STDOUT, '请输入端口（直接回车自动选 20056~20059）：');
        $line = trim((string)fgets(STDIN));
        if ($line !== '' && ctype_digit($line)) $port = (int)$line;
    }
}

$host = getenv('PHYS_BIND') ?: '0.0.0.0';

/* ------------------------------------------------------------------ *
 *  加载业务代码
 * ------------------------------------------------------------------ */
require __DIR__ . '/app/protocol.php';
require __DIR__ . '/app/store.php';
require __DIR__ . '/app/curriculum.php';
require __DIR__ . '/app/engine.php';
require __DIR__ . '/app/leaderboard.php';
require __DIR__ . '/app/chat.php';
require __DIR__ . '/app/features.php';
// 传输加密已移除（crypto.php 保留但不再加载）
require __DIR__ . '/app/render.php';
require __DIR__ . '/app/views.php';
require __DIR__ . '/app/views2.php';

/* ------------------------------------------------------------------ *
 *  监听
 * ------------------------------------------------------------------ */
$ctx = stream_context_create(['socket' => ['so_reuseaddr' => true, 'backlog' => 128]]);

/* 逐个尝试候选端口。
   $port > 0 表示用户指定了端口，那就只试它一个。 */
$candidates = ($port > 0) ? [$port] : PORT_RANGE;

$srv = false; $errno = 0; $errstr = '';
foreach ($candidates as $try) {
    $addr = "tcp://{$host}:{$try}";
    $srv  = @stream_socket_server($addr, $errno, $errstr, STREAM_SERVER_BIND | STREAM_SERVER_LISTEN, $ctx);
    if ($srv !== false) { $port = $try; break; }
    fwrite(STDERR, "端口 {$try} 不可用：{$errstr} ({$errno})\n");
}

if ($srv === false) {
    fwrite(STDERR, "\n这几个端口都起不来：" . implode(', ', $candidates) . "\n");
    fwrite(STDERR, "可能是被占用或没权限。换一个：php server.php 其他端口\n");
    exit(1);
}
$addr = "tcp://{$host}:{$port}";
stream_set_blocking($srv, false);

$dataDir = data_dir();
@mkdir($dataDir, 0777, true);

fwrite(STDOUT, "\n");
fwrite(STDOUT, "========================================\n");
fwrite(STDOUT, "  学科练习 · 纯 PHP 常驻服务\n");
fwrite(STDOUT, "  PHP " . PHP_VERSION . "（SAPI: " . PHP_SAPI . "，无需任何扩展）\n");
fwrite(STDOUT, "  数据目录: {$dataDir}\n");
fwrite(STDOUT, "----------------------------------------\n");
fwrite(STDOUT, "  本机：   http://127.0.0.1:{$port}/\n");
fwrite(STDOUT, "========================================\n\n");
fwrite(STDOUT, "按 Ctrl+C 停止\n\n");

/* ------------------------------------------------------------------ *
 *  常量
 * ------------------------------------------------------------------ */
/** 单个连接最多处理这么多请求后关闭，避免长连接占资源 */
const MAX_KEEPALIVE = 100;
const IDLE_TIMEOUT  = 30;      // 秒：普通请求的空闲上限
/**
 * 正在流式发送大文件（音乐）的连接用的空闲上限。
 * 27MB 音频在 5Mbps 上行要 45 秒以上，30 秒会把传到一半的连接掐掉。
 */
const STREAM_TIMEOUT = 300;    // 秒
const MAX_HEAD      = 65536;   // 请求头上限
/**
 * 请求体上限。
 * 云盘上传走 base64，1GB 文件编码后约 1.37GB，再加上加密包头，
 * 所以这里必须放大到 32MB，否则会被 413 挡掉。
 */
const MAX_BODY      = 1717986918; // 1.6GB：容得下 1GB 文件经 base64(×1.37) + 加密后的体积

/** 下载连接空闲超时（秒）：客户端长时间不收就断开，防止僵尸连接堆积 */
$connSeq = 0;

/** 静态资源白名单 */
function serve_static(string $path): ?array
{
    $map = [
        '/client.js' => [__DIR__ . '/public/client.js', 'application/javascript; charset=utf-8'],
        '/bg.js'     => [__DIR__ . '/public/bg.js',     'application/javascript; charset=utf-8'],
        '/music.js'  => [__DIR__ . '/public/music.js',  'application/javascript; charset=utf-8'],
        '/trend.js'  => [__DIR__ . '/public/trend.js',  'application/javascript; charset=utf-8'],
    ];
    if (!isset($map[$path])) return null;
    [$file, $type] = $map[$path];
    if (!is_file($file)) return null;
    return [
        'status' => 200,
        'type'   => $type,
        'body'   => (string)file_get_contents($file),
        // 用文件修改时间做版本号，客户端强刷一次后就一直是新的
        'etag'   => '"' . md5((string)@filemtime($file) . '|' . filesize($file)) . '"',
    ];
}

/** 组装 HTTP 响应 */
function http_response(int $status, string $type, string $body, array $extra = []): string
{
    $reason = [200 => 'OK', 204 => 'No Content', 400 => 'Bad Request',
               404 => 'Not Found', 405 => 'Method Not Allowed',
               413 => 'Payload Too Large', 500 => 'Internal Server Error',
               503 => 'Service Unavailable'][$status] ?? 'OK';
    $head = "HTTP/1.1 {$status} {$reason}\r\n";
    $head .= "Content-Type: {$type}\r\n";
    $head .= 'Content-Length: ' . strlen($body) . "\r\n";
    $head .= "Cache-Control: no-store\r\n";
    $head .= "Connection: keep-alive\r\n";
    foreach ($extra as $k => $v) $head .= "{$k}: {$v}\r\n";
    $head .= "\r\n";
    return $head . $body;
}

/**
 * 把 accept 得到的对端地址规范化成纯 IP。
 *   "tcp://1.2.3.4:54321"  → "1.2.3.4"
 *   "tcp://[::1]:54321"    → "127.0.0.1"
 *   "tcp://::ffff:1.2.3.4:5" → "1.2.3.4"
 */
function normalize_peer(string $peer): string
{
    $p = preg_replace('#^tcp://#', '', trim($peer));
    if ($p === '') return '0.0.0.0';

    // [IPv6]:port
    if ($p[0] === '[') {
        $end = strpos($p, ']');
        if ($end !== false) $p = substr($p, 1, $end - 1);
    } elseif (substr_count($p, ':') === 1) {
        // IPv4:port
        $p = explode(':', $p)[0];
    } elseif (substr_count($p, ':') > 1) {
        // 纯 IPv6（无端口），原样保留
    }

    // ::ffff:1.2.3.4 → 1.2.3.4
    if (stripos($p, '::ffff:') === 0) $p = substr($p, 7);

    // 本机各种写法统一
    if ($p === '::1' || $p === 'localhost') $p = '127.0.0.1';

    return $p;
}

/** 请求来源 IP */
function client_ip(array $meta): string
{
    foreach (['x-forwarded-for', 'x-real-ip'] as $h) {
        if (!empty($meta[$h])) {
            $v = trim(explode(',', (string)$meta[$h])[0]);
            if ($v !== '') return normalize_peer($v);
        }
    }
    return normalize_peer((string)($meta['__peer'] ?? '0.0.0.0'));
}


/* ------------------------------------------------------------------ *
 *  文件流式发送（支持 HTTP Range，不占内存）
 * ------------------------------------------------------------------ *
 *  为什么不用 handle_http() 返回字符串？
 *  那样要把整个文件读进内存再拼成一个大字符串 —— 27MB 音频
 *  会让内存翻倍，而且没法边下边播。
 *
 *  所以文件走这条独立通道：状态挂在 $c['serve'] 上，
 *  每轮事件循环发一小块，发完就关。
 * ------------------------------------------------------------------ */

/** 单块大小：64KB。太大会让其他连接等待，太小会碎 */
const SRV_CHUNK = 65536;

/**
 * 为一个连接准备文件发送。
 *
 * @param array  $c        连接（会被修改，写入 $c['serve']）
 * @param string $path     文件绝对路径
 * @param string $mime     Content-Type
 * @param array  $reqHdrs  请求头（用来解析 Range）
 * @param bool   $download 是否强制下载（加 Content-Disposition）
 * @return string|null     null=已接管；字符串=错误响应
 */
function serve_begin(array &$c, string $path, string $mime, array $reqHdrs = [], bool $download = false): ?string
{
    $size = @filesize($path);
    if ($size === false || $size <= 0) {
        return http_response(404, 'text/plain; charset=utf-8', '404');
    }

    $start = 0;
    $end   = $size - 1;
    $code  = 200;

    // ---- 解析 Range: bytes=start-end ----
    $range = (string)($reqHdrs['range'] ?? '');
    if ($range !== '' && preg_match('/bytes=(\d*)-(\d*)/', $range, $m)) {
        $a = $m[1] === '' ? null : (int)$m[1];
        $b = $m[2] === '' ? null : (int)$m[2];
        if ($a === null && $b !== null) {
            // bytes=-N  最后 N 字节
            $start = max(0, $size - $b);
            $end   = $size - 1;
        } else {
            $start = $a === null ? 0 : $a;
            $end   = $b === null ? $size - 1 : min($b, $size - 1);
        }
        if ($start > $end || $start >= $size) {
            return "HTTP/1.1 416 Range Not Satisfiable\r\n" .
                   "Content-Range: bytes */{$size}\r\n" .
                   "Content-Length: 0\r\nConnection: close\r\n\r\n";
        }
        $code = 206;
    }

    $len = $end - $start + 1;

    $fp = @fopen($path, 'rb');
    if ($fp === false) return http_response(404, 'text/plain; charset=utf-8', '404');
    if ($start > 0) @fseek($fp, $start);

    $head  = "HTTP/1.1 {$code} " . ($code === 206 ? 'Partial Content' : 'OK') . "\r\n";
    $head .= "Content-Type: {$mime}\r\n";
    $head .= "Content-Length: {$len}\r\n";
    $head .= "Accept-Ranges: bytes\r\n";
    if ($code === 206) $head .= "Content-Range: bytes {$start}-{$end}/{$size}\r\n";
    if ($download) {
        $head .= 'Content-Disposition: attachment; filename="' . rawurlencode(basename($path)) . '"\r\n';
    }
    $head .= "Cache-Control: no-store\r\n";
    $head .= "Connection: keep-alive\r\n";
    $head .= "\r\n";

    $c['serve'] = [
        'fp'      => $fp,
        'head'    => $head,
        'carry'   => '',
        'sent'    => 0,
        'len'     => $len,
        'active'  => true,
    ];
    $c['out'] = '';
    $c['buf'] = '';

    return null;
}

/**
 * 推进一个文件发送连接：能发就发。
 *
 * $write 是 stream_select 给出的「可写」集合。
 * 传 null 表示「默认可写」（首次发送响应头时用）。
 *
 * 注意：这里刻意【不用】按引用传参。
 * 之前写成 `?array &$write`，调用方顺手写 serve_pump($c, null, 2)
 * 就会 Fatal：Argument #2 ($write) could not be passed by reference。
 * 一个 null 字面量不该能把整个服务打挂，所以改成传值。
 */
function serve_pump(array &$c, ?array $write = null, int $budget = 2): void
{
    if (empty($c['serve']) || empty($c['serve']['active'])) return;
    $d = &$c['serve'];

    if (!is_resource($c['sock'])) { serve_close($c, false); return; }
    if ($write !== null && !in_array($c['sock'], $write, true)) return;

    for ($i = 0; $i < $budget; $i++) {
        // 1) 先发响应头
        if ($d['head'] !== '') {
            $n = @fwrite($c['sock'], $d['head']);
            if ($n === false) { serve_close($c, false); return; }
            if ($n <= 0) return;
            $d['head'] = substr($d['head'], $n);
            if ($d['head'] !== '') return;
        }

        // 2) 发够了
        if ($d['sent'] >= $d['len']) { serve_close($c, true); return; }

        // 3) 读一块
        if ($d['carry'] === '') {
            $want = min(SRV_CHUNK, $d['len'] - $d['sent']);
            $chunk = @fread($d['fp'], $want);
            if ($chunk === false) { serve_close($c, false); return; }
            if ($chunk === '') {
                if (feof($d['fp'])) { serve_close($c, true); return; }
                return;
            }
            $d['carry'] = $chunk;
        }

        // 4) 写出去
        $n = @fwrite($c['sock'], $d['carry']);
        if ($n === false) { serve_close($c, false); return; }
        if ($n <= 0) return;
        $d['carry'] = substr($d['carry'], $n);
        $d['sent'] += $n;

        if ($d['carry'] !== '') return;   // 对端拥塞，让出 CPU
    }
}

/** 结束发送。注意：绝不在这里直接 fclose(socket)，只做标记 */
function serve_close(array &$c, bool $ok): void
{
    if (!empty($c['serve']['fp'])) @fclose($c['serve']['fp']);
    $c['serve'] = null;
    if ($ok) {
        $c['deadline'] = time() + IDLE_TIMEOUT;
        $c['close'] = false;
    } else {
        $c['close'] = true;
    }
}

/**
 * 处理一个完整请求，返回响应字符串。
 * 业务协议：请求体是 LBSP 二进制动作；没有动作时合成首页。
 *
 */
function handle_http(string $method, string $target, array $headers, string $body, string $peer): string
{
    $path = parse_url($target, PHP_URL_PATH) ?: '/';

    // 静态资源（带版本号，避免浏览器拿到旧的 client.js 导致行为异常）
    $st = serve_static($path);
    if ($st) {
        $extra = ['Cache-Control' => 'no-cache'];
        if (!empty($st['etag'])) $extra['ETag'] = $st['etag'];
        return http_response($st['status'], $st['type'], $st['body'], $extra);
    }

    // ---- /music：音乐文件 ----
    //   探针（不带 play=1）：返回 JSON，告诉客户端有没有歌、多大、什么格式。
    //   带 play=1：不缓冲，交给 serve_begin() 流式发送（支持 Range，边下边播）。
    //   27MB 的 flac 走这条路，内存里永远只有 64KB。
    if ($path === '/music') {
        $dir  = __DIR__ . '/data';
        $flac = $dir . '/music.flac';
        $mp3  = $dir . '/music.mp3';
        $file = null; $mime = '';
        if (is_file($flac))    { $file = $flac; $mime = 'audio/flac'; }
        elseif (is_file($mp3)) { $file = $mp3;  $mime = 'audio/mpeg'; }

        if (strpos($target, 'play=1') === false) {
            $info = [$file === null ? 0 : 1, $file === null ? 0 : (int)@filesize($file), $mime];
            return http_response(200, 'application/json; charset=utf-8', json_encode($info));
        }
        if ($file === null) {
            return http_response(404, 'text/plain; charset=utf-8', '404');
        }
        // 特殊标记：主循环看到就用 serve_begin() 接管这个连接
        return "\x00STREAM\x00" . $file . "\x00" . $mime;
    }

    // 只接受 GET / POST
    if ($method !== 'GET' && $method !== 'POST') {
        return http_response(405, 'text/plain; charset=utf-8', '405 Method Not Allowed');
    }

    $headers['__peer'] = $peer;
    $ip = client_ip($headers);

    try {
        if ($method === 'POST' && $body !== '') {
            // 不加密：请求体就是 LBSP 动作数据，直接解析
            $req = parse_request_body($body, $ip);
        } else {
            // 首帧：合成首页
            $req = new Request(0x03, $ip, '', ['a' => 'view', 't' => ''], '');
        }

        $res = handle_request($req);

        // ---- 文件下载（导出成绩）：直接返回附件，不渲染页面 ----
        if (!empty($res->download)) {
            $d = $res->download;
            $body = (string)($d['body'] ?? '');
            $name = (string)($d['name'] ?? 'export.txt');
            $type = (string)($d['type'] ?? 'application/octet-stream');
            // 文件名可能含中文，用 RFC 5987 的 filename* 让浏览器正确识别
            $ascii = preg_replace('/[^ -~]/', '_', $name);
            $extra = [
                'Content-Disposition' => 'attachment; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($name),
            ];
            return http_response(200, $type, $body, $extra);
        }

        $extra = [];
        if ($res->token !== null) $extra['X-Phys-Token'] = $res->token;

        // ---- 响应一律返回明文 HTML ----
        //
        // 加密只用于【客户端上传的数据】（见解析请求那一步），
        // 响应不加密：浏览器要直接渲染 HTML，返回二进制会被当成文件下载。
        return http_response(200, 'text/html; charset=utf-8', $res->body, $extra);
    } catch (Throwable $e) {
        return http_response(500, 'text/plain; charset=utf-8',
            "500 Internal Server Error\n" . $e->getMessage());
    }
}

/* ------------------------------------------------------------------ *
 *  主循环
 * ------------------------------------------------------------------ */
$clients = [];                 // id => ['sock','buf','out','deadline','peer','served','close']

while (true) {

    $read  = [$srv];
    $write = [];
    foreach ($clients as $id => $c) {
        // 已标记关闭 / 句柄失效的连接：立刻清理，绝不塞进 select。
        // 把已关闭的 stream 传给 stream_select 会抛 ValueError 让进程退出。
        if (!empty($c['close']) || !is_resource($c['sock'])) {
            if (is_resource($c['sock'])) @fclose($c['sock']);
            unset($clients[$id]);
            continue;
        }
        // 正在发文件的连接：只关心"可写"，不关心"可读"。
        // 把它放进 read 集合会让 select 每次都立刻返回，
        // 白白空转 CPU（还会顺手把没用的字节读进来）。
        if (!empty($c['serve']['active'])) {
            $write[] = $c['sock'];
            continue;
        }
        $read[] = $c['sock'];
        if ($c['out'] !== '') $write[] = $c['sock'];
    }
    if (!$read && !$write) { usleep(20000); continue; }

    $except = null;
    // 超时用 20ms 而不是 1s：
    //   限速节奏是 40ms 一块，1 秒一轮的话一次会憋出 25 块，速率就不准了。
    //   20ms 的轮询间隔让限速既平滑又不烧 CPU（每轮几乎什么都不做）。
    $n = @stream_select($read, $write, $except, 0, 20000);
    if ($n === false) continue;

    // ---- 新连接 ----
    foreach ($read as $r) {
        if ($r === $srv) {
            $conn = @stream_socket_accept($srv, 0, $peerName);
            if ($conn !== false) {
                stream_set_blocking($conn, false);
                $id = ++$connSeq;
                $clients[$id] = [
                    'sock'     => $conn,
                    'buf'      => '',
                    'out'      => '',
                    'deadline' => time() + IDLE_TIMEOUT,
                    'peer'     => normalize_peer((string)$peerName),
                    'served'   => 0,
                    'close'    => false,
                    'serve'    => null,
                ];
            }
        }
    }

    // ---- 读（发送文件中的连接不读，避免 keep-alive 的残留字节干扰）----
    foreach ($clients as $id => &$c) {
        if (!is_resource($c['sock'])) { unset($clients[$id]); continue; }
        // 这个连接正在发大文件，本次响应还没结束：
        // 这时候读到的任何东西都可能是浏览器提前发的下一个请求，
        // 留在 buf 里会污染后面的解析，所以直接跳过。
        if (!empty($c['serve']['active'])) continue;
        if (!in_array($c['sock'], $read, true)) continue;

        $chunk = @fread($c['sock'], 65536);
        if ($chunk === false || ($chunk === '' && feof($c['sock']))) {
            unset($clients[$id]);
            continue;
        }
        if ($chunk === '') continue;

        $c['buf'] .= $chunk;

        // 完整请求就处理（只处理第一个，剩下留给下一轮，天然支持 pipelining）
        $pos = strpos($c['buf'], "\r\n\r\n");
        if ($pos === false) {
            if (strlen($c['buf']) > MAX_HEAD) {
                $c['out'] .= http_response(413, 'text/plain', 'Request header too large');
                $c['buf'] = '';
            }
            continue;
        }

        $headRaw = substr($c['buf'], 0, $pos);
        $lines = explode("\r\n", $headRaw);
        $reqLine = array_shift($lines) ?? '';
        $parts = explode(' ', $reqLine);
        $method = strtoupper($parts[0] ?? 'GET');
        $target = $parts[1] ?? '/';

        $headers = [];
        foreach ($lines as $l) {
            $ci = strpos($l, ':');
            if ($ci > 0) $headers[strtolower(substr($l, 0, $ci))] = trim(substr($l, $ci + 1));
        }
        $len = (int)($headers['content-length'] ?? 0);
        if ($len > MAX_BODY) {
            $c['out'] .= http_response(413, 'text/plain', 'Body too large');
            $c['buf'] = '';
            continue;
        }

        $avail = strlen($c['buf']) - ($pos + 4);
        if ($avail < $len) continue;                     // 等 body 到齐

        $body = substr($c['buf'], $pos + 4, $len);
        $c['buf'] = substr($c['buf'], $pos + 4 + $len);

        $resp = handle_http($method, $target, $headers, $body, $c['peer']);

        // 需要流式发送的文件（如音乐）：交给 serve_begin 接管这个连接
        if (strncmp($resp, "\x00STREAM\x00", 8) === 0) {
            $parts = explode("\x00", substr($resp, 8));
            $fpath = $parts[0] ?? '';
            $fmime = $parts[1] ?? 'application/octet-stream';
            $err = serve_begin($c, $fpath, $fmime, $headers, false);
            if ($err !== null) {
                $c['out'] .= $err;
            } else {
                serve_pump($c, null, 2);   // 头一块立刻发
            }
            continue;
        }

        $c['out'] .= $resp;
        $c['served']++;
        if ($c['served'] >= MAX_KEEPALIVE) {
            // 主动收尾
            $c['buf'] = '';
        }
    }
    unset($c);

    // ---- 写 ----
    foreach ($clients as $id => &$c) {

        // 文件流式发送中
        if (!empty($c['serve']['active'])) {
            serve_pump($c, $write, 2);
            if (!empty($c['close'])) {
                if (is_resource($c['sock'])) @fclose($c['sock']);
                unset($clients[$id]);
            }
            continue;
        }

        if (!empty($c['close'])) {
            if (is_resource($c['sock'])) @fclose($c['sock']);
            unset($clients[$id]);
            continue;
        }
        if ($c['out'] === '') continue;
        if (!is_resource($c['sock'])) { unset($clients[$id]); continue; }
        if (!in_array($c['sock'], $write, true)) continue;   // 不可写，等下一轮

        $written = @fwrite($c['sock'], $c['out']);
        if ($written === false) {
            if (is_resource($c['sock'])) @fclose($c['sock']);
            unset($clients[$id]);
            continue;
        }
        if ($written > 0) {
            $c['out'] = substr($c['out'], $written);
            $c['deadline'] = time() + IDLE_TIMEOUT;
        }
    }
    unset($c);

    // ---- 清理超时连接 ----
    $now = time();
    foreach ($clients as $id => $c) {
        // 正在发文件的连接用更宽的超时：
        // 27MB 音频在 5Mbps 上要 45 秒以上，用 30 秒的常规超时
        // 会把传到一半的连接杀掉（手机端表现就是音乐放一半断了）。
        $busyStream = !empty($c['serve']['active']);
        $idleLimit  = $busyStream ? STREAM_TIMEOUT : IDLE_TIMEOUT;

        if ($c['deadline'] + $idleLimit < $now && $c['out'] === '' && !$busyStream) {
            if (!empty($c['serve']['fp'])) @fclose($c['serve']['fp']);
            if (is_resource($c['sock'])) @fclose($c['sock']);
            unset($clients[$id]);
        }
    }
}
