/* ==================================================================
 * 背景音乐（不可暂停）
 * ==================================================================
 * 音乐文件：data/music.flac  →  没有就找 data/music.mp3
 * 通过 /music 端点请求，服务端流式发送（支持 Range，边下边播）。
 *
 * ── 为什么这个文件长这样 ──────────────────────────────────────
 * 本站每次操作都是服务端整页重绘，客户端用 mount() 把
 * document.body.innerHTML 整个换掉。这带来两个坑：
 *
 *   1) 每次切页 <script src="/music.js"> 都会被重新执行一遍。
 *      如果脚本里直接 new Audio()，就会不断新建音频对象，
 *      旧的那个没人管又还在播 —— 越切页声音越乱。
 *      → 所以整个模块挂在 window.__Music 上做单例：
 *        第二次执行时只重新绑定按钮，绝不重建 audio。
 *
 *   2) innerHTML 一换，按钮元素变成新节点，
 *      事件监听器随旧节点一起消失。
 *      → 所以每次 mount 后重新 bindButton()。
 *
 * ── 关于暂停 ──────────────────────────────────────────────────
 * 按需求，音乐一经播放就不再提供暂停入口：
 * 按钮只显示状态（点了也只是重新尝试播放），避免出现
 * “暂停后切页又自动续播 / 状态和实际不一致”这类 Bug。
 * ================================================================== */
(function () {
  'use strict';

  /* 单例：脚本被重复执行时直接复用上一次的实例 */
  if (window.__Music && window.__Music.__singleton) {
    window.__Music.boot();
    return;
  }

  var S = {
    __singleton: true,
    ready: false,     // 探测过服务端没有
    has: false,       // 服务端有音乐文件
    audio: null,
    ctxA: null,
    analyser: null,
    armed: false,     // 是否已装上“首次交互即播放”的解锁监听
    bound: null       // 当前已绑定的按钮（DOM 换掉后需要重绑）
  };

  function el(id) { return document.getElementById(id); }

  /* ---------- UI ---------- */

  function setUI(on) {
    var btn = el('musicbtn');
    if (!btn) return;
    btn.setAttribute('data-on', on ? '1' : '0');
    btn.setAttribute('aria-label', on ? '音乐播放中' : '点击播放音乐');
    btn.title = on ? '音乐播放中' : '点击播放音乐';
  }

  function show() {
    var box = el('musicbox');
    if (box) box.hidden = false;
    setUI(isOn());
  }

  function hide() {
    var box = el('musicbox');
    if (box) box.hidden = true;
  }

  function isOn() {
    return !!S.audio && !S.audio.paused && !S.audio.ended;
  }

  /* ---------- 音频 ---------- */

  /** 把音频接到 AnalyserNode，让背景跟着频谱动 */
  function initAudio() {
    if (S.ctxA || !S.audio) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      S.ctxA = new AC();
      var src = S.ctxA.createMediaElementSource(S.audio);
      S.analyser = S.ctxA.createAnalyser();
      S.analyser.fftSize = 256;              // 背景只要低频就够了，256 更省 CPU
      S.analyser.smoothingTimeConstant = 0.85;
      src.connect(S.analyser);
      S.analyser.connect(S.ctxA.destination);
      if (window.__BG && window.__BG.setAnalyser) window.__BG.setAnalyser(S.analyser);
    } catch (e) {
      console.warn('[音乐] 频谱分析不可用：', e);
    }
  }

  function tryPlay() {
    if (!S.audio || !S.has) return;
    initAudio();
    if (S.ctxA && S.ctxA.state === 'suspended') {
      try { S.ctxA.resume(); } catch (e) {}
    }
    var p = S.audio.play();
    if (p && p.catch) {
      p.then(function () { setUI(true); }).catch(function () { setUI(false); });
    }
  }

  /**
   * 浏览器不允许带声音自动播放。
   * 这里不做“检测到被拦就弹提示”的复杂逻辑，
   * 只在第一次任意点击/触摸时补一次播放，之后自动注销。
   */
  function armUnlock() {
    if (S.armed) return;
    S.armed = true;
    var once = function () {
      document.removeEventListener('pointerdown', once, true);
      document.removeEventListener('touchstart', once, true);
      document.removeEventListener('keydown', once, true);
      tryPlay();
    };
    document.addEventListener('pointerdown', once, true);
    document.addEventListener('touchstart', once, true);
    document.addEventListener('keydown', once, true);
  }

  /* ---------- 启动 ---------- */

  function probe() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/music', true);
    xhr.responseType = 'text';
    xhr.onload = function () {
      if (xhr.status !== 200) { hide(); return; }
      var info = null;
      try { info = JSON.parse(xhr.responseText); } catch (e) { info = null; }
      if (!info || !info[0]) { S.has = false; hide(); return; }

      S.has = true;

      // 单例：音频对象只创建一次，之后所有页面共用同一个
      if (!S.audio) {
        S.audio = new Audio();
        S.audio.src = '/music?play=1';
        S.audio.loop = true;
        S.audio.preload = 'auto';
        S.audio.setAttribute('playsinline', '');
        // 播放/暂停状态变化时刷新按钮（不用轮询）
        S.audio.addEventListener('playing', function () { setUI(true); });
        S.audio.addEventListener('pause', function () {
          // 不允许暂停：如果不是我们主动停的（比如页面隐藏导致的中断），
          // 立刻续上，避免“切页回来音乐没了”
          if (!document.hidden) setTimeout(function () {
            if (S.audio && S.audio.paused) tryPlay();
          }, 200);
        });
        S.audio.addEventListener('error', function () { setUI(false); });
      }

      show();
      tryPlay();
      armUnlock();
    };
    xhr.onerror = function () { hide(); };
    xhr.send();
  }

  /** 绑定按钮（DOM 每次整页重绘后都要重绑一次） */
  function bindButton() {
    var btn = el('musicbtn');
    if (!btn || btn === S.bound) return;   // 同一个节点不重复绑定
    S.bound = btn;
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      // 不提供暂停：点了只是确认/恢复播放
      tryPlay();
    });
  }

  /** 每次页面挂载后调用 */
  function boot() {
    bindButton();
    if (S.has && S.audio) {
      show();
      if (S.audio.paused && !document.hidden) tryPlay();
      return;
    }
    if (!S.ready) { S.ready = true; probe(); }
  }

  // 从后台切回来 / 页面进入缓存再恢复时，补一次播放
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && S.audio && S.audio.paused) tryPlay();
  });
  window.addEventListener('pageshow', function () {
    if (S.audio && S.audio.paused) tryPlay();
  });

  window.__Music = {
    __singleton: true,
    boot: boot,
    play: tryPlay,
    // 保留 pause 名称但故意不提供暂停能力，防止旧代码误调用
    pause: function () { tryPlay(); }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
