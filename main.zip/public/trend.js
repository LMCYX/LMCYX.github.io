/* ==================================================================
 * 成绩趋势折线图（Canvas 2D，无第三方库）
 * ==================================================================
 * 数据在页面里：<script id="trenddata" type="application/json">[...]</script>
 *
 * 和 bg.js 一样，这个脚本会因为整页重绘被反复执行，
 * 所以要做单例保护：只保留一个 resize 监听，重复执行只重画。
 * ================================================================== */
(function () {
  'use strict';

  var lastCv = null;

  /** 把数值映射到画布坐标 */
  function draw() {
    var cv = document.getElementById('trendcv');
    if (!cv) return;
    lastCv = cv;

    var dataEl = document.getElementById('trenddata');
    if (!dataEl) return;

    var pts;
    try { pts = JSON.parse(dataEl.textContent || '[]'); } catch (e) { return; }
    if (!pts || pts.length < 2) return;

    // 高分屏适配：把逻辑尺寸乘上 DPR
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var cssW = cv.parentNode ? cv.parentNode.clientWidth : 640;
    if (!cssW || cssW < 60) cssW = 640;
    var cssH = Math.round(cssW * 0.36);
    if (cssH < 150) cssH = 150;
    if (cssH > 300) cssH = 300;

    cv.width = Math.floor(cssW * dpr);
    cv.height = Math.floor(cssH * dpr);
    cv.style.width = cssW + 'px';
    cv.style.height = cssH + 'px';

    var ctx = cv.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);

    var L = 34, R = 10, T = 14, B = 22;
    var W = cssW - L - R, H = cssH - T - B;

    // ---- 取值域 ----
    var maxS = 0, i;
    for (i = 0; i < pts.length; i++) maxS = Math.max(maxS, pts[i].s || 0);
    maxS = Math.max(10, Math.ceil(maxS / 10) * 10);   // 向上取整到 10

    var n = pts.length;
    function X(i) { return L + (n === 1 ? W / 2 : W * i / (n - 1)); }
    function Y(v) { return T + H - (H * v / maxS); }

    // ---- 网格 + Y 轴刻度 ----
    ctx.strokeStyle = 'rgba(255,255,255,.08)';
    ctx.fillStyle = 'rgba(152,164,192,.85)';
    ctx.font = '10px system-ui,-apple-system,sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.lineWidth = 1;

    for (i = 0; i <= 4; i++) {
      var v = maxS * i / 4;
      var y = Y(v);
      ctx.beginPath();
      ctx.moveTo(L, Math.round(y) + 0.5);
      ctx.lineTo(L + W, Math.round(y) + 0.5);
      ctx.stroke();
      ctx.fillText(String(Math.round(v)), L - 5, y);
    }

    // ---- 折线下方的渐变填充 ----
    var g = ctx.createLinearGradient(0, T, 0, T + H);
    g.addColorStop(0, 'rgba(77,124,254,.42)');
    g.addColorStop(1, 'rgba(77,124,254,0)');

    ctx.beginPath();
    ctx.moveTo(X(0), Y(pts[0].s || 0));
    for (i = 1; i < n; i++) ctx.lineTo(X(i), Y(pts[i].s || 0));
    ctx.lineTo(X(n - 1), T + H);
    ctx.lineTo(X(0), T + H);
    ctx.closePath();
    ctx.fillStyle = g;
    ctx.fill();

    // ---- 折线 ----
    ctx.beginPath();
    ctx.moveTo(X(0), Y(pts[0].s || 0));
    for (i = 1; i < n; i++) ctx.lineTo(X(i), Y(pts[i].s || 0));
    ctx.strokeStyle = '#6d94ff';
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();

    // ---- 数据点（点多的时候只画外圈，避免糊成一片）----
    var dotR = n > 18 ? 0 : (n > 10 ? 2 : 3);
    if (dotR > 0) {
      for (i = 0; i < n; i++) {
        var cx = X(i), cy = Y(pts[i].s || 0);
        ctx.beginPath();
        ctx.arc(cx, cy, dotR, 0, 6.2832);
        ctx.fillStyle = '#0f1526';
        ctx.fill();
        ctx.strokeStyle = '#6d94ff';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    }

    // ---- 最高点标注 ----
    var bi = 0;
    for (i = 1; i < n; i++) if ((pts[i].s || 0) > (pts[bi].s || 0)) bi = i;
    var bx = X(bi), by = Y(pts[bi].s || 0);
    ctx.fillStyle = 'rgba(232,237,249,.95)';
    ctx.font = 'bold 11px system-ui,-apple-system,sans-serif';
    ctx.textAlign = bx > L + W * 0.8 ? 'right' : 'left';
    ctx.textBaseline = 'bottom';
    ctx.fillText('最高 ' + (pts[bi].s || 0), bx + (bx > L + W * 0.8 ? -6 : 6), by - 5);

    // ---- X 轴：只标首尾 ----
    ctx.fillStyle = 'rgba(109,121,148,.9)';
    ctx.font = '10px system-ui,-apple-system,sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText('第 1 次', L, T + H + 5);
    ctx.textAlign = 'right';
    ctx.fillText('第 ' + n + ' 次', L + W, T + H + 5);
  }

  // 只装一次 resize 监听
  if (!window.__TrendBound) {
    window.__TrendBound = true;
    var rt = 0;
    window.addEventListener('resize', function () {
      if (rt) clearTimeout(rt);
      rt = setTimeout(draw, 150);
    });
  }

  window.__Trend = { draw: draw };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', draw);
  else draw();
})();
