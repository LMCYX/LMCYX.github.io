/* ==================================================================
 * 客户端驱动
 *
 * 与服务端通过一个端点通信，请求体是 LBSP 二进制字段，
 * 响应是服务端实时合成的整页 HTML，整体装载。
 *
 * 练习流程（对应需求 6）：
 *   页面上一次显示 10 题 → 逐题作答（本地记录每题耗时）
 *   → 点「提交全部」→ 一次性发送 10 题的答案和耗时 → 服务端结算
 *
 * 传输：请求与响应都是明文（不加密），减少 CPU 开销，也让大文件上传更稳。
 * ================================================================== */
(function () {
  'use strict';

  var S = window.__S || { token: '', label: '', k: '' };
  var token = S.token || '';
  var busy = false;

  /* ---------------- LBSP 编码 ---------------- */
  function lbs(pairs) {
    var parts = [];
    Object.keys(pairs).forEach(function (k) {
      var kb = new TextEncoder().encode(k);
      var vb = new TextEncoder().encode(String(pairs[k]));
      var head = new Uint8Array(2 + kb.length + 4);
      head[0] = kb.length & 255; head[1] = (kb.length >> 8) & 255;
      head.set(kb, 2);
      var o = 2 + kb.length, vl = vb.length;
      head[o] = vl & 255; head[o + 1] = (vl >> 8) & 255;
      head[o + 2] = (vl >> 16) & 255; head[o + 3] = (vl >> 24) & 255;
      parts.push(head, vb);
    });
    var n = parts.reduce(function (a, p) { return a + p.length; }, 0);
    var out = new Uint8Array(n), off = 0;
    parts.forEach(function (p) { out.set(p, off); off += p.length; });
    return out;
  }

  /* ---------------- 发送动作 ---------------- */
  var busyTimer = 0;

  function act(pairs, opts) {
    if (busy) return;
    busy = true;
    showBusy();

    // 兜底：无论发生什么，8 秒后一定解除忙碌状态，
    // 避免出现「点了没反应、之后再也点不动」。
    if (busyTimer) clearTimeout(busyTimer);
    busyTimer = setTimeout(function () {
      if (busy) { busy = false; hideBusy(); toast('请求超时，请重试'); }
    }, 8000);

    var data = lbs(pairs);
    var tb = new TextEncoder().encode(token);
    var body = new Uint8Array(2 + tb.length + data.length);
    body[0] = tb.length & 255; body[1] = (tb.length >> 8) & 255;
    body.set(tb, 2); body.set(data, 2 + tb.length);

    // 不加密：直接发明文（服务端也不再解密）
    var sendBody = body;

    // 期望的动作：用来判断服务端是否真的处理了这次请求
    var wantAct = pairs.a || '';
    var tried = (opts && opts.__retried) ? 1 : 0;

    var xhr = new XMLHttpRequest();
    xhr.open('POST', location.pathname || '/', true);
    xhr.responseType = 'text';                       // 响应是明文 HTML
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.onload = function () {
      busy = false;
      if (busyTimer) { clearTimeout(busyTimer); busyTimer = 0; }
      if (xhr.status >= 200 && xhr.status < 300) {
        var nt = xhr.getResponseHeader('X-Phys-Token');
        if (nt) token = nt;

        // ---- 动作丢失检测 ----
        // 服务端会把「本次渲染的是哪个动作」写进页面的 fp 指纹里。
        // 如果请求的是 start/board/chat，却收到了首页，说明
        // 请求体没被正确解析（网络截断 / 代理改写等）。
        // 这种情况自动重试一次，避免用户"点了没反应"。
        var gotHome = xhr.responseText.indexOf('选择单元开始练习') !== -1;
        var wantPage = (wantAct === 'start' || wantAct === 'submit' ||
                        wantAct === 'board' || wantAct === 'chat' ||
                        wantAct === 'chat_send');
        if (wantPage && gotHome && !tried) {
          console.warn('[重试] 请求 ' + wantAct + ' 却收到首页，自动重试一次');
          mount(xhr.responseText);          // 先让界面可用
          var retryOpts = {};
          for (var kk in (opts || {})) retryOpts[kk] = opts[kk];
          retryOpts.__retried = true;
          setTimeout(function () { act(pairs, retryOpts); }, 120);
          return;
        }

        mount(xhr.responseText);
      } else {
        hideBusy();
        toast('服务端错误 ' + xhr.status);
      }
    };
    xhr.onerror = function () {
      busy = false;
      if (busyTimer) { clearTimeout(busyTimer); busyTimer = 0; }
      hideBusy();
      toast('网络异常，请刷新重试');
    };
    xhr.send(sendBody);
  }

  /* ---------------- 导出下载 ----------------
   * 服务端返回的是带 Content-Disposition 的附件。
   * 这里用 fetch 取回来再手动造一个 <a download> 触发，
   * 比直接 location.href 好的地方是失败时能提示，而不是白屏。
   */
  function doExport(fmt) {
    showBusy('正在生成…');
    var bytes = lbs({ a: 'export', fmt: fmt, t: token });
    fetch('/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream' },
      body: bytes,
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      var cd = r.headers.get('Content-Disposition') || '';
      var name = '我的成绩.' + (fmt === 'json' ? 'json' : 'csv');
      var m = /filename\*=UTF-8''([^;]+)/i.exec(cd);
      if (m) { try { name = decodeURIComponent(m[1]); } catch (e) {} }
      return r.blob().then(function (b) {
        var url = URL.createObjectURL(b);
        var a = document.createElement('a');
        a.href = url;
        a.download = name;
        // 必须挂到文档里，某些浏览器对游离节点不触发下载
        document.body.appendChild(a);
        a.click();
        setTimeout(function () {
          if (a.parentNode) a.parentNode.removeChild(a);
          URL.revokeObjectURL(url);
        }, 1500);
        hideBusy();
        toast('已开始下载：' + name);
      });
    }).catch(function (e) {
      hideBusy();
      toast('导出失败：' + e.message);
    });
  }

  /* ---------------- 装载整页 ---------------- */
  function mount(html) {
    var doc = new DOMParser().parseFromString(html, 'text/html');
    if (!doc || !doc.body) { toast('页面装载失败'); hideBusy(); return; }

    var scripts = Array.prototype.slice.call(doc.querySelectorAll('script'));

    document.body.className = doc.body.className;
    document.body.innerHTML = doc.body.innerHTML;
    document.title = doc.title || document.title;

    var st = document.getElementById('state');
    if (st) {
      try { S = JSON.parse(st.textContent); window.__S = S; } catch (e) { /* 保留旧值 */ }
      if (S.token) token = S.token;
    }

    injectScripts(scripts);
    bindAll();
    applySlide();
    enforceNick();
    revivePageModules();
    dismissBoot();
    hideBusy();
  }

  /**
   * 左右滑动动画。
   * 用一个简单的层级判断方向：从首页往深处走 = 右滑入，
   * 点「返回」= 左滑入。用 sessionStorage 记住上一次的页面层级。
   */
  function applySlide() {
    var root = document.getElementById('root');
    if (!root) return;
    var cur = pageDepth();
    var prev = 0;
    try { prev = parseInt(sessionStorage.getItem('phys_depth') || '0', 10) || 0; } catch (e) {}
    root.classList.remove('slide-l', 'slide-r');
    // 强制重排，让动画能重放
    void root.offsetWidth;
    if (cur >= prev) root.classList.add('slide-r');
    else root.classList.add('slide-l');
    try { sessionStorage.setItem('phys_depth', String(cur)); } catch (e) {}
  }

  /** 页面层级：首页 0，其余 1 */
  function pageDepth() {
    if (document.querySelector('.subjnav')) return 0;     // 首页
    return 1;
  }

  function injectScripts(scripts) {
    scripts.forEach(function (old) {
      if (old.id === 'state') return;
      if (old.src) {
        var src = old.getAttribute('src');
        if (document.querySelector('script[data-loaded="' + src + '"]')) return;
        var s = document.createElement('script');
        s.src = src; s.async = false;
        s.setAttribute('data-loaded', src);
        document.body.appendChild(s);
      } else {
        var inline = document.createElement('script');
        inline.textContent = old.textContent;
        document.body.appendChild(inline);
      }
    });
  }

  function dismissBoot() {
    var b = document.getElementById('boot');
    if (!b) return;
    b.classList.add('hide');
    setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 320);
  }

  /* ================================================================
   *  答题逻辑（一次 10 题）
   * ================================================================ */
  var answers = {};      // {题号: 选项}
  var times = {};        // {题号: 毫秒}
  var startAt = 0;
  var lastAt = 0;
  var timerId = 0;
  var TOTAL = 0;

  function initQuiz() {
    var cards = document.querySelectorAll('.qcard[id^="q"]');
    if (!cards.length) return;
    TOTAL = cards.length;
    answers = {}; times = {};
    startAt = Date.now();
    lastAt = startAt;

    // 未作答的题：显示占位符，不再跟着总时间跳数字
    var cards = document.querySelectorAll('.qcard[id^="q"]');
    for (var i = 0; i < cards.length; i++) {
      var el = document.getElementById('timer' + i);
      if (el) el.textContent = '未作答';
    }

    // 只跑总计时器
    if (timerId) clearInterval(timerId);
    timerId = setInterval(tick, 200);
    tick();
    updateBar();
  }

  /** 每 200ms 刷新一次【总计时器】；每题计时器只在作答时定格 */
  function tick() {
    var now = Date.now();
    var totalEl = document.getElementById('totaltimer');
    if (totalEl) {
      totalEl.textContent = fmtSec((now - startAt) / 1000);
    }
  }

  /** 秒数格式化：mm:ss */
  function fmtSec(sec) {
    if (sec < 0) sec = 0;
    var m = Math.floor(sec / 60);
    var s = Math.floor(sec % 60);
    return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }

  /** 选中一个选项。未提交前可以反复修改（改选项不重置本题计时） */
  function pick(qi, ci) {
    var now = Date.now();
    var firstTime = (answers[qi] === undefined);

    answers[qi] = ci;
    if (firstTime) {
      // 只有第一次选择才计本题耗时；之后改选项不重新计时
      times[qi] = Math.max(0, now - lastAt);
      lastAt = now;
    }

    // 高亮
    var card = document.getElementById('q' + qi);
    if (card) {
      var opts = card.querySelectorAll('.opt');
      for (var i = 0; i < opts.length; i++) {
        opts[i].classList.toggle('sel', i === ci);
      }
    }
    var t = document.getElementById('timer' + qi);
    if (t) t.textContent = '用时 ' + (times[qi] / 1000).toFixed(1) + ' 秒';

    updateBar();

    // 自动滚到下一题
    var next = document.getElementById('q' + (qi + 1));
    if (next) next.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function updateBar() {
    var el = document.getElementById('answered');
    if (!el) return;
    var n = Object.keys(answers).length;
    el.textContent = n;
    var btn = document.getElementById('submitbtn');
    if (btn) {
      btn.textContent = (n >= TOTAL && TOTAL > 0) ? '提交全部 (' + n + '/' + TOTAL + ')' : '提交全部';
    }
  }

  function doSubmit() {
    if (!TOTAL) return;
    var n = Object.keys(answers).length;
    if (n < TOTAL) {
      if (!confirm('还有 ' + (TOTAL - n) + ' 题没作答，未作答的题按答错计算。确定提交吗？')) return;
    }
    // 尚未提交的那一刻，把最后一题到现在的耗时补上
    var now = Date.now();
    var payload = { a: 'submit', t: token };
    for (var i = 0; i < TOTAL; i++) {
      payload['c' + i] = (answers[i] !== undefined) ? answers[i] : -1;
      payload['m' + i] = (times[i] !== undefined) ? times[i] : 0;
    }
    // 没作答的题，耗时按 0 记（不计入速度统计）
    if (timerId) clearInterval(timerId);
    act(payload);
  }

  /* ================================================================
   *  事件绑定
   * ================================================================ */
  function bindAll() {
    // 监听器只绑一次，绑在 document 上。
    // 绝不能用 #root：mount() 会整体替换 body.innerHTML，
    // 那样 #root 被销毁重建，绑在它上面的监听器会全部丢失，
    // 表现就是「点一次之后必须再点一次才生效」。
    if (document.__physBound === '1') { initQuiz(); bindExtras(); return; }
    document.__physBound = '1';

    /* 点击类动作（事件委托，永久有效） */
    document.addEventListener('click', function (ev) {
      var el = ev.target.closest ? ev.target.closest('[data-act],[data-q]') : null;
      if (!el) return;

      // 选项
      if (el.hasAttribute && el.hasAttribute('data-q') && el.hasAttribute('data-c')) {
        ev.preventDefault();
        pick(parseInt(el.getAttribute('data-q'), 10), parseInt(el.getAttribute('data-c'), 10));
        return;
      }

      var a = el.getAttribute('data-act');
      if (!a) return;
      ev.preventDefault();

      if (a === 'subject') { act({ a: 'subject', s: el.getAttribute('data-subject'), t: token }); return; }
      if (a === 'boardset') { act({ a: 'board', u: el.getAttribute('data-b') || '', t: token }); return; }
      if (a === 'starttest') { act({ a: 'starttest', u: el.getAttribute('data-unit'), t: token }); return; }
      if (a === 'start')  { act({ a: 'start', u: el.getAttribute('data-unit'), t: token }); return; }
      if (a === 'quit')   { if (confirm('确定放弃本次练习吗？不计成绩。')) { if (timerId) clearInterval(timerId); act({ a: 'quit', t: token }); } return; }
      if (a === 'go') {
        var p = el.getAttribute('data-page');
        if (timerId) clearInterval(timerId);
        // 排行榜走自己的分支（要带科目参数），其余纯切换页面服务端自己认识
        if (p === 'board') { act({ a: 'board', t: token }); return; }
        if (p === 'home')  { act({ a: 'view', t: token }); return; }
        if (p === 'wrong' || p === 'favs' || p === 'trend' ||
            p === 'online' || p === 'stats') {
          act({ a: p, t: token }); return;
        }
        if (p === 'chat') { act({ a: 'chat', t: token }); return; }
        act({ a: 'view', t: token }); return;
      }

      /* ---- 扩展功能 ---- */
      // 每日一练：服务端优先从错题本抽题，并顺手打卡
      if (a === 'daily')     { if (timerId) clearInterval(timerId); act({ a: 'daily', t: token }); return; }
      if (a === 'wrongredo') { if (timerId) clearInterval(timerId); act({ a: 'wrongredo', t: token }); return; }
      if (a === 'favredo')   { if (timerId) clearInterval(timerId); act({ a: 'favredo', t: token }); return; }

      // 收藏 / 取消收藏：就地翻转星标，不等服务端（体验更跟手）
      if (a === 'fav') {
        var fu = el.getAttribute('data-unit');
        var fq = el.getAttribute('data-qid');
        if (el.classList.contains('favstar')) {
          var on = el.classList.toggle('on');
          el.textContent = on ? '★' : '☆';
        }
        act({ a: 'fav', u: fu, q: fq, t: token });
        return;
      }

      // 导出：让浏览器直接下载（服务端返回附件头）
      if (a === 'export') {
        var fmt = el.getAttribute('data-fmt') || 'csv';
        doExport(fmt);
        return;
      }

      if (a === 'nickedit')   { openNick(); return; }
      if (a === 'nickcancel') { closeNick(); return; }
      if (a === 'nicksave')   { saveNick(); return; }
      if (a === 'chat_send')  { sendChat(el); return; }
    }, false);

    initQuiz();
    bindExtras();
  }

  /** 按 id 绑定的控件：每次装载后都要重绑（元素是新的） */
  function bindExtras() {
    var sb = document.getElementById('submitbtn');
    if (sb && !sb.__bound) {
      sb.__bound = 1;
      sb.addEventListener('click', function (e) { e.preventDefault(); doSubmit(); });
    }

    var sel = document.getElementById('boardsel');
    if (sel && !sel.__bound) {
      sel.__bound = 1;
      sel.addEventListener('change', function () {
        act({ a: 'board', u: sel.value || '', t: token });
      });
    }

    var ni = document.getElementById('nickinput');
    if (ni && !ni.__bound) {
      ni.__bound = 1;
      ni.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); saveNick(); }
      });
    }
    var nm = document.getElementById('nickmodal');
    if (nm && !nm.__bound) {
      nm.__bound = 1;
      nm.addEventListener('click', function (e) { if (e.target === nm) closeNick(); });
    }

    var ci = document.getElementById('chatinput');
    if (ci && !ci.__bound) {
      ci.__bound = 1;
      ci.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); sendChat(ci); }
      });
    }

    var cl = document.getElementById('chatlist');
    if (cl) cl.scrollTop = cl.scrollHeight;

    revivePageModules();
  }

  /**
   * 每次整页重绘之后，把“跨页面存活”的模块重新挂到新 DOM 上。
   *
   * 为什么需要这一步：
   *   mount() 直接替换 document.body.innerHTML，
   *   原来绑定在按钮/画布上的监听器和引用全部失效。
   *   音乐播放器（__Music）和背景（__BG）都是页面级单例，
   *   它们本身不能被重建（重建会导致音乐重头播 / 背景闪一下），
   *   只能重新认领新节点 —— 这就是这个函数干的事。
   */
  function revivePageModules() {
    try { if (window.__Music && window.__Music.boot) window.__Music.boot(); } catch (e) { /* 音乐失败不影响主流程 */ }
    try { if (window.__BG && window.__BG.resync) window.__BG.resync(); } catch (e) {}
  }

  /**
   * 首次进入强制设置昵称。
   * 服务端在 __S.need_nick 里告诉我们「这个人还没昵称」，
   * 此时弹出弹层并且不允许关闭（点遮罩/取消都无效）。
   */
  function enforceNick() {
    if (!S || !S.need_nick) return;
    var m = document.getElementById('nickmodal');
    if (!m) return;
    m.hidden = false;
    m.dataset.forced = '1';
    // 隐藏「取消」按钮，强制必须填
    var cancel = m.querySelector('[data-act="nickcancel"]');
    if (cancel) cancel.style.display = 'none';
    var tip = document.getElementById('nicktip');
    if (tip) tip.style.display = 'block';
    var i = document.getElementById('nickinput');
    setTimeout(function () { if (i) i.focus(); }, 120);
  }

  /** 打开昵称编辑弹层 */
  function openNick() {
    var m = document.getElementById('nickmodal');
    var i = document.getElementById('nickinput');
    if (!m) return;
    if (i) { i.value = (S && S.nick) ? S.nick : ''; }
    m.hidden = false;
    setTimeout(function () { if (i) i.focus(); }, 50);
  }
  function closeNick() {
    var m = document.getElementById('nickmodal');
    if (!m) return;
    if (m.dataset.forced === '1') return;   // 强制设置昵称期间不许关
    m.hidden = true;
  }
  function saveNick() {
    var i = document.getElementById('nickinput');
    var nick = i ? i.value.trim() : '';
    if (!nick) { toast('请输入昵称'); return; }
    var m = document.getElementById('nickmodal');
    if (m) { m.dataset.forced = ''; m.hidden = true; }
    act({ a: 'setnick', nick: nick, t: token });
  }

  function sendChat(el) {
    var input = document.getElementById('chatinput');
    var text = input ? input.value.trim() : '';
    if (!text) { toast('请输入内容'); return; }
    act({ a: 'chat_send', text: text, t: token });
  }

        /* ---------------- 小工具 ---------------- */
  function showBusy() {
    if (document.getElementById('busy')) return;
    var d = document.createElement('div');
    d.id = 'busy';
    // 不拦截点击：遮罩只做视觉提示，绝不吃掉用户的操作
    d.style.pointerEvents = 'none';
    document.body.appendChild(d);
  }
  function hideBusy() {
    var d = document.getElementById('busy');
    if (d) d.remove();
  }
  function toast(msg) {
    var t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }

  /* ---------------- 启动 ---------------- */
  bindAll();
  applySlide();
  enforceNick();
  revivePageModules();
  dismissBoot();
  setTimeout(dismissBoot, 3000);
})();
