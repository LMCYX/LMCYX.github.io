/* ==================================================================
 * 背景生成器（纯 JS / Canvas 2D，无图片、无 WebGL）
 * ==================================================================
 * 需求：背景用 JS 生成，并且跟着音乐变化。
 *
 * ── 重绘策略（为什么这样做） ────────────────────────────────
 * 以前每一帧都要：
 *   · 全屏 fillRect 铺底色
 *   · 5 个 createRadialGradient（每帧新建对象，最贵的部分）
 *   · 26 个闪点
 *   · 再来一次全屏暗角
 * 在手机上这是 900×1600×1.6 的像素量，帧率很低。
 *
 * 现在改成两条独立通道：
 *
 *   1) 静态底色层：色调映射只做一次，画到一张低分辨率
 *      （1/4 边长）的小 canvas 上当“背景图”，每帧只 drawImage 一次。
 *      光斑用低分辨率离屏画布（1/2）合成放大，
 *      既保留柔和的渐变观感，又省掉大部分逐像素填充。
 *
 *   2) 动态层：只有随音乐变化的部分走每帧重绘，
 *      并且帧率上限 30fps（人眼对缓慢流动的光斑无感）。
 *
 * 另外：
 *   · 页面切到后台（document.hidden）自动停帧，回来再续
 *   · 尊重 prefers-reduced-motion：只画一张静态图
 *   · 没有音乐时用正弦波驱动，画面照样呼吸
 * ================================================================== */
(function () {
  'use strict';

  /* 单例：整页重绘后脚本会被再执行一次，不能重建画布 */
  if (window.__BG && window.__BG.__singleton) {
    window.__BG.resync();
    return;
  }

  var cv, ctx, W, H, DPR, cssW, cssH;

  /* 离屏层：blobCanvas 是低分辨率光斑层，vignette 是暗角贴图 */
  var blobCv, blobCtx, blobW, blobH, BLOB_SCALE = 0.5;

  var raf = 0, running = false, t0 = 0, lastFrame = 0;
  var FREQ_MS = 33;           // 目标帧间隔 ≈30fps
  var freq = null, analyser = null;
  var reduced = false;

  /* 光斑：位置/大小/色相/相位 */
  var blobs = [
    { x: 0.15, y: 0.18, r: 0.42, h: 222, s: 90, ph: 0.0 },
    { x: 0.85, y: 0.12, r: 0.36, h: 285, s: 85, ph: 1.7 },
    { x: 0.78, y: 0.82, r: 0.40, h: 165, s: 80, ph: 3.1 },
    { x: 0.20, y: 0.88, r: 0.34, h: 18,  s: 85, ph: 4.6 },
    { x: 0.50, y: 0.50, r: 0.30, h: 250, s: 70, ph: 6.0 }
  ];

  /* 预生成的星点（固定伪随机，避免每帧算 sin 又不会乱跳） */
  var STARS = (function () {
    var a = [], seed = 20260927;
    function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; }
    for (var i = 0; i < 22; i++) a.push({ x: rnd(), y: rnd(), ph: rnd() * 6.283, sp: 0.7 + rnd() });
    return a;
  })();

  function resize() {
    // DPR 上限压到 1.25：手机 3x 屏下逐像素填充量是 1x 的 9 倍，
    // 背景是柔和渐变，1.25 视觉上已经足够，帧率却高很多。
    DPR = Math.min(window.devicePixelRatio || 1, 1.25);
    cssW = window.innerWidth;
    cssH = window.innerHeight;
    W = Math.max(2, Math.floor(cssW * DPR));
    H = Math.max(2, Math.floor(cssH * DPR));
    if (!cv) return false;
    cv.width = W; cv.height = H;
    cv.style.width = cssW + 'px';
    cv.style.height = cssH + 'px';

    // 低分辨率光斑层
    blobW = Math.max(2, Math.floor(W * BLOB_SCALE));
    blobH = Math.max(2, Math.floor(H * BLOB_SCALE));
    if (!blobCv) { blobCv = document.createElement('canvas'); blobCtx = blobCv.getContext('2d'); }
    blobCv.width = blobW; blobCv.height = blobH;
    return true;
  }

  /** 取某一频段的平均能量 0~1 */
  function band(lo, hi) {
    if (!freq || !freq.length) return 0;
    var n = freq.length;
    var a = (n * lo) | 0, b = (n * hi) | 0;
    if (b <= a) b = a + 1;
    var s = 0;
    for (var i = a; i < b && i < n; i++) s += freq[i];
    return (s / (b - a)) / 255;
  }

  /** 低分辨率层画 5 个光斑（加色混合），再放大贴到主画布 */
  function paintBlobs(t, eLow, eMid, eHigh, eAll) {
    var c = blobCtx;
    c.globalCompositeOperation = 'source-over';
    c.clearRect(0, 0, blobW, blobH);
    c.globalCompositeOperation = 'lighter';

    for (var i = 0; i < blobs.length; i++) {
      var b = blobs[i];
      var px = (b.x + Math.sin(t * 0.20 + b.ph) * 0.10) * blobW;
      var py = (b.y + Math.cos(t * 0.16 + b.ph * 0.8) * 0.08) * blobH;
      var rr = b.r * Math.min(blobW, blobH) * (0.85 + eLow * 0.55) * (0.9 + eMid * 0.25);
      if (rr < 1) rr = 1;

      var hue = (b.h + t * 7 + eHigh * 40) % 360;
      var alpha = 0.16 + eAll * 0.22;

      var g = c.createRadialGradient(px, py, 0, px, py, rr);
      g.addColorStop(0, 'hsla(' + hue + ',' + b.s + '%,62%,' + alpha.toFixed(3) + ')');
      g.addColorStop(0.55, 'hsla(' + ((hue + 25) % 360) + ',' + b.s + '%,52%,' + (alpha * 0.4).toFixed(3) + ')');
      g.addColorStop(1, 'hsla(' + hue + ',' + b.s + '%,45%,0)');
      c.fillStyle = g;
      c.beginPath();
      c.arc(px, py, rr, 0, 6.2832);
      c.fill();
    }
  }

  /** 暗角：用缓存的径向渐变（不每帧新建） */
  var lastVig = null;
  function vignette() {
    if (!lastVig) {
      lastVig = ctx.createRadialGradient(W / 2, H * 0.45, Math.min(W, H) * 0.25,
                                         W / 2, H * 0.5, Math.max(W, H) * 0.78);
      lastVig.addColorStop(0, 'rgba(0,0,0,0)');
      lastVig.addColorStop(1, 'rgba(0,0,0,0.55)');
    }
    return lastVig;
  }

  /** 一帧 */
  function frame(t, eLow, eMid, eHigh, eAll) {
    // ---- 底色（平涂，比渐变便宜很多） ----
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#05070f';
    ctx.fillRect(0, 0, W, H);

    // ---- 光斑层：低分辨率画完放大，等于免费做了模糊 ----
    paintBlobs(t, eLow, eMid, eHigh, eAll);
    ctx.globalCompositeOperation = 'lighter';
    ctx.drawImage(blobCv, 0, 0, blobW, blobH, 0, 0, W, H);

    // ---- 高音闪点 ----
    if (eHigh > 0.18) {
      var base = eHigh * 0.5;
      for (var k = 0; k < STARS.length; k++) {
        var s = STARS[k];
        var sa = base * (0.4 + 0.6 * Math.abs(Math.sin(t * 2 * s.sp + s.ph)));
        ctx.fillStyle = 'rgba(255,255,255,' + sa.toFixed(3) + ')';
        var sx = ((s.x + Math.sin(t * 0.3 + s.ph) * 0.02) * W) | 0;
        var sy = ((s.y + Math.cos(t * 0.25 + s.ph) * 0.02) * H) | 0;
        ctx.fillRect(sx, sy, 2, 2);
      }
    }

    // ---- 暗角 ----
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = vignette();
    ctx.fillRect(0, 0, W, H);
  }

  function loop(now) {
    if (!running) return;
    raf = requestAnimationFrame(loop);
    if (now - lastFrame < FREQ_MS) return;      // 限帧
    lastFrame = now;

    var t = (now - t0) * 0.001;
    var hasMusic = !!freq;
    var eLow  = hasMusic ? band(0.00, 0.12) : (0.5 + 0.5 * Math.sin(t * 0.7));
    var eMid  = hasMusic ? band(0.12, 0.45) : (0.5 + 0.5 * Math.sin(t * 0.5 + 1.3));
    var eHigh = hasMusic ? band(0.45, 0.95) : (0.5 + 0.5 * Math.sin(t * 0.9 + 2.7));
    var eAll  = (eLow + eMid + eHigh) / 3;
    frame(t, eLow, eMid, eHigh, eAll);
  }

  /** 找画布；整页重绘后 canvas 是新节点，必须重新取 */
  function resync() {
    var n = document.getElementById('bgcanvas');
    if (!n) return;
    if (n !== cv) {
      cv = n;
      ctx = cv.getContext('2d');
      lastVig = null;
      if (!resize()) return;
    }
    if (reduced) {           // 静态模式：直接画一张
      frame(0, 0.5, 0.5, 0.5, 0.5);
      return;
    }
    if (!running) start();
  }

  function start() {
    if (!cv) { resync(); if (!cv) return; }
    if (!ctx) ctx = cv.getContext('2d');
    if (!ctx) return;
    reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    if (!resize()) return;
    running = true;
    lastFrame = 0;
    if (!t0) t0 = performance.now();
    if (raf) cancelAnimationFrame(raf);
    raf = requestAnimationFrame(loop);
  }

  function stop() {
    running = false;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
  }

  window.addEventListener('resize', function () { lastVig = null; if (resize() && !running) resync(); });

  // 后台标签页不画：手机上看不到还烧电
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) stop();
    else if (!reduced) start();
  });

  window.__BG = {
    __singleton: true,
    start: start,
    stop: stop,
    resync: resync,
    /** 音乐播放器拿到 analyser 后接进来 */
    setAnalyser: function (a) {
      analyser = a;
      if (analyser) {
        freq = new Uint8Array(analyser.frequencyBinCount);
        var pull = function () {
          if (!analyser) return;
          analyser.getByteFrequencyData(freq);
          setTimeout(pull, 40);
        };
        pull();
      } else {
        freq = null;
      }
    }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', resync);
  else resync();
})();
