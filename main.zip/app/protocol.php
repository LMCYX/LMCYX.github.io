<?php
/**
 * 协议层：请求解析 / 响应封装
 *
 * 二进制请求（由 server.mjs 组装）：
 *   [0]      type       1 字节
 *   [1]      ipLen      1 字节
 *   [2..]    ip         ipLen 字节（服务端从 socket 得到的真实来源 IP）
 *   [...]    tokenLen   2 字节 小端
 *   [...]    token      tokenLen 字节（会话令牌，服务端生成）
 *   [...]    data       剩余：动作数据（LBSP 编码的键值对）
 *
 * 二进制响应：
 *   [0]=0  普通：后面全部是页面字节
 *   [0]=1  带令牌：后跟 2 字节令牌长度 + 令牌 + 页面字节
 */

declare(strict_types=1);

const PROTO_VERSION = 1;

/** 读取客户端来源 IP 的哈希（不落原始 IP，兼顾隐私与「IP 登录」需求） */
function client_ip_key(string $ip): string
{
    return substr(hash('sha256', 'phys-lab-v1|' . $ip), 0, 24);
}

/**
 * 用户显示名 = 直接显示连接服务器的 IP（需求 4）。
 *
 * 注意：ipkey（内部标识）仍是 IP 的哈希，用于做文件名/键名，避免
 * 原始 IP（含冒号、点号）直接进数据库键；显示时用的是明文 IP。
 */
function ip_label(string $ip): string
{
    $ip = trim($ip);
    if ($ip === '') return '未知';
    // 兼容反代带来的 X-Forwarded-For（可能带端口）
    if (strpos($ip, ':') !== false && substr_count($ip, ':') === 1) {
        $ip = explode(':', $ip)[0];
    }
    return $ip;
}

final class Request
{
    public function __construct(
        public int $type,
        public string $ip,
        public string $token,
        public array $data,   // LBSP 解码后的键值对
        public string $raw
    ) {}
}

final class Response
{
    public string $body = '';
    public ?string $token = null;

    /**
     * 非空时表示"这是一次文件下载"，不走 HTML 渲染。
     *   ['name'=>文件名, 'type'=>MIME, 'body'=>内容]
     * 用在「导出成绩 CSV / JSON 备份」上。
     */
    public ?array $download = null;

    public function setBody(string $b): void { $this->body = $b; }

    public function encode(): string
    {
        if ($this->token === null) {
            return "\x00" . $this->body;
        }
        $t = $this->token;
        return "\x01" . pack('v', strlen($t)) . $t . $this->body;
    }
}

/* ------------------------------------------------------------------ *
 *  LBSP：Length-prefixed Binary String Pair
 *  把动作编码成 [键长度][键][值长度][值]... 的紧凑二进制，
 *  不用 JSON、不用 HTTP 表单。
 * ------------------------------------------------------------------ */
function lbs_decode(string $buf): array
{
    $out = [];
    $o = 0;
    $n = strlen($buf);
    while ($o + 2 <= $n) {
        $kl = unpack('v', substr($buf, $o, 2))[1];
        $o += 2;
        if ($o + $kl > $n) break;
        $k = substr($buf, $o, $kl);
        $o += $kl;
        if ($o + 4 > $n) break;
        $vl = unpack('V', substr($buf, $o, 4))[1];
        $o += 4;
        if ($o + $vl > $n) break;
        $v = substr($buf, $o, $vl);
        $o += $vl;
        $out[$k] = $v;
    }
    return $out;
}

function lbs_encode(array $pairs): string
{
    $out = '';
    foreach ($pairs as $k => $v) {
        $v = (string)$v;
        $out .= pack('v', strlen((string)$k)) . (string)$k . pack('V', strlen($v)) . $v;
    }
    return $out;
}

/** 解析来自 Node 的请求字节 */
function parse_request(string $raw): Request
{
    if (strlen($raw) < 4) {
        return new Request(0, '0.0.0.0', '', [], $raw);
    }
    $type = ord($raw[0]);
    $ipLen = ord($raw[1]);
    $o = 2;
    $ip = substr($raw, $o, $ipLen);
    $o += $ipLen;
    $tokLen = 0;
    if ($o + 2 <= strlen($raw)) {
        $tokLen = unpack('v', substr($raw, $o, 2))[1];
        $o += 2;
    }
    $token = substr($raw, $o, $tokLen);
    $o += $tokLen;
    $data = lbs_decode(substr($raw, $o));
    return new Request($type, $ip, $token, $data, $raw);
}

/* ------------------------------------------------------------------ *
 *  HTTP 场景下的请求解析
 *
 *  纯 PHP 版没有 Node 那层「先拆 PHYS 帧再交给 PHP」的中间层，
 *  因此这里直接接受两种输入：
 *    1) 完整 PHYS 帧（裸 TCP / 原生客户端）
 *    2) 纯 LBSP 动作体（浏览器：动作已编码好，直接 POST 过来）
 * ------------------------------------------------------------------ */
function parse_request_body(string $raw, string $ip): Request
{
    // 是 PHYS 帧吗？（魔数 "PHYS"）
    if (strlen($raw) >= 14 && substr($raw, 0, 4) === 'PHYS') {
        $type = ord($raw[5]);
        $len  = unpack('V', substr($raw, 10, 4))[1];
        $body = substr($raw, 14, $len);
        return parse_attach($body, $ip, $type);
    }

    // 否则当作纯 LBSP 动作体
    return parse_attach($raw, $ip, 0x03);
}

/**
 * 解析 [2B 令牌长度][令牌][LBSP 动作体]
 *
 * 关键：令牌长度是 0 时，后面直接就是 LBSP 动作体。
 * 不能因为「前两字节看着像长度」就把动作体的头两字节吃掉。
 */
function parse_attach(string $body, string $ip, int $type): Request
{
    $token = '';
    $data  = $body;

    if (strlen($body) >= 4) {
        $n = unpack('v', substr($body, 0, 2))[1];
        // 只有长度为正、且后面确实够长、且内容像令牌时，才认作令牌
        if ($n > 0 && strlen($body) >= 2 + $n) {
            $cand = substr($body, 2, $n);
            if (preg_match('/^[A-Za-z0-9_\-]{8,64}$/', $cand)) {
                $token = $cand;
                $data  = substr($body, 2 + $n);
            }
        }
    }

    $fields = lbs_decode($data);

    // 兜底：LBSP 没解出动作时，尝试跳过 2 字节空令牌头再解一次
    if (!isset($fields['a']) && strlen($data) >= 2) {
        $n = unpack('v', substr($data, 0, 2))[1];
        if ($n === 0) {
            $alt = lbs_decode(substr($data, 2));
            if (isset($alt['a'])) { $fields = $alt; $data = substr($data, 2); }
        }
    }

    return new Request($type, $ip, $token, $fields, $body);
}
