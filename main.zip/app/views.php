<?php
/** 各页面视图：全部由 PHP 合成完整 HTML。 */

declare(strict_types=1);

/* ------------------------------------------------------------------ *
 *  顶栏 + 导航
 * ------------------------------------------------------------------ */
function view_header(array $user, string $fp, string $active = ''): string
{
    $nick  = trim((string)($user['nick'] ?? ''));
    $ip    = e((string)($user['ip'] ?? ''));
    $label = e((string)$user['label']);
    $rank  = user_rank((string)$user['ipkey']);
    $rankTxt = $rank > 0 ? "第 {$rank} 名" : '未上榜';
    $named = $nick !== '';
    $nickHint = $named ? '改昵称' : '设置昵称';

    // 导航标签。
    // 分成两行显示：上面是主要功能，下面是附加功能 —— 手机上不挤。
    $tabs = [
        'home'   => ['单元练习', 'home'],
        'wrong'  => ['错题本',   'wrong'],
        'favs'   => ['收藏',     'favs'],
        'trend'  => ['成绩',     'trend'],
        'board'  => ['排行榜',   'board'],
        'online' => ['在线',     'online'],
        'stats'  => ['统计',     'stats'],
        'chat'   => ['聊天室',   'chat'],
    ];

    $nav = '';
    foreach ($tabs as $key => [$text, $page]) {
        $cls = $active === $key ? ' class="on"' : '';
        $nav .= '<a href="#"' . $cls . ' data-act="go" data-page="' . $page . '">' . $text . '</a>';
    }

    $siteName = e(SITE_NAME);
    $siteSub  = e(SITE_SUB);

    return <<<HTML
<header class="top">
  <div class="brand">{$siteName}<small>{$siteSub}</small></div>
  <div class="head-right">
    <span class="chip" title="{$ip}">{$label}</span>
    <a class="chip nickbtn" href="#" data-act="nickedit">{$nickHint}</a>
    <span class="chip hl">{$rankTxt}</span>
  </div>
</header>
<nav class="tabs">{$nav}</nav>
HTML;
}

/* ------------------------------------------------------------------ *
 *  首页：科目切换 + 单元列表（每个单元两个入口：练习 / 总测）
 * ------------------------------------------------------------------ */
function render_home(array $state, array $user, string $fp): string
{
    $prog   = all_progress((string)$user['ipkey']);
    $notice = (string)($state['notice'] ?? '');
    $noticeHtml = $notice !== '' ? '<div class="notice">' . e($notice) . '</div>' : '';

    $subj = (string)($state['subject'] ?? 'phy');
    if (!isset(subjects()[$subj])) $subj = 'phy';

    /* ---- 科目切换 ---- */
    $tabs = '';
    foreach (subjects() as $key => $info) {
        $cnt = count(subject_unit_ids($key));
        if ($cnt === 0) continue;
        $on = ($key === $subj) ? ' on' : '';
        $tabs .= '<a href="#" class="subjtab' . $on . '" data-act="subject" data-subject="' . e($key) . '">'
               . e($info['short'])
               . '<small>' . $cnt . ' 节</small></a>';
    }

    /* ---- 单元列表 ---- */
    $cards = '';
    foreach (curriculum()[$subj] ?? [] as $chNo => $ch) {
        $inner = '';
        foreach ($ch['subs'] as $uid => $sub) {
            $total = unit_size($uid);
            if ($total === 0) continue;
            $got = $prog[$uid] ?? 0;
            $pct = $total > 0 ? (int)round($got / $total * 100) : 0;
            $inner .= '<div class="unitcard">'
                . '<div class="t">' . e($sub['name']) . '</div>'
                . '<div class="m"><span>P' . (int)$sub['page'] . '</span>'
                . '<span>首次做对 ' . $got . '/' . $total . '</span></div>'
                . '<div class="bar"><i style="width:' . $pct . '%"></i></div>'
                . '<div class="unitacts">'
                . '<a class="mini" href="#" data-act="start" data-unit="' . e($uid) . '">练习 10 题</a>'
                . '<a class="mini test" href="#" data-act="starttest" data-unit="' . e($uid) . '">单元总测 20 题</a>'
                . '</div></div>';
        }
        if ($inner === '') continue;
        $cards .= '<h2 style="margin-top:16px">' . e($ch['name']) . '</h2><div class="grid">' . $inner . '</div>';
    }
    if ($cards === '') $cards = '<div class="card"><div class="empty">题库准备中。</div></div>';

    // 快捷入口：错题本 / 收藏 / 每日一练（有内容时才显示）
    $quick = '';
    $wn = (int)($state['wrong_n'] ?? 0);
    $fn = (int)($state['fav_n'] ?? 0);
    if ($wn > 0) {
        $quick .= '<a class="qk no" href="#" data-act="go" data-page="wrong">'
                . '<b>' . $wn . '</b><span>错题待复习</span></a>';
    }
    if ($fn > 0) {
        $quick .= '<a class="qk fav" href="#" data-act="go" data-page="favs">'
                . '<b>' . $fn . '</b><span>收藏的题</span></a>';
    }
    $quickHtml = $quick !== '' ? '<div class="quickrow">' . $quick . '</div>' : '';

    // 在线人数 + 全站统计小条
    $onlineN = (int)($state['online_n'] ?? 0);
    $st = $state['site_stat'] ?? [];
    $meta = '<div class="metaline">'
          . '<span><i class="dot on"></i> ' . $onlineN . ' 人在线</span>'
          . '<span>题库 ' . (int)($st['questions'] ?? 0) . ' 题</span>'
          . '<span>累计作答 ' . (int)($st['answers'] ?? 0) . ' 题次</span>'
          . '<span>全站正确率 ' . (int)($st['accuracy'] ?? 0) . '%</span>'
          . '</div>';

    return view_header($user, $fp, 'home')
        . $noticeHtml
        . daily_card($state, $user, $fp)
        . $quickHtml
        . '<nav class="subjnav">' . $tabs . '</nav>'
        . $meta
        . $cards;
}

/* ------------------------------------------------------------------ *
 *  练习页（一次显示 10 题）
 * ------------------------------------------------------------------ */
function render_practice(array $state, array $user, string $fp): string
{
    $s = $state['session'];
    $notice = (string)($state['notice'] ?? '');
    $noticeHtml = $notice !== '' ? '<div class="notice ok">' . e($notice) . '</div>' : '';

    if (!$s) {
        return view_header($user, $fp, 'home')
            . '<h1>练习</h1>' . $noticeHtml
            . '<div class="card"><div class="empty">没有进行中的练习。<br>'
            . '<a class="btn" style="margin-top:14px" href="#" data-act="go" data-page="home">返回单元列表</a>'
            . '</div></div>';
    }

    // 跨单元会话（每日一练 / 错题重练 / 收藏重练）：
    //   unit_id 是空的，题号存成 "unit:qid" 列表，用 session_pairs 解析。
    // 普通会话仍然只有一个 unit_id。
    $mixed = !empty($s['mixed']);
    $pairs = session_pairs($s);
    $meta  = $mixed ? null : unit_meta((string)$s['unit_id']);
    $qids  = array_map(fn($p) => (int)$p[1], $pairs);   // 纯题号（判分/提交用）
    $total = count($pairs);
    $done  = (int)$s['done'] === 1;
    $unitName = e($mixed
        ? (string)($s['unit_name'] ?? '综合练习')
        : ($meta['name'] ?? (string)$s['unit_id']));

    /* ---------- 已提交：显示结算 ---------- */
    if ($done) {
        $result = $s['result'] ?? null;
        if (!$result) {
            return view_header($user, $fp, 'home')
                . '<h1>练习已结束</h1>' . $noticeHtml
                . '<div class="card"><div class="empty">本次未提交，不计成绩。<br>'
                . '<a class="btn" style="margin-top:14px" href="#" data-act="go" data-page="home">返回单元</a>'
                . '</div></div>';
        }

        $correct = (int)$result['correct'];
        $rate    = $total > 0 ? (int)round($correct / $total * 100) : 0;
        $prog    = unit_progress((string)$user['ipkey'], (string)$s['unit_id']);
        $size    = unit_size((string)$s['unit_id']);
        $rank    = user_rank((string)$user['ipkey']);
        $rankTxt = $rank > 0 ? "第 {$rank} 名" : '—';

        $list = '';
        $_rseed = (string)$s['token'];
        foreach ($pairs as $i => $pr) {
            $qid = (int)$pr[1];
            $q = shuffled_question((string)$pr[0], $qid, $_rseed);
            if (!$q) continue;
            $d  = $result['detail'][$i] ?? null;
            $ok = $d && !empty($d['ok']);
            $chosen = $d ? (int)$d['choice'] : -1;
            $your = ($chosen >= 0 && isset($q['opts'][$chosen])) ? $q['opts'][$chosen] : '未作答';
            $ansTxt = $q['opts'][(int)$q['ans']] ?? '';
            $gain = $d ? (int)$d['gain'] : 0;
            $ms   = $d ? (int)$d['ms'] : 0;

            $opts = '';
            foreach ($q['opts'] as $j => $o) {
                $cls = 'opt';
                if ($j === (int)$q['ans']) $cls .= ' right';
                elseif ($j === $chosen)    $cls .= ' wrong';
                $opts .= '<div class="' . $cls . '"><span class="k">' . chr(65 + $j) . '</span><span>' . e($o) . '</span></div>';
            }

            $list .= '<div class="qcard">'
                . '<div class="qhead"><span class="qno">第 ' . ($i + 1) . ' 题</span>'
                . '<span class="qtimer">' . ($ok ? '✓ 答对 +' . $gain . ' 分' : '✗ 答错') . ' · ' . fmt_ms($ms) . '</span></div>'
                . '<div class="qtext">' . e($q['q']) . '</div>'
                . $opts
                . '<div class="exp"><span class="tag ' . ($ok ? 'ok' : 'no') . '">'
                . ($ok ? '你答对了' : '正确答案：' . e($ansTxt)) . '</span>'
                . e($q['exp'] ?? '') . '</div>'
                . '</div>';
        }

        return view_header($user, $fp, 'home')
            . '<h1>练习完成</h1>' . $noticeHtml
            . '<div class="card">'
            . '<h2>' . $unitName . '</h2>'
            . '<div class="stat3">'
            . '<div><b class="g">' . (int)$result['score'] . '</b><span>本次得分</span></div>'
            . '<div><b class="a">' . $rate . '%</b><span>正确率 (' . $correct . '/' . $total . ')</span></div>'
            . '<div><b class="o">' . fmt_ms((int)$result['avg_ms']) . '</b><span>答对平均速度</span></div>'
            . '</div>'
            . '<p class="sub" style="margin-bottom:0">首次做对 <b>' . $prog . ' / ' . $size
            . '</b>　排名 <b>' . $rankTxt . '</b></p>'
            . practice_summary($result, $qids, (string)$s['unit_id'], $s['delta'] ?? null)
            . '<div class="row" style="margin-top:13px">'
            . ($mixed
                ? '<a class="btn" href="#" data-act="wrongredo">再练一遍错题</a>'
                : '<a class="btn" href="#" data-act="start" data-unit="' . e($s['unit_id']) . '">再练一组</a>')
            . '<a class="btn ghost" href="#" data-act="go" data-page="home">返回单元</a>'
            . '<a class="btn ghost" href="#" data-act="go" data-page="board">看排行榜</a>'
            . '</div></div>'
            . '<h2 style="margin-top:18px">逐题回顾</h2>'
            . '<div class="qlist">' . $list . '</div>';
    }

    /* ---------- 作答中：一次显示全部 10 题 ---------- */
    $cards = '';
    $seed  = (string)$s['token'];
    $ipk   = (string)$user['ipkey'];
    foreach ($pairs as $i => $pr) {
        $pu  = (string)$pr[0];       // 这道题属于哪个单元
        $qid = (int)$pr[1];
        // 用打乱后的版本渲染，客户端看到的顺序与服务端判分一致
        $q = shuffled_question($pu, $qid, $seed);
        if (!$q) continue;
        $opts = '';
        foreach ($q['opts'] as $j => $o) {
            $opts .= '<button type="button" class="opt" data-q="' . $i . '" data-c="' . $j . '">'
                   . '<span class="k">' . chr(65 + $j) . '</span><span>' . e($o) . '</span></button>';
        }
        // 收藏星标：点了就加入/移出"待复习"
        $starOn = fav_has($ipk, $pu, $qid);
        $star = '<button type="button" class="favstar' . ($starOn ? ' on' : '')
              . '" data-act="fav" data-unit="' . e($pu) . '" data-qid="' . $qid . '"'
              . ' aria-label="收藏" title="' . ($starOn ? '取消收藏' : '收藏这道题') . '">'
              . ($starOn ? '★' : '☆') . '</button>';

        // 跨单元时在题号旁边标一下来源单元，避免不知道在做哪一章
        $from = '';
        if ($mixed) {
            $mm = unit_meta($pu);
            if ($mm !== null) {
                $from = ' <span class="qfrom">' . e(substr((string)$mm['name'], 0, 10)) . '</span>';
            }
        }

        $cards .= '<div class="qcard" id="q' . $i . '">'
            . $star
            . '<div class="qhead"><span class="qno">第 ' . ($i + 1) . ' 题' . $from . '</span>'
            . '<span class="qtimer" id="timer' . $i . '">—</span></div>'
            . '<div class="qtext">' . e($q['q']) . '</div>'
            . $opts . '</div>';
    }

    if ($mixed) {
        // 跨单元会话没有"单单元进度"这个概念，改成显示错题/收藏总数
        $prog = wrong_count($ipk);
        $size = $prog;
    } else {
        $prog = unit_progress((string)$user['ipkey'], (string)$s['unit_id']);
        $size = unit_size((string)$s['unit_id']);
    }

    $isTest = ((int)($s['is_test'] ?? 0) === 1);
    $tag    = $isTest ? '单元总测' : '练习';

    return view_header($user, $fp, 'home')
        . '<div class="pracbar">'
        . '<a class="btn ghost backbtn" href="#" data-act="go" data-page="home">'
        . '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3L5 8l5 5"/></svg>返回</a>'
        . '<div class="practitle">' . e($unitName) . '<span class="ptag' . ($isTest ? ' test' : '') . '">' . $tag . '</span></div>'
        . '<div class="ttotal"><b id="totaltimer">00:00</b></div>'
        . '</div>'
        . $noticeHtml
        . '<div class="qlist">' . $cards . '</div>'
        . '<div class="submitbar">'
        . '<div class="stat">已作答 <b id="answered">0</b> / ' . $total . ' 题</div>'
        . '<div class="row">'
        . '<a class="btn ghost" href="#" data-act="quit">放弃</a>'
        . '<button class="btn ok" id="submitbtn" type="button">提交全部</button>'
        . '</div></div>';
}

/* ------------------------------------------------------------------ *
 *  排行榜：总榜 + 三个学科分榜（共 4 个）
 * ------------------------------------------------------------------ */
function render_board(array $state, array $user, string $fp): string
{
    // 当前榜：'' = 总榜；'phy'/'bio'/'mor'/'inter' = 学科榜
    $cur = (string)($state['board_unit'] ?? '');
    // 只有这三个科目有独立榜，其余（含跨学科）一律回总榜
    if (!in_array($cur, ['phy', 'bio', 'mor'], true)) $cur = '';

    $myKey = (string)$user['ipkey'];

    /* ---- 四个榜的切换按钮 ---- */
    // 只有 物理 / 生物 / 道法 三个学科榜，加上总榜共 4 个
    $boardSubs = ['phy', 'bio', 'mor'];
    $tabs = '<a href="#" class="boardtab' . ($cur === '' ? ' on' : '') . '" data-act="boardset" data-b="">总榜</a>';
    foreach ($boardSubs as $key) {
        if (!isset(subjects()[$key])) continue;
        $tabs .= '<a href="#" class="boardtab' . ($cur === $key ? ' on' : '')
               . '" data-act="boardset" data-b="' . e($key) . '">' . e(subjects()[$key]['short']) . '榜</a>';
    }

    /* ---- 取数据 ---- */
    $rows  = ($cur === '') ? leaderboard_total(200) : leaderboard_subject($cur, 200);
    $title = ($cur === '') ? '总榜' : (subject_name($cur) . '榜');

    $body = '';
    foreach ($rows as $i => $r) {
        $n   = $i + 1;
        $cls = $n === 1 ? 'g' : ($n === 2 ? 's' : ($n === 3 ? 'b' : ''));
        $me  = ($r['ipkey'] === $myKey) ? ' class="me"' : '';
        $score  = ($r['score'] !== null) ? (int)$r['score'] : null;
        $online = fmt_duration((int)($r['online_ms'] ?? 0));

        $body .= '<tr' . $me . '>'
              . '<td class="rank ' . $cls . '">' . $n . '</td>'
              . '<td>' . e((string)$r['label'])
              .   (!empty($r['ip']) ? '<div style="font-size:10.5px;color:var(--txt3)">' . e((string)$r['ip']) . '</div>' : '')
              . '</td>'
              . '<td class="n"><b>' . ($score !== null ? $score : '—') . '</b></td>'
              . '<td class="n">' . e($online) . '</td>'
              . '</tr>';
    }
    if ($body === '') {
        $body = '<tr><td colspan="4"><div class="empty">还没有人上榜。</div></td></tr>';
    }

    return view_header($user, $fp, 'board')
        . '<nav class="boardnav">' . $tabs . '</nav>'
        . '<div class="card">'
        . '<h2>' . e($title) . '</h2>'
        . '<div style="overflow-x:auto"><table>'
        . '<thead><tr><th style="width:40px">名次</th><th>用户</th>'
        . '<th class="n">分数</th><th class="n">在线时间</th></tr></thead>'
        . '<tbody>' . $body . '</tbody></table></div>'
        . '</div>';
}

/* ------------------------------------------------------------------ *
 *  聊天室（支持发文件）
 * ------------------------------------------------------------------ */
function render_chat(array $state, array $user, string $fp): string
{
    $msgs   = $state['chat_msgs'] ?? (function_exists('chat_load') ? chat_load() : []);
    $files  = $state['cloud_files'] ?? (function_exists('cloud_list') ? cloud_list() : []);
    $notice = (string)($state['notice'] ?? '');
    $noticeHtml = $notice !== '' ? '<div class="notice ok">' . e($notice) . '</div>' : '';
    $myKey  = (string)$user['ipkey'];

    /* ---------- 消息列表 ---------- */
    $list = '';
    foreach ($msgs as $m) {
        $mine = ((string)($m['ipkey'] ?? '') === $myKey) ? ' mine' : ' other';
        $who  = e((string)($m['label'] ?? '匿名'));
        $tm   = function_exists('chat_time_text')
                ? chat_time_text((int)($m['at'] ?? 0))
                : date('H:i', (int)($m['at'] ?? 0));
        $text = (string)($m['text'] ?? '');

        $inner = '';
        // 文字（可能是附言）
        if (trim($text) !== '') {
            $inner .= '<div class="chattext">' . e($text) . '</div>';
        }
        if ($inner === '') $inner = '<div class="chattext">（空消息）</div>';

        $list .= '<div class="msg' . $mine . '">'
               . '<div class="who">' . $who . '</div>'
               . $inner
               . '<div class="tm">' . e($tm) . '</div>'
               . '</div>';
    }
    if ($list === '') {
        $list = '<div class="empty">还没有人发言。<br>说点什么，或者发个文件吧。</div>';
    }

    /* ---------- 可分享的云盘文件 ---------- */
    $opts = '<option value="">选择云盘文件分享…</option>';
    foreach ($files as $f) {
        $sz = function_exists('human_size') ? human_size((int)$f['size']) : ((int)$f['size'] . ' B');
        $opts .= '<option value="' . e((string)$f['id']) . '">'
               . e((string)$f['name']) . ' (' . e($sz) . ')</option>';
    }

    return view_header($user, $fp, 'chat')
        . '<h1>聊天室</h1>'
        . $noticeHtml
        . '<div class="card">'
        . '<div class="chatbox">'
        . '<div class="chatlist" id="chatlist">' . $list . '</div>'

        /* 文字消息 */
        . '<div class="chatinput">'
        . '<input type="text" id="chatinput" maxlength="500" placeholder="说点什么…（回车发送）" autocomplete="off">'
        . '<a class="btn" href="#" data-act="chat_send">发送</a>'
        . '</div>'
        . '</div>'
        . '<p class="sub" style="margin:11px 0 0">'
        . '每人每秒最多 1 条；消息永久保存。'
        . '</p>'
        . '</div>';
}


/* ------------------------------------------------------------------ *
 *  答完题总结（需求 5）：错了哪些、对了哪些、排行榜涨了什么
 * ------------------------------------------------------------------ */
function practice_summary(array $result, array $qids, string $unitId, ?array $delta): string
{
    $detail = $result['detail'] ?? [];

    // 分出答对 / 答错
    $right = [];
    $wrong = [];
    foreach ($qids as $i => $qid) {
        $q = get_question($unitId, (int)$qid);
        if (!$q) continue;
        $d = $detail[$i] ?? null;
        $ok = $d && !empty($d['ok']);
        $row = [
            'no'   => $i + 1,
            'q'    => (string)$q['q'],
            'gain' => $d ? (int)$d['gain'] : 0,
            'ms'   => $d ? (int)$d['ms'] : 0,
            'your' => '',
            'ans'  => (string)($q['opts'][(int)$q['ans']] ?? ''),
        ];
        if ($ok) {
            $right[] = $row;
        } else {
            $chosen = $d ? (int)$d['choice'] : -1;
            $row['your'] = ($chosen >= 0 && isset($q['opts'][$chosen]))
                            ? (string)$q['opts'][$chosen] : '未作答';
            $wrong[] = $row;
        }
    }

    $html = '<div class="card" style="margin-top:13px">';
    $html .= '<h2>本次总结</h2>';

    /* ---- 一句话结论 ---- */
    $n = count($qids);
    $c = count($right);
    if ($c === $n)      $verdict = '全对，非常棒！';
    elseif ($c >= $n * 0.8) $verdict = '表现不错，只有个别疏漏。';
    elseif ($c >= $n * 0.5) $verdict = '及格了，错的题再过一遍会更稳。';
    else                $verdict = '这次错的比较多，建议把解析看一遍。';
    $html .= '<p class="sub">答对 <b>' . $c . '</b> 题，答错 <b>' . count($wrong) . '</b> 题。' . e($verdict) . '</p>';

    /* ---- 答错的题（重点） ---- */
    if ($wrong) {
        $html .= '<h2 style="margin-top:14px;color:var(--no)">答错的题（' . count($wrong) . '）</h2>';
        $html .= '<div class="filelist">';
        foreach ($wrong as $w) {
            $html .= '<div class="fileitem" style="display:block">'
                   . '<div class="fname" style="white-space:normal;color:var(--no)">第 ' . $w['no'] . ' 题</div>'
                   . '<div style="font-size:13.5px;margin:5px 0 6px;line-height:1.6">' . e($w['q']) . '</div>'
                   . '<div class="fmeta">你选了：<span style="color:var(--no)">' . e($w['your']) . '</span></div>'
                   . '<div class="fmeta">正确答案：<span style="color:var(--ok)">' . e($w['ans']) . '</span></div>'
                   . '</div>';
        }
        $html .= '</div>';
    }

    /* ---- 答对的题 ---- */
    if ($right) {
        $html .= '<h2 style="margin-top:14px;color:var(--ok)">答对的题（' . count($right) . '）</h2>';
        $html .= '<div class="filelist">';
        foreach ($right as $r) {
            $gainTxt = $r['gain'] > 1 ? (' +' . $r['gain'] . ' 分（含连对加成）') : ' +1 分';
            $html .= '<div class="fileitem">'
                   . '<div class="info">'
                   . '<div class="fname" style="color:var(--ok)">第 ' . $r['no'] . ' 题' . e($gainTxt) . '</div>'
                   . '<div class="fmeta" style="white-space:normal">' . e($r['q']) . '</div>'
                   . '</div>'
                   . '<div class="acts"><span class="chip">' . e(fmt_ms($r['ms'])) . '</span></div>'
                   . '</div>';
        }
        $html .= '</div>';
    }

    /* ---- 排行榜变化 ---- */
    if ($delta) {
        $html .= '<h2 style="margin-top:14px">排行榜变化</h2>';
        $html .= '<div class="stat3">';

        // 分数
        $sb = (int)$delta['score_before'];
        $sa = (int)$delta['score_after'];
        $html .= '<div><b class="g">' . $sa . '</b><span>总分'
               . ($sa > $sb ? ' ↑+' . ($sa - $sb) : '') . '</span></div>';

        // 排名
        $rb = (int)$delta['rank_before'];
        $ra = (int)$delta['rank_after'];
        $rankVal = $ra > 0 ? ('第 ' . $ra) : '—';
        $rankSub = '名次';
        if ($rb > 0 && $ra < $rb)      $rankSub = '↑ 上升 ' . ($rb - $ra) . ' 名';
        elseif ($rb === 0 && $ra > 0)  $rankSub = '首次上榜';
        elseif ($rb > 0 && $ra > $rb)  $rankSub = '下降 ' . ($ra - $rb) . ' 名';
        $html .= '<div><b class="a">' . e($rankVal) . '</b><span>' . e($rankSub) . '</span></div>';

        // 在线时间
        $on = (int)($delta['online_after'] ?? 0);
        $html .= '<div><b class="o">' . e(fmt_duration($on)) . '</b><span>在线时间</span></div>';

        $html .= '</div>';

        if ((int)$delta['first_hits'] > 0) {
            $html .= '<p class="sub" style="margin:10px 0 0">本次有 <b>' . (int)$delta['first_hits']
                   . '</b> 道题是首次做对，单元进度已增加。</p>';
        }
    }

    $html .= '</div>';
    return $html;
}
