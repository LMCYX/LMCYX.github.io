<?php
/**
 * 页面合成器：每次操作都由 PHP 重新合成「整页」。
 *
 * 外观：统一的深色主题（不再使用 WebGL 液态玻璃）。
 */

declare(strict_types=1);

function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function state_fingerprint(array $state, array $user): string
{
    $s = $state['session'];
    $parts = [
        'ip'   => $state['ipkey'],
        'tok'  => $s['token'] ?? '',
        'done' => $s['done'] ?? 0,
        'act'  => $state['action'],
    ];
    return substr(hash('sha256', json_encode($parts)), 0, 16);
}

function render_page(array $state, array $user, Request $req): string
{
    $fp = state_fingerprint($state, $user);

    $body = match ($state['action']) {
        'start', 'starttest', 'submit', 'quit', 'daily', 'wrongredo', 'favredo'
                                  => render_practice($state, $user, $fp),
        'board'                   => render_board($state, $user, $fp),
        'wrong'                   => render_wrong($state, $user, $fp),
        'favs'                    => render_favs($state, $user, $fp),
        'trend'                   => render_trend($state, $user, $fp),
        'online'                  => render_online($state, $user, $fp),
        'stats'                   => render_stats($state, $user, $fp),
        'chat', 'chat_send'       => function_exists('render_chat')
                                        ? render_chat($state, $user, $fp)
                                        : render_home($state, $user, $fp),
        default                   => render_home($state, $user, $fp),
    };

    return render_shell($body, $state, $user, $fp);
}

/* ------------------------------------------------------------------ *
 *  外壳：统一的深色主题
 * ------------------------------------------------------------------ */
function render_shell(string $body, array $state, array $user, string $fp): string
{
    $jsonState = json_encode([
        'fp'    => $fp,
        'token' => $state['token'],
        'label' => $user['label'],
        'nick'  => (string)($user['nick'] ?? ''),
        'ip'    => (string)($user['ip'] ?? ''),
        // 首次进入强制设置昵称：服务端判断有没有昵称
        'need_nick' => trim((string)($user['nick'] ?? '')) === '',
    ], JSON_UNESCAPED_UNICODE);

    return <<<HTML
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0a0e1a">
<title></title>
<style>
:root{
  --bg:#0a0e1a;
  --bg2:#0f1526;
  --panel:rgba(255,255,255,.055);
  --panel2:rgba(255,255,255,.085);
  --line:rgba(255,255,255,.13);
  --line2:rgba(255,255,255,.22);
  --txt:#e8edf9;
  --txt2:#98a4c0;
  --txt3:#6d7994;
  --acc:#4d7cfe;
  --acc2:#6d94ff;
  --ok:#22c98a;
  --no:#ff5b6b;
  --warn:#ffb224;
  --gold:#ffd76e;
  --r:14px;
  --r2:11px;
}
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html{-webkit-text-size-adjust:100%}
body{
  font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Noto Sans CJK SC","Microsoft YaHei",system-ui,sans-serif;
  background:var(--bg);
  color:var(--txt);
  min-height:100vh;
  font-size:15px;
  line-height:1.6;
  overflow-x:hidden;
  padding-bottom:env(safe-area-inset-bottom);
  -webkit-font-smoothing:antialiased;
}
/* ================================================================
   炫彩背景（需求 2）
   ----------------------------------------------------------------
   做法：三层叠加，全部用 CSS（无 WebGL，兼容性与性能都稳）
     ① 底色：深蓝到近黑
     ② 流动色斑：多个大半径径向渐变 + 缓慢位移/缩放动画，
        叠加混合模式让颜色互相"发光"
     ③ 细网格：极淡的科技感纹理，避免大面积纯色发闷
   用 prefers-reduced-motion 尊重系统的"减弱动效"设置。
   ================================================================ */
body{
  background:
    radial-gradient(120vw 100vh at 50% 0%, #101a35 0%, #070b16 55%, #04060d 100%);
}
/* 色斑层 */
body::before{
  content:"";position:fixed;inset:-20%;z-index:0;pointer-events:none;
  background:
    radial-gradient(42vw 42vw at 14% 16%, rgba(88,132,255,.55), transparent 60%),
    radial-gradient(38vw 38vw at 86% 12%, rgba(196,86,255,.42), transparent 60%),
    radial-gradient(44vw 44vw at 78% 84%, rgba(34,220,180,.38), transparent 60%),
    radial-gradient(40vw 40vw at 20% 88%, rgba(255,120,90,.34), transparent 60%),
    radial-gradient(34vw 34vw at 50% 50%, rgba(120,90,255,.28), transparent 62%);
  filter:blur(38px) saturate(150%);
  animation:auroraSpin 34s linear infinite;
  will-change:transform;
}
/* 网格层 */
body::after{
  content:"";position:fixed;inset:0;z-index:0;pointer-events:none;
  background-image:
    linear-gradient(rgba(255,255,255,.030) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.030) 1px, transparent 1px);
  background-size:46px 46px;
  mask-image:radial-gradient(120vw 120vh at 50% 40%, #000 30%, transparent 85%);
  -webkit-mask-image:radial-gradient(120vw 120vh at 50% 40%, #000 30%, transparent 85%);
}
@keyframes auroraSpin{
  0%  {transform:rotate(0deg)   scale(1.0)}
  50% {transform:rotate(180deg) scale(1.14)}
  100%{transform:rotate(360deg) scale(1.0)}
}
@media(prefers-reduced-motion:reduce){
  body::before{animation:none}
}
.wrap{position:relative;z-index:2;max-width:860px;margin:0 auto;padding:14px 13px 44px}

/* ---------- 顶栏 ---------- */
header.top{
  display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;
  padding:11px 13px;margin-bottom:14px;
  background:var(--panel);border:1px solid var(--line);border-radius:var(--r);
  backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
}
.brand{font-weight:800;font-size:16px;letter-spacing:.2px;line-height:1.25}
.brand small{display:block;font-weight:500;font-size:11px;color:var(--txt2);letter-spacing:0;margin-top:1px}
.head-right{display:flex;gap:7px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
.chip{
  font-size:11.5px;padding:4px 9px;border-radius:999px;
  background:rgba(255,255,255,.06);border:1px solid var(--line);
  color:var(--txt2);white-space:nowrap;line-height:1.5;
}
.chip.hl{color:var(--gold);border-color:rgba(255,215,110,.34);background:rgba(255,215,110,.09)}

/* ---------- 导航 ---------- */
nav.tabs{display:flex;gap:6px;margin-bottom:14px;overflow-x:auto;padding-bottom:2px;scrollbar-width:none}
nav.tabs::-webkit-scrollbar{display:none}
/* 科目切换（首页） */
.subjnav{
  display:flex;gap:8px;margin-bottom:14px;overflow-x:auto;padding-bottom:2px;
  scrollbar-width:none;
}
.subjnav::-webkit-scrollbar{display:none}
.subjtab{
  flex:0 0 auto;display:flex;flex-direction:column;align-items:center;gap:1px;
  padding:10px 18px;border-radius:12px;text-decoration:none;
  font-size:14.5px;font-weight:700;color:var(--txt2);
  background:rgba(255,255,255,.05);border:1px solid var(--line);
  transition:.15s;min-width:82px;
}
.subjtab small{font-size:10.5px;font-weight:500;color:var(--txt3)}
.subjtab:hover{color:var(--txt);border-color:var(--line2);background:rgba(255,255,255,.09)}
.subjtab.on{
  color:#fff;background:linear-gradient(160deg,var(--acc),#3a63d8);
  border-color:transparent;box-shadow:0 4px 14px rgba(77,124,254,.34);
}
.subjtab.on small{color:rgba(255,255,255,.75)}

nav.tabs a{
  flex:0 0 auto;padding:9px 15px;border-radius:10px;text-decoration:none;
  font-size:13.5px;font-weight:600;color:var(--txt2);
  background:rgba(255,255,255,.045);border:1px solid var(--line);
  transition:.15s;
}
nav.tabs a:hover{color:var(--txt);border-color:var(--line2)}
nav.tabs a.on{color:#fff;background:linear-gradient(160deg,var(--acc),#3a63d8);border-color:transparent;
  box-shadow:0 3px 12px rgba(77,124,254,.32)}

/* ---------- 标题 ---------- */
h1{font-size:20px;font-weight:800;margin:4px 2px 13px;letter-spacing:.2px}
h2{font-size:15px;font-weight:700;margin:0 0 10px;display:flex;align-items:center;gap:7px}
h2::before{content:"";width:3px;height:14px;border-radius:2px;background:var(--acc)}
p.sub{color:var(--txt2);font-size:13px;line-height:1.75;margin:0 0 12px}

/* ---------- 卡片 ---------- */
.card{
  background:var(--panel);border:1px solid var(--line);border-radius:var(--r);
  padding:15px;margin-bottom:13px;
  backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
}

/* ---------- 单元网格 ---------- */
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(158px,1fr));gap:9px}
.unit{
  display:block;text-decoration:none;color:inherit;padding:12px 13px;
  border-radius:var(--r2);background:var(--panel2);border:1px solid var(--line);
  transition:.14s;position:relative;overflow:hidden;
}
.unit:hover{border-color:rgba(77,124,254,.55);background:rgba(77,124,254,.10);transform:translateY(-1px)}
.unit:active{transform:scale(.985)}
.unit .t{font-size:13.5px;font-weight:700;line-height:1.4}
.unit .m{font-size:11px;color:var(--txt2);margin-top:7px;display:flex;justify-content:space-between;gap:6px}
.bar{height:4px;border-radius:99px;background:rgba(255,255,255,.10);overflow:hidden;margin-top:8px}
.bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--acc),var(--ok));transition:width .3s}

/* ---------- 按钮 ---------- */
.btn{
  display:inline-flex;align-items:center;justify-content:center;gap:7px;
  padding:11px 18px;border-radius:var(--r2);border:1px solid transparent;
  background:linear-gradient(160deg,var(--acc),#3a63d8);color:#fff;
  font-size:14.5px;font-weight:700;cursor:pointer;text-decoration:none;
  transition:.14s;min-height:44px;font-family:inherit;
}
.btn:hover{filter:brightness(1.12)}
.btn:active{transform:scale(.975)}
.btn.ghost{background:rgba(255,255,255,.07);border-color:var(--line);color:var(--txt)}
.btn.ghost:hover{background:rgba(255,255,255,.12)}
.btn.danger{background:linear-gradient(160deg,#e8455a,#c23043)}
.btn.ok{background:linear-gradient(160deg,var(--ok),#18a06d)}
.btn:disabled,.btn[aria-disabled="true"]{opacity:.45;pointer-events:none}
.btn.big{width:100%;padding:14px;font-size:16px;min-height:50px}
.row{display:flex;gap:9px;flex-wrap:wrap;align-items:center}

/* ---------- 提示条 ---------- */
.notice{
  padding:10px 13px;border-radius:var(--r2);font-size:13px;margin-bottom:12px;
  background:rgba(255,178,36,.13);border:1px solid rgba(255,178,36,.34);color:#ffdfa0;
}
.notice.ok{background:rgba(34,201,138,.13);border-color:rgba(34,201,138,.34);color:#a9f0d2}
.notice.err{background:rgba(255,91,107,.13);border-color:rgba(255,91,107,.34);color:#ffc2c8}

/* ---------- 答题 ---------- */
.qlist{display:flex;flex-direction:column;gap:13px}
.qcard{
  background:var(--panel);border:1px solid var(--line);border-radius:var(--r);
  padding:14px;
}
.qhead{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:9px}
.qno{
  font-size:12px;font-weight:800;color:#fff;background:linear-gradient(160deg,var(--acc),#3a63d8);
  padding:3px 9px;border-radius:8px;
}
.qtimer{font-size:11.5px;color:var(--txt3);font-variant-numeric:tabular-nums}
.qtext{font-size:15.5px;line-height:1.68;font-weight:600;margin-bottom:12px}
.opt{
  display:flex;gap:10px;align-items:flex-start;width:100%;text-align:left;
  padding:11px 13px;margin-bottom:7px;border-radius:var(--r2);
  background:rgba(255,255,255,.045);border:1px solid var(--line);
  color:var(--txt);font-size:14.5px;line-height:1.55;cursor:pointer;
  transition:.12s;font-family:inherit;
}
.opt:hover{border-color:rgba(77,124,254,.55);background:rgba(77,124,254,.10)}
.opt:active{transform:scale(.99)}
.opt .k{
  flex:0 0 23px;height:23px;border-radius:7px;display:grid;place-items:center;
  background:rgba(255,255,255,.12);font-weight:800;font-size:12.5px;margin-top:1px;
}
.opt.sel{background:rgba(77,124,254,.20);border-color:var(--acc);}
.opt.sel .k{background:var(--acc);color:#fff}
.opt.right{background:rgba(34,201,138,.17);border-color:rgba(34,201,138,.7)}
.opt.right .k{background:var(--ok);color:#04160e}
.opt.wrong{background:rgba(255,91,107,.15);border-color:rgba(255,91,107,.65)}
.opt.wrong .k{background:var(--no);color:#fff}
.exp{
  margin-top:10px;padding:11px 13px;border-radius:var(--r2);font-size:13px;line-height:1.75;
  background:rgba(255,255,255,.05);border-left:3px solid var(--acc);color:#cfd8ef;
}
.tag{font-weight:800;margin-right:5px}
.tag.ok{color:var(--ok)} .tag.no{color:var(--no)}

/* ---------- 提交栏 ---------- */
/* 顶部计时条：吸顶，做题时一直能看到总用时 */
.timerbar{
  position:sticky;top:0;z-index:12;margin-bottom:12px;
  display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;
  padding:10px 13px;border-radius:var(--r);
  background:rgba(15,21,38,.92);border:1px solid var(--line2);
  backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
  box-shadow:0 4px 20px rgba(0,0,0,.35);
}
.timerbar .tleft{display:flex;gap:7px;align-items:center;flex-wrap:wrap}
.timerbar .ttotal{display:flex;align-items:baseline;gap:7px;font-size:12px;color:var(--txt2)}
.timerbar .ttotal b{
  font-size:19px;font-variant-numeric:tabular-nums;color:var(--acc2);
  letter-spacing:.5px;min-width:62px;text-align:right;
}

.submitbar{
  position:sticky;bottom:10px;z-index:10;margin-top:14px;
  background:rgba(15,21,38,.94);border:1px solid var(--line2);border-radius:var(--r);
  padding:11px 13px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
  display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;
  box-shadow:0 -4px 22px rgba(0,0,0,.4);
}
.submitbar .stat{font-size:13px;color:var(--txt2)}
.submitbar .stat b{color:var(--txt);font-size:15px}

/* ---------- 表格 ---------- */
table{width:100%;border-collapse:collapse;font-size:13.5px}
th,td{padding:9px 7px;text-align:left;border-bottom:1px solid rgba(255,255,255,.08)}
th{color:var(--txt2);font-weight:600;font-size:11.5px;white-space:nowrap}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
tr.me{background:rgba(77,124,254,.13)}
tbody tr:hover{background:rgba(255,255,255,.035)}
.rank{font-weight:800;font-variant-numeric:tabular-nums}
.rank.g{color:var(--gold)} .rank.s{color:#d5ddf0} .rank.b{color:#e0a077}
.empty{padding:26px 10px;text-align:center;color:var(--txt3);font-size:13.5px;line-height:1.9}

/* ---------- 统计块 ---------- */
.stat3{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;text-align:center;margin:5px 0 13px}
.stat3 div{padding:12px 6px;border-radius:var(--r2);background:var(--panel2);border:1px solid var(--line)}
.stat3 b{display:block;font-size:20px;font-variant-numeric:tabular-nums;margin-bottom:2px;line-height:1.3}
.stat3 span{font-size:11px;color:var(--txt2)}
.stat3 .g{color:var(--gold)} .stat3 .o{color:var(--ok)} .stat3 .a{color:var(--acc2)}

/* ---------- 聊天室 ---------- */
.chatbox{display:flex;flex-direction:column;height:min(60vh,520px);gap:10px}
.chatlist{
  flex:1;overflow-y:auto;padding:12px;border-radius:var(--r2);
  background:rgba(0,0,0,.22);border:1px solid var(--line);
  display:flex;flex-direction:column;gap:9px;overscroll-behavior:contain;
}
.msg{max-width:86%;padding:8px 12px;border-radius:12px;font-size:14px;line-height:1.6;word-break:break-word}
.msg .who{font-size:11px;color:var(--txt3);margin-bottom:3px}
.msg .tm{font-size:10.5px;color:var(--txt3);margin-top:3px;text-align:right}
.msg.other{background:rgba(255,255,255,.07);border:1px solid var(--line);align-self:flex-start}
.msg.mine{background:linear-gradient(160deg,rgba(77,124,254,.34),rgba(58,99,216,.24));
  border:1px solid rgba(77,124,254,.44);align-self:flex-end}
/* 聊天室：文件卡片 */
.chatfile{
  display:flex;flex-direction:column;gap:2px;
  margin-top:6px;padding:9px 12px;border-radius:10px;
  background:rgba(77,124,254,.20);border:1px solid rgba(77,124,254,.42);
  text-decoration:none;color:inherit;transition:.13s;
}
.chatfile:hover{background:rgba(77,124,254,.30);border-color:var(--acc)}
.chatfile .fname{font-size:13.5px;font-weight:700;word-break:break-all}
.chatfile .fmeta{font-size:11px;color:var(--txt2)}
.chattext{margin-top:4px;word-break:break-word}
/* 聊天室：附件操作条 */
.chatattach{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.chatattach input[type=file]{flex:1;min-width:0}

.chatinput{display:flex;gap:8px}
.chatinput input{
  flex:1;padding:11px 13px;border-radius:var(--r2);border:1px solid var(--line);
  background:rgba(255,255,255,.05);color:var(--txt);font-size:14.5px;font-family:inherit;min-width:0;
}
.chatinput input:focus{outline:none;border-color:var(--acc);background:rgba(77,124,254,.09)}

/* ---------- 云盘 ---------- */
.filelist{display:flex;flex-direction:column;gap:8px}
.fileitem{
  display:flex;align-items:center;gap:10px;padding:11px 12px;border-radius:var(--r2);
  background:var(--panel2);border:1px solid var(--line);
}
.fileitem .info{flex:1;min-width:0}
.fileitem .fname{font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fileitem .fmeta{font-size:11.5px;color:var(--txt2);margin-top:2px}
.fileitem .acts{display:flex;gap:6px;flex:0 0 auto}

/* ---------- 输入 ---------- */
input[type=text],input[type=file],select{
  font-family:inherit;font-size:14px;color:var(--txt);
  background:rgba(255,255,255,.05);border:1px solid var(--line);
  border-radius:var(--r2);padding:10px 12px;
}
input[type=text]:focus,select:focus{outline:none;border-color:var(--acc)}
input[type=file]{padding:8px;font-size:13px;width:100%}

/* ---------- 遮罩 / 提示 ---------- */
.boot{position:fixed;inset:0;z-index:99;display:grid;place-items:center;
  background:var(--bg);font-size:14px;color:var(--txt2);transition:opacity .3s}
.boot.hide{opacity:0;pointer-events:none}
@keyframes bootAutoHide{to{opacity:0;visibility:hidden}}
.boot{animation:bootAutoHide .3s ease 1.2s forwards}
#busy{position:fixed;inset:0;z-index:80;background:rgba(4,7,14,.42);
  backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px)}
/* 昵称编辑弹层 */
.nickmask{
  position:fixed;inset:0;z-index:150;display:grid;place-items:center;padding:20px;
  background:rgba(4,7,14,.72);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);
}
.nickmask[hidden]{display:none}
.nickbox{
  width:100%;max-width:380px;padding:18px;border-radius:var(--r);
  background:rgba(18,24,42,.98);border:1px solid var(--line2);
  box-shadow:0 12px 40px rgba(0,0,0,.55);
}
.nickbox input{width:100%}
.chip.nickbtn{cursor:pointer;border-color:rgba(77,124,254,.45);color:var(--acc2)}
.chip.nickbtn:hover{background:rgba(77,124,254,.16)}

/* 背景 canvas：铺满，在所有内容之下 */
#bgcanvas{position:fixed;inset:0;z-index:0;display:block;pointer-events:none}

/* 音乐播放器：右下角圆形按钮 */
.musicbox{
  position:fixed;right:16px;bottom:calc(18px + env(safe-area-inset-bottom));
  z-index:60;display:flex;align-items:center;gap:8px;
  padding:8px 10px;border-radius:999px;
  background:rgba(15,21,38,.86);border:1px solid var(--line2);
  backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
  box-shadow:0 6px 22px rgba(0,0,0,.45);
}
.musicbox[hidden]{display:none}
#musicbtn{
  width:38px;height:38px;border-radius:50%;border:none;cursor:pointer;
  display:grid;place-items:center;color:#fff;
  background:linear-gradient(160deg,var(--acc),#3a63d8);
  transition:transform .12s,filter .12s;
}
#musicbtn:active{transform:scale(.94)}
#musicbtn .mi-off{display:none}
#musicbtn[data-on="1"] .mi-play{display:none}
#musicbtn[data-on="1"] .mi-off{display:block}
.mwave{display:flex;align-items:flex-end;gap:2px;height:16px}
.mwave i{width:3px;border-radius:2px;background:var(--acc2);opacity:.35;height:4px}
#musicbtn[data-on="1"] ~ .mwave i{opacity:1;animation:mw .9s ease-in-out infinite}
.mwave i:nth-child(2){animation-delay:.15s}
.mwave i:nth-child(3){animation-delay:.3s}
.mwave i:nth-child(4){animation-delay:.45s}
@keyframes mw{0%,100%{height:4px}50%{height:15px}}
@media(prefers-reduced-motion:reduce){.mwave i{animation:none!important}}

/* ==================================================================
   扩展功能的样式（错题本 / 收藏 / 成绩 / 在线 / 统计 / 每日一练）
   ================================================================== */

/* ---- 导航：标签多了，允许横向滚动，不换行挤成一团 ---- */
.tabs{display:flex;gap:6px;overflow-x:auto;padding:0 0 10px;
  -webkit-overflow-scrolling:touch;scrollbar-width:none}
.tabs::-webkit-scrollbar{display:none}
.tabs a{flex:0 0 auto;padding:7px 13px;border-radius:999px;font-size:13px;
  color:var(--txt2);background:rgba(255,255,255,.05);
  border:1px solid transparent;text-decoration:none;white-space:nowrap}
.tabs a.on{color:#fff;background:linear-gradient(160deg,var(--acc),#3a63d8);
  border-color:transparent;font-weight:600}

/* ---- 标题里的计数徽标 ---- */
.cnt{font-size:12px;font-weight:600;color:var(--txt2);
  background:rgba(255,255,255,.08);padding:2px 9px;border-radius:999px;
  margin-left:6px;vertical-align:middle}

/* ---- 学科小标签 ---- */
.schip{display:inline-block;font-size:10.5px;font-weight:700;padding:2px 7px;
  border-radius:6px;margin-right:7px;vertical-align:middle}
.schip.phy{color:#8fb0ff;background:rgba(77,124,254,.18)}
.schip.bio{color:#6ee7b7;background:rgba(34,201,138,.16)}
.schip.mor{color:#fbbf6e;background:rgba(251,146,60,.16)}
.schip.inter{color:#e0a9ff;background:rgba(192,109,255,.16)}

/* ---- 错题本 / 收藏 列表 ---- */
.wlist{display:flex;flex-direction:column;gap:9px}
.witem{background:var(--panel);border:1px solid var(--line);border-radius:12px;
  padding:11px 12px}
.wtop{display:flex;align-items:center;gap:6px;margin-bottom:7px;flex-wrap:wrap}
.wunit{font-size:12px;color:var(--txt2);flex:1;min-width:0;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.wn{font-size:11px;font-weight:700;color:var(--no);
  background:rgba(255,91,107,.14);padding:2px 7px;border-radius:6px}
.wq{font-size:13.5px;line-height:1.55;color:var(--txt);
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.wacts{display:flex;gap:8px;margin-top:9px}
.btn.tiny{padding:4px 11px;font-size:12px;border-radius:8px;flex:0 0 auto}

/* ---- 每日一练卡片 ---- */
.dailycard{display:flex;align-items:center;gap:12px;
  background:linear-gradient(135deg,rgba(77,124,254,.20),rgba(109,148,255,.07));
  border:1px solid rgba(109,148,255,.34);border-radius:14px;
  padding:13px 15px;margin-bottom:14px}
.dleft{flex:1;min-width:0}
.dtitle{font-size:14.5px;font-weight:800;letter-spacing:.3px}
.dsub{font-size:11.5px;color:var(--txt2);margin-top:3px}
.dsub b{color:var(--acc2)}

/* ---- 统计格子 ---- */
.stat4{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:12px 0}
.statgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:12px 0}
.stat4>div,.statgrid>div{background:var(--panel);border:1px solid var(--line);
  border-radius:11px;padding:10px 6px;text-align:center}
.stat4 b,.statgrid b{display:block;font-size:17px;font-weight:800;line-height:1.2}
.stat4 span,.statgrid span{display:block;font-size:10.5px;color:var(--txt2);margin-top:3px}
.stat4 b.g,.statgrid b.g{color:var(--ok)}
.stat4 b.a,.statgrid b.a{color:var(--acc2)}
.stat4 b.o,.statgrid b.o{color:#fbbf6e}
@media(max-width:420px){.stat4,.statgrid{grid-template-columns:repeat(2,1fr)}}

/* ---- 折线图容器 ---- */
.chartwrap{background:var(--panel);border:1px solid var(--line);
  border-radius:12px;padding:8px 6px 4px;margin-top:12px}
.chartwrap canvas{display:block;width:100%}

/* ---- 在线列表 ---- */
.oline{display:flex;align-items:center;gap:9px;padding:9px 2px;
  border-bottom:1px solid var(--line)}
.oline:last-child{border-bottom:none}
.dot{width:8px;height:8px;border-radius:50%;background:var(--txt3);flex:0 0 auto}
.dot.on{background:var(--ok);box-shadow:0 0 7px rgba(34,201,138,.85)}
.oname{font-size:13.5px;font-weight:600;flex:1;min-width:0;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.oip{font-size:11px;color:var(--txt3);flex:0 0 auto}
.oago{font-size:11px;color:var(--txt2);flex:0 0 auto;min-width:52px;text-align:right}

/* ---- 热门单元条形 ---- */
.hotlist{display:flex;flex-direction:column;gap:8px;margin-top:10px}
.hotrow{display:flex;align-items:center;gap:9px}
.hotname{font-size:12.5px;flex:0 0 38%;min-width:0;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--txt2)}
.hotbar{flex:1;height:7px;border-radius:999px;background:rgba(255,255,255,.07);
  overflow:hidden}
.hotbar i{display:block;height:100%;border-radius:999px;
  background:linear-gradient(90deg,var(--acc),var(--acc2))}
.hotn{font-size:11.5px;color:var(--txt3);flex:0 0 auto;min-width:22px;text-align:right}


/* ---- 折叠说明 ---- */
.howto{margin-top:16px;background:var(--panel);border:1px solid var(--line);
  border-radius:12px;padding:0 13px}
.howto summary{cursor:pointer;padding:11px 0;font-size:13.5px;font-weight:600;
  list-style:none}
.howto summary::-webkit-details-marker{display:none}
.howto summary::before{content:'▸ ';color:var(--acc2)}
.howto[open] summary::before{content:'▾ '}
.howto p{font-size:12.5px;color:var(--txt2);line-height:1.65;margin:6px 0}
.howto ul{margin:6px 0 12px;padding-left:19px}
.howto li{font-size:12.5px;color:var(--txt2);line-height:1.7;margin-bottom:3px}
.howto code{background:rgba(255,255,255,.09);padding:1px 5px;border-radius:4px;
  font-size:11.5px;color:var(--acc2)}
.howto pre{background:rgba(0,0,0,.36);border:1px solid var(--line);border-radius:9px;
  padding:11px;overflow-x:auto;font-size:11px;line-height:1.55;color:#cfe0ff;
  margin:8px 0;white-space:pre}

/* ---- 首页快捷入口 ---- */
.quickrow{display:grid;grid-template-columns:repeat(2,1fr);gap:9px;margin-bottom:14px}
.qk{display:flex;align-items:center;gap:10px;padding:11px 13px;border-radius:12px;
  text-decoration:none;border:1px solid var(--line);background:var(--panel)}
.qk b{font-size:19px;font-weight:800;line-height:1}
.qk span{font-size:12px;color:var(--txt2)}
.qk.no{border-color:rgba(255,91,107,.34);background:rgba(255,91,107,.09)}
.qk.no b{color:var(--no)}
.qk.fav{border-color:rgba(251,191,110,.32);background:rgba(251,146,60,.08)}
.qk.fav b{color:#fbbf6e}

/* ---- 首页实时小条 ---- */
.metaline{display:flex;flex-wrap:wrap;gap:7px 14px;margin:2px 0 14px;
  font-size:11.5px;color:var(--txt3)}
.metaline .dot{display:inline-block;vertical-align:middle;margin-right:2px}

/* ---- 跨单元练习时的来源单元标记 ---- */
.qfrom{font-size:10.5px;font-weight:500;color:var(--txt3);
  background:rgba(255,255,255,.07);padding:2px 7px;border-radius:5px;margin-left:5px}

/* ---- 收藏按钮（题目右上角） ---- */
.qcard{position:relative}
.favstar{position:absolute;top:9px;right:10px;width:28px;height:28px;
  display:grid;place-items:center;border:none;background:transparent;
  color:var(--txt3);cursor:pointer;font-size:16px;line-height:1;
  border-radius:8px;transition:color .15s,transform .12s}
.favstar:hover{color:#fbbf6e}
.favstar:active{transform:scale(.9)}
.favstar.on{color:#fbbf6e}

/* 练习页顶栏：返回 + 标题 + 计时 */
.pracbar{
  position:sticky;top:0;z-index:12;margin-bottom:12px;
  display:flex;align-items:center;gap:10px;
  padding:9px 11px;border-radius:var(--r);
  background:rgba(15,21,38,.92);border:1px solid var(--line2);
  backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
  box-shadow:0 4px 20px rgba(0,0,0,.35);
}
.pracbar .backbtn{padding:8px 12px;min-height:38px;font-size:13.5px;flex:0 0 auto}
.practitle{flex:1;min-width:0;font-size:14.5px;font-weight:700;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ptag{display:inline-block;margin-left:8px;padding:2px 8px;border-radius:7px;
  font-size:11px;font-weight:700;background:rgba(255,255,255,.12);color:var(--txt2)}
.ptag.test{background:rgba(255,178,36,.2);color:#ffd76e}
.pracbar .ttotal{font-size:16px;font-weight:800;color:var(--acc2);
  font-variant-numeric:tabular-nums;flex:0 0 auto}

/* 单元卡片：两个操作按钮 */
.unitcard{
  padding:12px 13px;border-radius:var(--r2);
  background:var(--panel2);border:1px solid var(--line);transition:.14s;
}
.unitcard:hover{border-color:rgba(77,124,254,.5)}
.unitacts{display:flex;gap:6px;margin-top:9px}
.mini{
  flex:1;text-align:center;padding:7px 4px;border-radius:9px;text-decoration:none;
  font-size:12px;font-weight:700;color:var(--txt);
  background:rgba(255,255,255,.08);border:1px solid var(--line);transition:.12s;
}
.mini:hover{background:rgba(77,124,254,.18);border-color:rgba(77,124,254,.5)}
.mini.test{background:rgba(255,178,36,.14);border-color:rgba(255,178,36,.4);color:#ffd76e}
.mini.test:hover{background:rgba(255,178,36,.24)}

/* 排行榜 4 个切换 */
.boardnav{display:flex;gap:6px;margin-bottom:12px;overflow-x:auto;scrollbar-width:none}
.boardnav::-webkit-scrollbar{display:none}
.boardtab{
  flex:0 0 auto;padding:9px 16px;border-radius:10px;text-decoration:none;
  font-size:13.5px;font-weight:700;color:var(--txt2);
  background:rgba(255,255,255,.05);border:1px solid var(--line);transition:.14s;
}
.boardtab:hover{color:var(--txt)}
.boardtab.on{color:#fff;background:linear-gradient(160deg,var(--acc),#3a63d8);border-color:transparent}

/* 页面切换动画：左右滑动 */
@keyframes slideInR{from{opacity:0;transform:translateX(26px)}to{opacity:1;transform:none}}
@keyframes slideInL{from{opacity:0;transform:translateX(-26px)}to{opacity:1;transform:none}}
.slide-r{animation:slideInR .26s cubic-bezier(.22,.7,.3,1) both}
.slide-l{animation:slideInL .26s cubic-bezier(.22,.7,.3,1) both}
/* 题目卡片逐个淡入 */
@keyframes cardIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.qlist > .qcard{animation:cardIn .3s ease both}
.qlist > .qcard:nth-child(2){animation-delay:.04s}
.qlist > .qcard:nth-child(3){animation-delay:.08s}
.qlist > .qcard:nth-child(4){animation-delay:.12s}
.qlist > .qcard:nth-child(5){animation-delay:.16s}
@media(prefers-reduced-motion:reduce){
  .slide-r,.slide-l,.qlist > .qcard{animation:none!important}
}

/* 选项选中动画 */
.opt{transition:transform .12s,background .14s,border-color .14s}
.opt.sel{animation:selPop .18s ease}
@keyframes selPop{0%{transform:scale(1)}50%{transform:scale(1.015)}100%{transform:scale(1)}}

/* 昵称弹层的输入框 */
.nickbox input{
  width:100%;padding:12px 13px;border-radius:var(--r2);
  border:1px solid var(--line);background:rgba(255,255,255,.06);
  color:var(--txt);font-size:16px;font-family:inherit;
}
.nickbox input:focus{outline:none;border-color:var(--acc);background:rgba(77,124,254,.1)}

.toast{
  position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:120;
  padding:10px 17px;border-radius:var(--r2);background:rgba(18,24,42,.97);
  border:1px solid var(--line2);font-size:13px;color:var(--txt);
  opacity:0;transition:opacity .25s;pointer-events:none;max-width:88vw;text-align:center;
  box-shadow:0 6px 24px rgba(0,0,0,.5);
}
.toast.show{opacity:1}

@media(max-width:430px){
  .wrap{padding:11px 10px 38px}
  h1{font-size:18px}
  .qtext{font-size:15px}
  .grid{grid-template-columns:repeat(auto-fill,minmax(140px,1fr))}
  header.top{padding:10px 11px}
  .brand{font-size:15px}
}
</style>
</head>
<body>
<div class="boot" id="boot">正在载入…</div>
<canvas id="bgcanvas"></canvas>
<div class="wrap" id="root">
{$body}
</div>

<!-- 音乐播放器（没有音乐文件时自动隐藏） -->
<!-- 音乐：只有播放/未播放两种状态，没有暂停（见 music.js 顶部说明） -->
<div class="musicbox" id="musicbox" hidden>
  <button id="musicbtn" type="button" data-on="0" aria-label="点击播放音乐">
    <svg class="mi-play" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
    <svg class="mi-off" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><circle cx="12" cy="12" r="5.2"/></svg>
  </button>
  <span class="mwave"><i></i><i></i><i></i><i></i></span>
</div>

<div class="toast" id="toast"></div>

<!-- 昵称编辑弹层（默认隐藏，点顶栏昵称时弹出） -->
<div class="nickmask" id="nickmodal" hidden>
  <div class="nickbox">
    <h2>设置昵称</h2>
    <p class="sub" style="margin-bottom:10px" id="nicktip0">你的身份由访问 IP 确定；昵称只是显示名，可以随时改。</p>
    <p class="notice" id="nicktip" style="display:none;margin-bottom:10px">请先设置昵称再开始使用。</p>
    <input type="text" id="nickinput" maxlength="16" placeholder="输入昵称（最多 16 字）" autocomplete="off">
    <div class="row" style="margin-top:12px;justify-content:flex-end">
      <a class="btn ghost" href="#" data-act="nickcancel">取消</a>
      <a class="btn" href="#" data-act="nicksave">保存</a>
    </div>
  </div>
</div>
<script id="state" type="application/json">{$jsonState}</script>
<script>
window.__S = JSON.parse(document.getElementById('state').textContent);
</script>
<script src="/trend.js"></script>
<script src="/bg.js"></script>
<script src="/music.js"></script>
<script src="/client.js"></script>
</body>
</html>
HTML;
}
