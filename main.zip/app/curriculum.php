<?php
/**
 * 课程结构：支持多科目（物理 / 生物学 / 道德与法治）
 *
 * 单元 id 一律带科目前缀，例如：
 *     phy-1-1   物理 第1章第1节
 *     bio-12-1  生物 第12章第1节
 *     mor-1-1   道法 第一课第1节
 *
 * 题库文件：app/units/<unit-id>.php
 */

declare(strict_types=1);

/** 网站总名称（改这里就能改全站标题） */
const SITE_NAME  = '学科练习';
const SITE_SUB   = '八年级 · 物理 / 生物 / 道法';

/**
 * 科目定义。
 *   key   科目代号（也是 unit id 的前缀）
 *   name  科目全名
 *   short 导航上显示的短名
 */
function subjects(): array
{
    static $s = null;
    if ($s !== null) return $s;
    $s = [
        'phy' => ['name' => '物理',       'short' => '物理',   'full' => '八年级物理（上册）'],
        'bio' => ['name' => '生物学',     'short' => '生物',   'full' => '八年级生物学'],
        'mor' => ['name' => '道德与法治', 'short' => '道法',   'full' => '八年级道德与法治（上册）'],
        'inter' => ['name' => '跨学科实践', 'short' => '跨学科', 'full' => '跨学科实践'],
    ];
    return $s;
}

function subject_of(string $unitId): string
{
    $p = explode('-', $unitId)[0];
    return isset(subjects()[$p]) ? $p : 'phy';
}

function subject_name(string $key, bool $short = false): string
{
    $s = subjects()[$key] ?? null;
    if ($s === null) return $key;
    return $short ? $s['short'] : $s['name'];
}

/**
 * 全部课程结构：科目 → 章 → 小节
 *
 * 返回：
 *   [
 *     'phy' => [
 *        'chapters' => [
 *           '1' => ['name'=>'第1章 测量', 'no'=>1, 'subs'=>['phy-1-1'=>[...]]],
 *           ...
 *        ],
 *     ],
 *     ...
 *   ]
 */
function curriculum(): array
{
    static $c = null;
    if ($c !== null) return $c;

    $c = [
        /* ================= 物理 ================= */
        'phy' => [
            '1' => ['name' => '第1章 测量', 'no' => 1, 'subs' => [
                'phy-1-1' => ['no' => 1, 'name' => '第1节 长度的测量', 'page' => 8],
                'phy-1-2' => ['no' => 2, 'name' => '第2节 时间的测量', 'page' => 15],
                'phy-1-3' => ['no' => 3, 'name' => '第3节 质量的测量', 'page' => 20],
            ]],
            '2' => ['name' => '第2章 机械运动', 'no' => 2, 'subs' => [
                'phy-2-1' => ['no' => 1, 'name' => '第1节 运动与静止', 'page' => 31],
                'phy-2-2' => ['no' => 2, 'name' => '第2节 运动的快慢', 'page' => 35],
                'phy-2-3' => ['no' => 3, 'name' => '第3节 速度的测量', 'page' => 40],
            ]],
            '3' => ['name' => '第3章 声现象', 'no' => 3, 'subs' => [
                'phy-3-1' => ['no' => 1, 'name' => '第1节 声音的产生和传播', 'page' => 48],
                'phy-3-2' => ['no' => 2, 'name' => '第2节 声音的特性', 'page' => 54],
                'phy-3-3' => ['no' => 3, 'name' => '第3节 声波的应用和控制', 'page' => 61],
            ]],
            '4' => ['name' => '第4章 光现象', 'no' => 4, 'subs' => [
                'phy-4-1' => ['no' => 1, 'name' => '第1节 光的反射', 'page' => 73],
                'phy-4-2' => ['no' => 2, 'name' => '第2节 平面镜成像', 'page' => 82],
                'phy-4-3' => ['no' => 3, 'name' => '第3节 光的折射', 'page' => 89],
                'phy-4-4' => ['no' => 4, 'name' => '第4节 凸透镜成像', 'page' => 95],
                'phy-4-5' => ['no' => 5, 'name' => '第5节 透镜的应用', 'page' => 103],
            ]],
            '5' => ['name' => '第5章 运动和力', 'no' => 5, 'subs' => [
                'phy-5-1' => ['no' => 1, 'name' => '第1节 力', 'page' => 115],
                'phy-5-2' => ['no' => 2, 'name' => '第2节 弹力 重力', 'page' => 120],
                'phy-5-3' => ['no' => 3, 'name' => '第3节 二力合成 二力平衡', 'page' => 126],
                'phy-5-4' => ['no' => 4, 'name' => '第4节 摩擦力', 'page' => 132],
                'phy-5-5' => ['no' => 5, 'name' => '第5节 牛顿第一定律', 'page' => 137],
            ]],
        ],

        /* ================= 跨学科实践 ================= */
        'inter' => [
            '1' => ['name' => '跨学科实践', 'no' => 1, 'subs' => [
                'inter-1-1' => ['no' => 1, 'name' => '体质的测量与评价', 'page' => 25],
                'inter-1-2' => ['no' => 2, 'name' => '简单乐器的制作', 'page' => 66],
            ]],
        ],

        /* ================= 生物 ================= */
        'bio' => [
            '12' => ['name' => '第12章 消化系统与营养摄取', 'no' => 12, 'subs' => [
                'bio-12-1' => ['no' => 1, 'name' => '第1节 食物中的营养物质', 'page' => 4],
                'bio-12-2' => ['no' => 2, 'name' => '第2节 食物的消化和吸收', 'page' => 11],
            ]],
            '13' => ['name' => '第13章 血液循环系统与物质运输', 'no' => 13, 'subs' => [
                'bio-13-1' => ['no' => 1, 'name' => '第1节 血液的组成和功能', 'page' => 24],
                'bio-13-2' => ['no' => 2, 'name' => '第2节 血管与心脏', 'page' => 30],
                'bio-13-3' => ['no' => 3, 'name' => '第3节 血液循环与物质运输', 'page' => 37],
            ]],
            '14' => ['name' => '第14章 呼吸系统与气体交换', 'no' => 14, 'subs' => [
                'bio-14-1' => ['no' => 1, 'name' => '第1节 呼吸与呼吸系统', 'page' => 44],
                'bio-14-2' => ['no' => 2, 'name' => '第2节 呼吸运动与气体交换', 'page' => 50],
            ]],
            '15' => ['name' => '第15章 泌尿系统与废物排泄', 'no' => 15, 'subs' => [
                'bio-15-1' => ['no' => 1, 'name' => '第1节 泌尿系统的结构', 'page' => 60],
                'bio-15-2' => ['no' => 2, 'name' => '第2节 代谢产物的排泄', 'page' => 65],
            ]],
            '16' => ['name' => '第16章 神经系统与神经调节', 'no' => 16, 'subs' => [
                'bio-16-1' => ['no' => 1, 'name' => '第1节 神经系统的组成', 'page' => 76],
                'bio-16-2' => ['no' => 2, 'name' => '第2节 神经系统与人体运动', 'page' => 83],
                'bio-16-3' => ['no' => 3, 'name' => '第3节 人体主要的感覚器官', 'page' => 87],
            ]],
            '17' => ['name' => '第17章 内分泌系统与激素调节', 'no' => 17, 'subs' => [
                'bio-17-1' => ['no' => 1, 'name' => '第1节 人体的激素', 'page' => 98],
                'bio-17-2' => ['no' => 2, 'name' => '第2节 性激素与青春期', 'page' => 106],
            ]],
            '18' => ['name' => '第18章 免疫系统与免疫防御', 'no' => 18, 'subs' => [
                'bio-18-1' => ['no' => 1, 'name' => '第1节 人体的三道防线', 'page' => 116],
                'bio-18-2' => ['no' => 2, 'name' => '第2节 疫苗与免疫', 'page' => 124],
            ]],
        ],

        /* ================= 道德与法治 ================= */
        'mor' => [
            '1' => ['name' => '第一单元 走进社会生活', 'no' => 1, 'subs' => [
                'mor-1-1' => ['no' => 1, 'name' => '第一课·认识社会生活', 'page' => 2],
                'mor-1-2' => ['no' => 2, 'name' => '第一课·我们都是社会的一员', 'page' => 6],
                'mor-2-1' => ['no' => 3, 'name' => '第二课·人的社会化', 'page' => 9],
                'mor-2-2' => ['no' => 4, 'name' => '第二课·养成亲社会行为', 'page' => 12],
                'mor-3-1' => ['no' => 5, 'name' => '第三课·网络改变世界', 'page' => 16],
                'mor-3-2' => ['no' => 6, 'name' => '第三课·营造清朗空间', 'page' => 19],
            ]],
            '2' => ['name' => '第二单元 维护社会秩序', 'no' => 2, 'subs' => [
                'mor-4-1' => ['no' => 1, 'name' => '第四课·维护秩序靠规则', 'page' => 26],
                'mor-4-2' => ['no' => 2, 'name' => '第四课·遵守规则', 'page' => 29],
                'mor-5-1' => ['no' => 3, 'name' => '第五课·文明有礼', 'page' => 34],
                'mor-5-2' => ['no' => 4, 'name' => '第五课·诚实守信', 'page' => 38],
                'mor-5-3' => ['no' => 5, 'name' => '第五课·友善待人', 'page' => 42],
                'mor-6-1' => ['no' => 6, 'name' => '第六课·树立法治观念', 'page' => 46],
                'mor-6-2' => ['no' => 7, 'name' => '第六课·学会依法办事', 'page' => 49],
            ]],
            '3' => ['name' => '第三单元 勇担社会责任', 'no' => 3, 'subs' => [
                'mor-7-1' => ['no' => 1, 'name' => '第七课·珍视自由', 'page' => 58],
                'mor-7-2' => ['no' => 2, 'name' => '第七课·践行平等', 'page' => 61],
                'mor-8-1' => ['no' => 3, 'name' => '第八课·坚守公平', 'page' => 66],
                'mor-8-2' => ['no' => 4, 'name' => '第八课·守护正义', 'page' => 70],
                'mor-9-1' => ['no' => 5, 'name' => '第九课·社会责任我担当', 'page' => 75],
                'mor-9-2' => ['no' => 6, 'name' => '第九课·奉献社会我践行', 'page' => 79],
            ]],
            '4' => ['name' => '第四单元 维护国家利益', 'no' => 4, 'subs' => [
                'mor-10-1' => ['no' => 1, 'name' => '第十课·国家利益高于一切', 'page' => 86],
                'mor-10-2' => ['no' => 2, 'name' => '第十课·捍卫国家利益', 'page' => 90],
                'mor-11-1' => ['no' => 3, 'name' => '第十一课·党和人民信赖的英雄军队', 'page' => 94],
                'mor-11-2' => ['no' => 4, 'name' => '第十一课·全面推进国防和军队现代化', 'page' => 97],
                'mor-12-1' => ['no' => 5, 'name' => '第十二课·认识国家安全', 'page' => 102],
                'mor-12-2' => ['no' => 6, 'name' => '第十二课·维护国家安全', 'page' => 106],
            ]],
        ],

    ];
    return $c;
}

/** 全部小节 id（跨科目） */
function unit_ids(): array
{
    $ids = [];
    foreach (curriculum() as $subj => $chapters) {
        foreach ($chapters as $ch) {
            foreach ($ch['subs'] as $id => $s) $ids[] = $id;
        }
    }
    return $ids;
}

/** 某科目下的小节 id */
function subject_unit_ids(string $subj): array
{
    $ids = [];
    foreach (curriculum()[$subj] ?? [] as $ch) {
        foreach ($ch['subs'] as $id => $s) $ids[] = $id;
    }
    return $ids;
}

/** 小节元信息 */
function unit_meta(string $id): ?array
{
    $subj = subject_of($id);
    foreach (curriculum() as $sk => $chapters) {
        foreach ($chapters as $ch) {
            if (isset($ch['subs'][$id])) {
                return [
                    'unit'       => $id,
                    'subject'    => $sk,
                    'chapter'    => $ch['name'],
                    'chapter_no' => $ch['no'],
                    'name'       => $ch['subs'][$id]['name'],
                    'no'         => $ch['subs'][$id]['no'],
                    'page'       => $ch['subs'][$id]['page'],
                ];
            }
        }
    }
    return null;
}

/**
 * 载入题库（每单元 50 题）。
 * 题库文件在服务端 app/units/*.php，客户端不可达。
 */
function load_bank(): array
{
    static $bank = null;
    if ($bank !== null) return $bank;

    $bank = [];
    $dir = __DIR__ . '/units';
    foreach (glob($dir . '/*.php') as $f) {
        $data = require $f;
        if (!is_array($data)) continue;
        foreach ($data as $q) {
            $uid = $q['unit'];
            $bank[$uid][] = $q;
        }
    }
    foreach ($bank as $uid => $list) {
        usort($list, fn($a, $b) => $a['qid'] <=> $b['qid']);
        $bank[$uid] = $list;
    }
    return $bank;
}

function unit_size(string $uid): int
{
    $b = load_bank();
    return isset($b[$uid]) ? count($b[$uid]) : 0;
}

/** 随机抽取 n 题 */
/**
 * 抽题。
 *
 * @param string $uid    单元
 * @param int    $n      抽几题
 * @param array  $done   该用户在这个单元「已经首次做对」的题号集合
 *                       （传空数组则纯随机）
 *
 * 策略：
 *   1. 先尽量抽【没做过】的题（这样每次练习都有新鲜感）
 *   2. 不够时用【做过但最久没碰】的题补齐
 *   3. 全程用 random_int() 取随机数（每次都重新取熵，不依赖全局种子）
 */
function draw_questions(string $uid, int $n = 10, array $done = []): array
{
    $b = load_bank();
    $list = $b[$uid] ?? [];
    if (!$list) return [];
    if (count($list) <= $n) return pick_shuffle(array_column($list, 'qid'));

    $doneSet = [];
    foreach ($done as $d) $doneSet[(int)$d] = true;

    $fresh = [];   // 没做过的
    $seen  = [];   // 做过的
    foreach ($list as $q) {
        if (isset($doneSet[(int)$q['qid']])) $seen[] = (int)$q['qid'];
        else $fresh[] = (int)$q['qid'];
    }

    // 先用没做过的
    $picked = pick_random($fresh, $n);

    // 不够就用做过的补（随机取，避免固定顺序）
    if (count($picked) < $n) {
        $need = $n - count($picked);
        $rest = pick_random($seen, $need);
        $picked = array_merge($picked, $rest);
    }

    return pick_shuffle($picked);
}

/** 从数组里随机取 $n 个（不重复），用 random_int 保证每次取新熵 */
function pick_random(array $pool, int $n): array
{
    $pool = array_values($pool);
    $cnt = count($pool);
    if ($cnt === 0 || $n <= 0) return [];
    if ($cnt <= $n) return $pool;

    $out = [];
    $taken = [];
    while (count($out) < $n) {
        $i = random_int(0, $cnt - 1);
        if (isset($taken[$i])) continue;
        $taken[$i] = true;
        $out[] = $pool[$i];
    }
    return $out;
}

/** 洗牌（random_int 版，避免 shuffle() 受全局种子影响） */
function pick_shuffle(array $arr): array
{
    $arr = array_values($arr);
    for ($i = count($arr) - 1; $i > 0; $i--) {
        $j = random_int(0, $i);
        $t = $arr[$i]; $arr[$i] = $arr[$j]; $arr[$j] = $t;
    }
    return $arr;
}

function get_question(string $uid, int $qid): ?array
{
    $b = load_bank();
    foreach ($b[$uid] ?? [] as $q) if ($q['qid'] === $qid) return $q;
    return null;
}

/**
 * 取出一题，并【打乱选项顺序】。
 *
 * @param string $unitId 单元
 * @param int    $qid    题号
 * @param string $seed   随机种子（用会话令牌，保证同一场练习内稳定）
 * @return array|null    ['qid','q','opts','ans'] 或 null
 *
 * 注意：ans 会跟着选项一起搬位置，所以返回值里的 ans 一定对应
 *       打乱后的正确项 —— 判分必须用这个函数返回的 ans。
 */
function shuffled_question(string $unitId, int $qid, string $seed = ''): ?array
{
    $q = get_question($unitId, $qid);
    if ($q === null) return null;

    $opts = $q['opts'];
    $ans  = (int)$q['ans'];

    // 用种子派生一个稳定的乱序（同一 seed+qid 结果相同）
    $order = [0, 1, 2, 3];
    if ($seed !== '') {
        // 用 hash 派生伪随机数，避免依赖 mt_srand 的全局状态
        $h = hash('sha256', $seed . '|' . $unitId . '|' . $qid, true);
        // 用 Fisher-Yates，随机源取自 hash 字节
        $bytes = array_values(unpack('C*', $h));
        $bi = 0;
        for ($i = 3; $i > 0; $i--) {
            $r = $bytes[$bi % count($bytes)];
            $bi++;
            $j = $r % ($i + 1);
            $tmp = $order[$i]; $order[$i] = $order[$j]; $order[$j] = $tmp;
        }
    }

    // 按 order 重排选项，并追踪正确答案的新位置
    $newOpts = [];
    $newAns  = 0;
    foreach ($order as $newPos => $oldPos) {
        $newOpts[$newPos] = $opts[$oldPos];
        if ($oldPos === $ans) $newAns = $newPos;
    }

    return [
        'qid'  => (int)$q['qid'],
        'q'    => $q['q'],
        'opts' => $newOpts,
        'ans'  => $newAns,
        'exp'  => (string)($q['exp'] ?? ''),
    ];
}
