<?php
/**
 * 排行榜 · 零扩展版
 *
 * 显示三个数值（需求 5）：
 *   正确率 = 答对题数 / 总答题数        （取该用户最好的一次）
 *   分数   = 含连对加成的总分（最高分）
 *   答对速度 = 答对题目的平均耗时，毫秒/题（只算答对的题，答错的不计入）
 *
 * 只要 IP 访问过就会出现在榜上（users.json 里有记录即上榜），
 * 哪怕一次练习都没做过（此时数值显示为 —）。
 */

declare(strict_types=1);

/** 把 runs 聚合成每个用户的最好成绩 */
function leaderboard_rows(bool $onlyPlayers = false): array
{
    // 请求内缓存：同一请求里排行榜只算一次（页面多处会用到）
    static $cache = [];
    static $ver = -1;
    $now = $GLOBALS['__json_cache_ver'] ?? 0;
    if ($now !== $ver) { $cache = []; $ver = $now; }
    $key = $onlyPlayers ? 'p' : 'a';
    if (isset($cache[$key])) return $cache[$key];

    $users  = json_read(data_file('users'));
    $runs   = json_read(data_file('runs'));
    $prog   = json_read(data_file('progress'));

    // 每个用户取"分数最高"的那次作为展示成绩
    $best = [];
    foreach ($runs as $r) {
        $k = (string)($r['ipkey'] ?? '');
        if ($k === '') continue;
        if (!isset($best[$k]) || (int)$r['score'] > (int)$best[$k]['score']) {
            $best[$k] = $r;
        }
    }

    $rows = [];
    foreach ($users as $k => $u) {
        // 只要访问过就上榜
        $r = $best[$k] ?? null;
        $rows[] = [
            'ipkey'      => $k,
            'label'      => (string)($u['label'] ?? ('IP-' . strtoupper(substr($k,0,8)))),
            'nick'       => trim((string)($u['nick'] ?? '')),
            'ip'         => (string)($u['ip'] ?? ''),
            'score'      => $r ? (int)$r['score'] : null,
            'correct'    => $r ? (int)$r['correct'] : null,
            'total'      => $r ? (int)$r['total'] : null,
            // 正确率
            'accuracy'   => ($r && (int)$r['total'] > 0)
                            ? (int)round((int)$r['correct'] / (int)$r['total'] * 100)
                            : null,
            // 答对速度（毫秒/题，只算答对的）
            'avg_ms'     => $r ? (int)$r['avg_ms'] : null,
            'runs'       => 0,
            'hits'       => isset($prog[$k]) ? count($prog[$k]) : 0,
            'online_ms'  => (int)($u['online_ms'] ?? 0),
            'seen_at'    => (int)($u['seen_at'] ?? 0),
        ];
    }

    // 练习次数
    $cnt = [];
    foreach ($runs as $r) {
        $k = (string)($r['ipkey'] ?? '');
        if ($k !== '') $cnt[$k] = ($cnt[$k] ?? 0) + 1;
    }
    foreach ($rows as &$row) $row['runs'] = $cnt[$row['ipkey']] ?? 0;
    unset($row);

    if ($onlyPlayers) {
        $rows = array_values(array_filter($rows, fn($x) => $x['score'] !== null));
    }

    /* ---- 按显示名（IP）合并重复项 ----
       旧版本把「ip:port」当成不同用户，同一个 IP 可能被登记成多条。
       这里按 label 归并：取分数最高的那次成绩，练习次数与首次做对累加。
    */
    $merged = [];
    foreach ($rows as $row) {
        $key = (string)$row['label'];
        if (!isset($merged[$key])) {
            $merged[$key] = $row;
            continue;
        }
        $m = &$merged[$key];
        // 分数更高的接管成绩字段
        $curScore  = $m['score']  ?? -1;
        $newScore  = $row['score'] ?? -1;
        if ($newScore > $curScore) {
            $m['score']    = $row['score'];
            $m['correct']  = $row['correct'];
            $m['total']    = $row['total'];
            $m['accuracy'] = $row['accuracy'];
            $m['avg_ms']   = $row['avg_ms'];
        }
        $m['runs']     += $row['runs'];
        $m['hits']     += $row['hits'];
        $m['online_ms'] = max((int)$m['online_ms'], (int)$row['online_ms']);
        $m['seen_at']   = max((int)$m['seen_at'], (int)$row['seen_at']);
        unset($m);
    }
    $rows = array_values($merged);

    // 排序：分数高的在前；同分比在线时长（长的在前）
    usort($rows, function ($a, $b) {
        $sa = $a['score'] ?? -1;
        $sb = $b['score'] ?? -1;
        if ($sa !== $sb) return $sb <=> $sa;
        return (int)$b['online_ms'] <=> (int)$a['online_ms'];
    });

    $cache[$key] = $rows;
    return $rows;
}

function leaderboard_total(int $limit = 100): array
{
    return array_slice(leaderboard_rows(false), 0, $limit);
}

function leaderboard_unit(string $uid, int $limit = 100): array
{
    // 单元榜：只看该单元的成绩
    $users = json_read(data_file('users'));
    $runs  = json_read(data_file('runs'));

    $best = [];
    foreach ($runs as $r) {
        if ((string)($r['unit_id'] ?? '') !== $uid) continue;
        $k = (string)($r['ipkey'] ?? '');
        if ($k === '') continue;
        if (!isset($best[$k]) || (int)$r['score'] > (int)$best[$k]['score']) $best[$k] = $r;
    }

    $rows = [];
    foreach ($best as $k => $r) {
        $rows[] = [
            'ipkey'    => $k,
            'label'    => (string)($users[$k]['label'] ?? ('IP-' . strtoupper(substr($k,0,8)))),
            'score'    => (int)$r['score'],
            'correct'  => (int)$r['correct'],
            'total'    => (int)$r['total'],
            'accuracy' => ((int)$r['total'] > 0)
                          ? (int)round((int)$r['correct'] / (int)$r['total'] * 100) : 0,
            'avg_ms'   => (int)$r['avg_ms'],
            'runs'     => 0,
            'hits'     => 0,
            'online_ms'=> (int)($users[$k]['online_ms'] ?? 0),
            'seen_at'  => 0,
        ];
    }

    usort($rows, function ($a, $b) {
        if ($a['score'] !== $b['score']) return $b['score'] <=> $a['score'];
        return (int)($b['online_ms'] ?? 0) <=> (int)($a['online_ms'] ?? 0);
    });

    return array_slice($rows, 0, $limit);
}

/**
 * 科目榜：只统计 runs 里属于该科目的成绩。
 * 分数取该科目内最高的一次。
 */
function leaderboard_subject(string $subj, int $limit = 200): array
{
    $users = json_read(data_file('users'));
    $runs  = json_read(data_file('runs'));

    // 收集该科目下的单元 id
    $units = array_flip(subject_unit_ids($subj));

    $best = [];
    foreach ($runs as $r) {
        $u = (string)($r['unit_id'] ?? '');
        if (!isset($units[$u])) continue;
        $k = (string)($r['ipkey'] ?? '');
        if ($k === '') continue;
        if (!isset($best[$k]) || (int)$r['score'] > (int)$best[$k]['score']) $best[$k] = $r;
    }

    $rows = [];
    foreach ($best as $k => $r) {
        $rows[] = [
            'ipkey'     => $k,
            'label'     => (string)($users[$k]['label'] ?? ip_label_from_key($k)),
            'nick'      => trim((string)($users[$k]['nick'] ?? '')),
            'ip'        => (string)($users[$k]['ip'] ?? ''),
            'score'     => (int)$r['score'],
            'correct'   => (int)$r['correct'],
            'total'     => (int)$r['total'],
            'accuracy'  => ((int)$r['total'] > 0)
                            ? (int)round((int)$r['correct'] / (int)$r['total'] * 100) : 0,
            'avg_ms'    => (int)$r['avg_ms'],
            'runs'      => 0,
            'hits'      => 0,
            'online_ms' => (int)($users[$k]['online_ms'] ?? 0),
            'seen_at'   => 0,
        ];
    }

    usort($rows, function ($a, $b) {
        if ($a['score'] !== $b['score']) return $b['score'] <=> $a['score'];
        return $a['online_ms'] <=> $b['online_ms'];
    });

    return array_slice($rows, 0, $limit);
}

/** 该用户在总榜的名次（0 = 未上榜） */
/**
 * 该用户在总榜的名次（0 = 未上榜）。
 *
 * 实现要点：不构造整个榜单再排序，而是「数有多少人比我强」。
 * 排序规则（与 leaderboard_rows 一致）：
 *   分数高者前 → 正确率高的前 → 速度快的前 → 最近访问的前
 * 这样只遍历一次数据，省掉排序开销。
 */
function user_rank(string $ipkey): int
{
    static $cache = [];
    static $ver = -1;
    $now = $GLOBALS['__json_cache_ver'] ?? 0;
    if ($now !== $ver) { $cache = []; $ver = $now; }
    if (isset($cache[$ipkey])) return $cache[$ipkey];

    $users = json_read(data_file('users'));
    if (!isset($users[$ipkey])) { $cache[$ipkey] = 0; return 0; }

    $runs = json_read(data_file('runs'));
    $prog = json_read(data_file('progress'));

    // 每人取最高分那次（与 leaderboard_rows 口径一致）
    $best = [];
    foreach ($runs as $r) {
        $k = (string)($r['ipkey'] ?? '');
        if ($k === '') continue;
        if (!isset($best[$k]) || (int)$r['score'] > (int)$best[$k]['score']) $best[$k] = $r;
    }

    // 我自己的指标
    $me = $best[$ipkey] ?? null;
    $myScore = $me ? (int)$me['score'] : null;
    $myAcc   = ($me && (int)$me['total'] > 0)
                ? (int)round((int)$me['correct'] / (int)$me['total'] * 100) : null;
    $myMs    = $me ? (int)$me['avg_ms'] : null;
    $mySeen   = (int)($users[$ipkey]['seen_at'] ?? 0);
    $myOnline = (int)($users[$ipkey]['online_ms'] ?? 0);

    $better = 0;
    foreach ($users as $k => $u) {
        if ($k === $ipkey) continue;

        $r = $best[$k] ?? null;
        $s = $r ? (int)$r['score'] : null;
        $a = ($r && (int)$r['total'] > 0)
                ? (int)round((int)$r['correct'] / (int)$r['total'] * 100) : null;
        $m = $r ? (int)$r['avg_ms'] : null;
        $seen = (int)($u['seen_at'] ?? 0);

        // 比较：分数 → 在线时长
        $ss  = $s ?? -1;
        $mss = $myScore ?? -1;
        if ($ss !== $mss) { if ($ss > $mss) $better++; continue; }

        $on  = (int)($u['online_ms'] ?? 0);
        if ($on > $myOnline) $better++;
    }

    $rank = $better + 1;
    $cache[$ipkey] = $rank;
    return $rank;
}

/** 毫秒转可读文字 */
function fmt_ms(?int $ms): string
{
    if ($ms === null || $ms <= 0) return '—';
    if ($ms < 1000) return $ms . ' ms';
    return round($ms / 1000, 1) . ' s';
}

/** 毫秒 → 可读的在线时长（如 "2 小时 13 分" / "46 分钟" / "刚刚"） */
function fmt_duration(int $ms): string
{
    if ($ms <= 0) return '刚刚';
    $sec = (int)round($ms / 1000);
    if ($sec < 60) return $sec . ' 秒';
    $min = (int)floor($sec / 60);
    if ($min < 60) return $min . ' 分钟';
    $h = (int)floor($min / 60);
    $m = $min % 60;
    if ($h < 24) return $m > 0 ? ($h . ' 小时 ' . $m . ' 分') : ($h . ' 小时');
    $d = (int)floor($h / 24);
    $hh = $h % 24;
    return $hh > 0 ? ($d . ' 天 ' . $hh . ' 小时') : ($d . ' 天');
}
