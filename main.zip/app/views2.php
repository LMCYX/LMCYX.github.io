<?php
/**
 * 扩展功能的页面视图。
 *
 * 和 views.php 分开写，避免那个文件过长。
 * 每个 render_xxx 都返回一段 HTML 片段（不含外壳），
 * 由 render_page() 按 action 选择。
 */

declare(strict_types=1);

/* ------------------------------------------------------------------ *
 *  小工具
 * ------------------------------------------------------------------ */

/** 时间戳 -> "3 分钟前" */
function ago_text(int $ts): string
{
    if ($ts <= 0) return '—';
    $d = time() - $ts;
    if ($d < 60)    return '刚刚';
    if ($d < 3600)  return intdiv($d, 60) . ' 分钟前';
    if ($d < 86400) return intdiv($d, 3600) . ' 小时前';
    if ($d < 86400 * 30) return intdiv($d, 86400) . ' 天前';
    return date('m-d', $ts);
}

/** 学科彩色小标签 */
function subj_chip(string $subj): string
{
    $map = ['phy' => 'phy', 'bio' => 'bio', 'mor' => 'mor', 'inter' => 'inter'];
    $c = $map[$subj] ?? 'phy';
    return '<span class="schip ' . $c . '">' . e(subject_name($subj, true)) . '</span>';
}

/* ================================================================== *
 *  功能：错题本
 * ================================================================== */

function render_wrong(array $state, array $user, string $fp): string
{
    $rows = $state['wrong_list'] ?? [];
    $n = count($rows);

    $body = '';
    if (!$rows) {
        $body = '<div class="empty">错题本是空的 —— 要么你全对，要么还没练过。<br>去首页挑个单元试试。</div>';
    } else {
        $body .= '<div class="wlist">';
        foreach ($rows as $r) {
            $body .= '<div class="witem">'
                   . '<div class="wtop">'
                   .   subj_chip((string)$r['subject'])
                   .   '<span class="wunit">' . e((string)$r['unit_name']) . '</span>'
                   .   '<span class="wn">错 ' . (int)$r['n'] . ' 次</span>'
                   . '</div>'
                   . '<div class="wq">' . e((string)$r['q']) . '</div>'
                   . '<div class="wacts">'
                   .   '<a class="btn tiny" href="#" data-act="fav" data-unit="' . e((string)$r['unit_id']) . '" data-qid="' . (int)$r['qid'] . '">收藏</a>'
                   .   '<a class="btn tiny ghost" href="#" data-act="start" data-unit="' . e((string)$r['unit_id']) . '">练这个单元</a>'
                   . '</div></div>';
        }
        $body .= '</div>';
    }

    $bar = $n > 0
        ? '<div class="row" style="margin-bottom:12px"><a class="btn" href="#" data-act="wrongredo">一键重练这 ' . min($n, 20) . ' 题</a></div>'
        : '';

    return view_header($user, $fp, 'wrong')
        . '<div class="card">'
        . '<h2>错题本 <span class="cnt">' . $n . '</span></h2>'
        . '<p class="sub">做错的题会自动进这里；哪天做对了就自动移出去。按错误次数排序。</p>'
        . $bar . $body
        . '</div>';
}

/* ================================================================== *
 *  功能：收藏
 * ================================================================== */

function render_favs(array $state, array $user, string $fp): string
{
    $rows = $state['fav_list'] ?? [];
    $n = count($rows);

    $body = '';
    if (!$rows) {
        $body = '<div class="empty">还没有收藏。<br>在练习页点题目右上角的 ☆ 就能收藏，用来标记"这题我要再看一遍"。</div>';
    } else {
        $body .= '<div class="wlist">';
        foreach ($rows as $r) {
            $body .= '<div class="witem">'
                   . '<div class="wtop">'
                   .   subj_chip((string)$r['subject'])
                   .   '<span class="wunit">' . e((string)$r['unit_name']) . '</span>'
                   . '</div>'
                   . '<div class="wq">' . e((string)$r['q']) . '</div>'
                   . '<div class="wacts">'
                   .   '<a class="btn tiny ghost" href="#" data-act="fav" data-unit="' . e((string)$r['unit_id']) . '" data-qid="' . (int)$r['qid'] . '">取消收藏</a>'
                   . '</div></div>';
        }
        $body .= '</div>';
    }

    $bar = $n > 0
        ? '<div class="row" style="margin-bottom:12px"><a class="btn" href="#" data-act="favredo">重练这 ' . min($n, 20) . ' 题</a></div>'
        : '';

    return view_header($user, $fp, 'favs')
        . '<div class="card">'
        . '<h2>收藏 <span class="cnt">' . $n . '</span></h2>'
        . '<p class="sub">手动标记的待复习题目。</p>'
        . $bar . $body
        . '</div>';
}

/* ================================================================== *
 *  功能：成绩趋势
 * ================================================================== */

function render_trend(array $state, array $user, string $fp): string
{
    $series = $state['trend'] ?? [];
    $st     = $state['trend_stat'] ?? [];

    // 给 JS 画图用的数据（只传必要字段，省流量）
    $pts = [];
    foreach ($series as $s) {
        $pts[] = ['s' => (int)$s['score'], 'c' => (int)$s['correct'], 't' => (int)$s['total']];
    }
    $json = json_encode($pts, JSON_UNESCAPED_UNICODE);

    $head = '<div class="stat4">'
          . '<div><b>' . (int)($st['runs'] ?? 0) . '</b><span>练习次数</span></div>'
          . '<div><b class="g">' . (int)($st['total'] ?? 0) . '</b><span>累计得分</span></div>'
          . '<div><b class="a">' . (int)($st['best'] ?? 0) . '</b><span>最高单次</span></div>'
          . '<div><b class="o">' . (int)($st['acc'] ?? 0) . '%</b><span>平均正确率</span></div>'
          . '</div>';

    $canvas = count($pts) >= 2
        ? '<div class="chartwrap"><canvas id="trendcv" width="720" height="260"></canvas></div>'
          . '<script id="trenddata" type="application/json">' . $json . '</script>'
        : '<div class="empty">至少练 2 次才会有趋势图。<br>现在有 ' . count($pts) . ' 次记录。</div>';

    // 明细表
    $tbl = '';
    if ($series) {
        $tbl .= '<h2 style="margin-top:18px">每次明细</h2><div style="overflow-x:auto"><table>'
              . '<thead><tr><th>时间</th><th>得分</th><th class="n">答对</th><th class="n">正确率</th></tr></thead><tbody>';
        foreach (array_reverse($series) as $s) {
            $tot = max(1, (int)$s['total']);
            $acc = (int)round((int)$s['correct'] / $tot * 100);
            $uid = (string)$s['unit'];
            $nm  = strpos($uid, 'mixed:') === 0 ? substr($uid, 6) : (string)(unit_meta($uid)['name'] ?? $uid);
            $tbl .= '<tr><td>' . e(date('m-d H:i', (int)$s['t'])) . '<div style="font-size:10.5px;color:var(--txt3)">' . e($nm) . '</div></td>'
                  . '<td class="n"><b>' . (int)$s['score'] . '</b></td>'
                  . '<td class="n">' . (int)$s['correct'] . '/' . (int)$s['total'] . '</td>'
                  . '<td class="n">' . $acc . '%</td></tr>';
        }
        $tbl .= '</tbody></table></div>';
    }

    return view_header($user, $fp, 'trend')
        . '<div class="card">'
        . '<h2>成绩趋势</h2>'
        . '<p class="sub">最近 30 次练习的得分曲线（越往上越好）。</p>'
        . $head . $canvas . $tbl
        . '<div class="row" style="margin-top:16px">'
        . '<a class="btn ghost" href="#" data-act="export" data-fmt="csv">导出 CSV</a>'
        . '<a class="btn ghost" href="#" data-act="export" data-fmt="json">导出 JSON 备份</a>'
        . '</div>'
        . '</div>';
}

/* ================================================================== *
 *  功能：在线状态
 * ================================================================== */

function render_online(array $state, array $user, string $fp): string
{
    $rows = $state['online'] ?? [];
    $n = (int)($state['online_n'] ?? 0);

    $body = '';
    if (!$rows) {
        $body = '<div class="empty">还没有人访问过。</div>';
    } else {
        foreach ($rows as $r) {
            $dot = $r['online'] ? '<i class="dot on"></i>' : '<i class="dot"></i>';
            $body .= '<div class="oline">'
                   . $dot
                   . '<span class="oname">' . e((string)$r['name']) . '</span>'
                   . '<span class="oip">' . e((string)$r['ip']) . '</span>'
                   . '<span class="oago">' . ($r['online'] ? '在线' : e(ago_text((int)$r['seen']))) . '</span>'
                   . '</div>';
        }
    }

    return view_header($user, $fp, 'online')
        . '<div class="card">'
        . '<h2>在线状态 <span class="cnt">' . $n . ' 人在线</span></h2>'
        . '<p class="sub">2 分钟内有操作就算在线。点过页面的都会留在下面。</p>'
        . $body
        . '</div>';
}

/* ================================================================== *
 *  功能：全站统计
 * ================================================================== */

function render_stats(array $state, array $user, string $fp): string
{
    $s = $state['site_stat'] ?? [];
    $hot = $state['hot'] ?? [];

    $grid = '<div class="statgrid">'
          . '<div><b>' . (int)($s['users'] ?? 0) . '</b><span>访问过的用户</span></div>'
          . '<div><b>' . (int)($s['runs'] ?? 0) . '</b><span>练习次数</span></div>'
          . '<div><b>' . (int)($s['answers'] ?? 0) . '</b><span>累计作答（题次）</span></div>'
          . '<div><b class="g">' . (int)($s['accuracy'] ?? 0) . '%</b><span>全站正确率</span></div>'
          . '<div><b>' . (int)($s['units'] ?? 0) . '</b><span>单元数</span></div>'
          . '<div><b>' . (int)($s['questions'] ?? 0) . '</b><span>题库总题数</span></div>'
          . '<div><b class="a">' . (int)($s['coverage'] ?? 0) . '%</b><span>题目覆盖率</span></div>'
          . '<div><b class="o">' . (int)($s['chats'] ?? 0) . '</b><span>聊天消息</span></div>'
          . '</div>';

    $top = '';
    if (!empty($s['top'])) {
        $t = $s['top'];
        $top = '<h2 style="margin-top:18px">最活跃</h2>'
             . '<div class="oline"><i class="dot on"></i>'
             . '<span class="oname">' . e((string)($t['name'] ?? '?')) . '</span>'
             . '<span class="oip">练了 ' . (int)$t['n'] . ' 次</span>'
             . '<span class="oago">' . (int)$t['score'] . ' 分</span>'
             . '</div>';
    }

    $hotHtml = '';
    if ($hot) {
        $hotHtml = '<h2 style="margin-top:18px">热门单元</h2><div class="hotlist">';
        $max = max(1, (int)($hot[0]['runs'] ?? 1));
        foreach ($hot as $h) {
            $w = (int)round((int)$h['runs'] / $max * 100);
            $hotHtml .= '<div class="hotrow">'
                      . '<span class="hotname">' . e((string)$h['name']) . '</span>'
                      . '<span class="hotbar"><i style="width:' . $w . '%"></i></span>'
                      . '<span class="hotn">' . (int)$h['runs'] . '</span>'
                      . '</div>';
        }
        $hotHtml .= '</div>';
    }

    return view_header($user, $fp, 'stats')
        . '<div class="card"><h2>全站统计</h2>'
        . '<p class="sub">所有用户加在一起的数据。</p>'
        . $grid . $top . $hotHtml
        . '</div>';
}

/* ================================================================== *
 *  功能：邮件设置 / 发信
 * ================================================================== */

/* ================================================================== *
 *  每日一练卡片（放首页顶部）
 * ================================================================== */

function daily_card(array $state, array $user, string $fp): string
{
    $d = $state['daily'] ?? [];
    $streak = (int)($d['streak'] ?? 0);
    $done   = !empty($d['today']);
    $best   = (int)($d['best'] ?? 0);
    $total  = (int)($d['total'] ?? 0);

    // 7 个点表示最近 7 天（这里简化：只标出今天打没打）
    $flame = $streak >= 7 ? '🔥🔥' : ($streak >= 3 ? '🔥' : '');

    return '<div class="dailycard">'
         . '<div class="dleft">'
         .   '<div class="dtitle">每日一练 ' . $flame . '</div>'
         .   '<div class="dsub">'
         .     ($done
                 ? ('今天已完成 · 连续 <b>' . $streak . '</b> 天')
                 : ('还没练 · 连续 <b>' . $streak . '</b> 天'))
         .     ' · 最长 ' . $best . ' 天 · 共打卡 ' . $total . ' 次'
         .   '</div>'
         . '</div>'
         . '<a class="btn' . ($done ? ' ghost' : '') . '" href="#" data-act="daily">'
         .   ($done ? '再练一组' : '开始打卡')
         . '</a>'
         . '</div>';
}
