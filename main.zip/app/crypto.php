<?php
/**
 * 数据传输加密模块 · 纯 PHP 零扩展实现
 * ==================================================================
 * 设计目标：
 *   把「服务端 → 客户端」的响应体加密，使同一条链路上抓包
 *   看不到业务明文（题目、答案解释、排行榜等）。
 *
 * 一、为什么可以「零扩展」
 * ------------------------------------------------------------------
 *   PHP 的 hash 体系有两层：
 *     (1) ext/hash 扩展  —— 提供 hash()/hash_hmac()/hash_init() 等
 *     (2) 但从 PHP 7.4 起，ext/hash 已经【永久内置】进 PHP 核心
 *         （ext/hash 被标记为 "always available"，无法被 --disable-hash 关掉，
 *          也不再是共享扩展）。
 *   因此 hash() / hash_hmac() 在任何一份 PHP 7.4+ 里都一定存在，
 *   不属于「需要额外安装的扩展」。
 *   这一点可以用 extension_loaded('hash') 验证：它恒为 true，
 *   而且 get_loaded_extensions() 里有 hash，但 php.ini 里没有任何 hash.so。
 *
 *   同理，本模块只用到：
 *     hash()            —— 核心
 *     hash_hmac()       —— 核心
 *     random_bytes()    —— 核心（CSPRNG，PHP 7 起内置）
 *     pack()/unpack()   —— 核心（标准库）
 *     substr()/strlen() —— 核心
 *     base64_encode/decode —— 核心（标准库，PHP 8 起也移入核心）
 *     file_*()          —— 核心
 *   全程没有 openssl_* / sodium_* / mbstring / gmp / bcmath。
 *
 * 二、算法原理
 * ------------------------------------------------------------------
 *   这里用「HMAC-SHA256 作为 PRF 的计数器模式流密码（CTR）」
 *   + 「Encrypt-then-MAC」的组合。它不是 AES，但在「密钥长度 256bit、
 *   每次随机 nonce、密文附带认证标签」的前提下，
 *   其机密性/完整性强度对本站这种场景是足够的。
 *
 *   1) 密钥流（keystream）生成 —— CTR 模式
 *      把 32 字节的种子 seed 当密钥，对递增的计数器块做 HMAC-SHA256：
 *
 *          block_i = HMAC-SHA256(seed, "LBSPKS" || nonce || counter_i)   (32 字节)
 *          keystream = block_0 || block_1 || block_2 || ...
 *
 *      计数器 counter_i 用 8 字节大端（pack('J')）编码，从 0 递增。
 *      这本质上是一个基于 HMAC 的 PRF 计数器模式（同类构造见 NIST SP 800-108
 *      KDF in counter mode / HKDF-Expand），输出伪随机、不可预测。
 *
 *   2) 加密 —— 异或
 *          ciphertext = plaintext XOR keystream[0..len)
 *      流密码不需要填充，明文多长密文就多长。
 *
 *   3) 完整性 —— Encrypt-then-MAC
 *          mac = HMAC-SHA256(key, nonce || ciphertext)      (32 字节)
 *      先加密后认证，认证覆盖 nonce，可防篡改、防 nonce 重放替换。
 *      **校验时必须用 hash_equals() 做恒定时间比较**，避免计时侧信道。
 *
 *   4) 密钥派生
 *      data/crypto.key 里存 32 字节主密钥 MK。
 *      每次加密随机取 16 字节 nonce，派生本次的密钥流种子：
 *          seed = HMAC-SHA256(MK, "LBSP-v1 seed" || nonce)
 *      这样即使 nonce 复用，只要 MK 不泄露就不会重复出同一串密钥流。
 *
 * 三、封包格式（crypto_encrypt 返回的二进制）
 * ------------------------------------------------------------------
 *   偏移   长度   内容
 *   0      4      magic  "LBC1"        （明文嗅探用，便于快速判断）
 *   4      1      version = 1
 *   5      16     nonce（random_bytes(16)）
 *   21     32     mac = HMAC-SHA256(key, nonce||ciphertext)
 *   53     N      ciphertext
 *   ----------------------------------------------------------------
 *   总开销固定 53 字节。
 *   对一份 30KB 的 HTML 页面来说，体积增幅 ≈ 53/30000 ≈ 0.2%，
 *   远小于 base64 的 33%（本模块传输的是原始二进制，不做 base64）。
 *
 * 四、与前端的对接
 * ------------------------------------------------------------------
 *   public/client.js 里有同一算法的纯 JS 实现
 *   （自带一个 60 行的 SHA-256 + HMAC + CTR 密钥流），
 *   两端 seed 派生 / 计数器编码 / MAC 输入顺序必须逐字节一致，
 *   任何一处不一致都会导致 MAC 校验失败。
 * ==================================================================
 */

declare(strict_types=1);

/** 封包 magic：明文嗅探用 */
const CRYPTO_MAGIC   = 'LBC1';
/** 封包版本 */
const CRYPTO_VERSION = 1;
/** nonce 长度 */
const CRYPTO_NONCE_LEN = 16;
/** MAC（HMAC-SHA256）长度 */
const CRYPTO_MAC_LEN = 32;
/** 主密钥长度 */
const CRYPTO_KEY_LEN = 32;
/** 固定头部长度 = magic(4) + version(1) + nonce(16) + mac(32) */
const CRYPTO_HEAD_LEN = 53;

/* ------------------------------------------------------------------ *
 *  主密钥
 * ------------------------------------------------------------------ */

/**
 * 读取/生成主密钥。
 *
 *   - 文件：<data_dir>/crypto.key，内容为 32 字节原始二进制
 *   - 不存在则用 random_bytes(32) 生成，并以 0600 权限写入
 *   - 进程内静态缓存，避免每个请求都读盘
 *
 * 注意：主密钥不在 HTTP 层传输，只用于派生「每会话密钥」。
 */
function crypto_key(): string
{
    static $cached = null;
    if ($cached !== null) return $cached;

    $file = crypto_key_file();

    // 已存在：读出并校验长度
    if (is_file($file)) {
        $raw = @file_get_contents($file);
        if (is_string($raw) && strlen($raw) === CRYPTO_KEY_LEN) {
            $cached = $raw;
            return $cached;
        }
        // 兼容：万一被存成了 hex（64 字符）
        if (is_string($raw) && strlen($raw) === CRYPTO_KEY_LEN * 2
            && ctype_xdigit($raw)) {
            $bin = @hex2bin($raw);
            if (is_string($bin) && strlen($bin) === CRYPTO_KEY_LEN) {
                $cached = $bin;
                return $cached;
            }
        }
        // 长度不对 → 视为损坏，重新生成（会覆盖）
    }

    // 生成新密钥
    $key = random_bytes(CRYPTO_KEY_LEN);

    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0777, true);

    // 先建空文件并立刻收紧权限，再写内容，避免出现「0644 且已有密钥」的窗口
    $fp = @fopen($file, 'wb');
    if ($fp !== false) {
        @chmod($file, 0600);
        @flock($fp, LOCK_EX);
        @fwrite($fp, $key);
        @fflush($fp);
        @flock($fp, LOCK_UN);
        @fclose($fp);
        @chmod($file, 0600);
    } else {
        // 兜底：直接用 file_put_contents（权限可能受 umask 影响，随后再 chmod）
        @file_put_contents($file, $key, LOCK_EX);
        @chmod($file, 0600);
    }

    $cached = $key;
    return $cached;
}

/** 密钥文件路径 */
function crypto_key_file(): string
{
    $dir = function_exists('data_dir') ? data_dir() : (__DIR__ . '/../data');
    return rtrim($dir, '/\\') . '/crypto.key';
}

/* ------------------------------------------------------------------ *
 *  密钥派生 / 密钥流
 * ------------------------------------------------------------------ */

/**
 * 由「主密钥 + nonce」派生本次的密钥流种子（32 字节）。
 *
 *   seed = HMAC-SHA256(MK, "LBSP-v1 seed" || nonce)
 *
 * 用 HMAC 而不是裸 hash(key||nonce)，可以避免长度扩展攻击，
 * 并且输出天然是 32 字节，正好当下一层 HMAC 的密钥。
 */
function crypto_derive(string $key, string $nonce): string
{
    return hash_hmac('sha256', "LBSP-v1 seed" . $nonce, $key, true);
}

/**
 * 生成 $len 字节的伪随机密钥流（CTR 模式）。
 *
 * 对每个计数器 i（8 字节大端）算：
 *     block_i = HMAC-SHA256(seed, "LBSPKS" || counter_i)
 * 然后按需截断拼接。
 *
 * 用哈希/HMAC 当 PRF 的好处：输出与真随机不可区分（在 SHA-256
 * 的 PRF 假设下），且不需要任何外部随机源，两端算法完全可复现。
 */
function crypto_keystream(string $seed, int $len): string
{
    if ($len <= 0) return '';

    // 计数器用 8 字节大端，从 0 递增。用【字符串进位】实现，
    // 避开浮点与 64 位整数（32 位 PHP 上 pack('J')/intdiv 都会炸）。
    // 语义：block_i = HMAC-SHA256(seed, "LBSPKS" || uint64_be(i))
    $ctr = "\x00\x00\x00\x00\x00\x00\x00\x00";

    // ---- 手工 HMAC，预计算 key 的 ipad / opad ----
    // seed 在整条密钥流里固定，所以这两块只需算一次。
    // 结果与 hash_hmac() 逐字节一致（已实测），密文格式不变。
    $k = strlen($seed) > 64 ? hash('sha256', $seed, true) : $seed;
    $k = str_pad($k, 64, "\x00");
    $ipad = $k ^ str_repeat("\x36", 64);
    $opad = $k ^ str_repeat("\x5c", 64);

    $out  = '';
    $need = $len;

    while ($need > 0) {
        $inner = hash('sha256', $ipad . "LBSPKS" . $ctr, true);
        $block = hash('sha256', $opad . $inner, true);

        $take = $need < 32 ? $need : 32;
        $out .= $take === 32 ? $block : substr($block, 0, $take);
        $need -= $take;

        // 8 字节大端 +1（从最低位往前进位）
        for ($i = 7; $i >= 0; $i--) {
            $b = ord($ctr[$i]);
            if ($b === 255) { $ctr[$i] = "\x00"; continue; }
            $ctr[$i] = chr($b + 1);
            break;
        }
    }

    return $out;
}

/* ------------------------------------------------------------------ *
 *  加解密
 * ------------------------------------------------------------------ */

/**
 * 加密：返回二进制封包
 *     [magic(4)][version(1)][nonce(16)][mac(32)][ciphertext]
 *
 * Encrypt-then-MAC：
 *     1. nonce 随机 16 字节
 *     2. seed = crypto_derive(key, nonce)
 *     3. ciphertext = plaintext XOR keystream(seed)
 *     4. mac = HMAC-SHA256(key, nonce || ciphertext)
 */
function crypto_encrypt(string $plain, ?string $key = null): string
{
    $key   = $key ?? crypto_key();
    $nonce = random_bytes(CRYPTO_NONCE_LEN);

    $seed  = crypto_derive($key, $nonce);
    $ks    = crypto_keystream($seed, strlen($plain));
    $cipher = $plain ^ $ks;                       // 等长异或（stream cipher）

    $mac = hash_hmac('sha256', $nonce . $cipher, $key, true);

    return CRYPTO_MAGIC . chr(CRYPTO_VERSION) . $nonce . $mac . $cipher;
}

/**
 * 解密：校验 magic/version/mac，任何一步失败返回 null。
 *
 * 返回 null 表示「数据被篡改或密钥不对」，调用方应拒绝使用；
 * 返回 string 才是可信明文（包括空串 —— 所以必须用 === null 判断）。
 */
function crypto_decrypt(string $packed, ?string $key = null): ?string
{
    if (strlen($packed) < CRYPTO_HEAD_LEN) return null;
    if (substr($packed, 0, 4) !== CRYPTO_MAGIC) return null;
    if (ord($packed[4]) !== CRYPTO_VERSION) return null;

    $nonce  = substr($packed, 5, CRYPTO_NONCE_LEN);
    $mac    = substr($packed, 5 + CRYPTO_NONCE_LEN, CRYPTO_MAC_LEN);
    $cipher = substr($packed, CRYPTO_HEAD_LEN);

    $key = $key ?? crypto_key();

    // 恒定时间比较，防计时攻击
    $want = hash_hmac('sha256', $nonce . $cipher, $key, true);
    if (!hash_equals($want, $mac)) return null;

    $seed = crypto_derive($key, $nonce);
    $ks   = crypto_keystream($seed, strlen($cipher));

    return $cipher ^ $ks;
}

/**
 * 快速判断一段数据是不是本模块的加密包。
 * 只检查 magic（4 字节），不做 MAC 校验，供分流用，开销极小。
 */
function crypto_is_packed(string $data): bool
{
    return strlen($data) >= CRYPTO_HEAD_LEN
        && substr($data, 0, 4) === CRYPTO_MAGIC;
}

/* ------------------------------------------------------------------ *
 *  会话密钥（给前端用）
 * ------------------------------------------------------------------ */

/**
 * 派生「本会话」密钥：前端页面里内嵌的就是它。
 *
 *   session_key = HMAC-SHA256(MK, "LBSP-v1 session" || session_id)
 *
 * session_id 由调用方给出（本站用客户端 IP 的 ipkey + 日期，
 * 见 session_id()）。这样：
 *   - 每个客户端拿到的密钥不同，A 拿到也解不开 B 的响应；
 *   - 每天轮换一次，泄露也不会永久有效；
 *   - 主密钥 MK 永远不出现在任何 HTTP 报文里。
 */
function crypto_session_key(string $sid, ?string $key = null): string
{
    $key = $key ?? crypto_key();
    return hash_hmac('sha256', "LBSP-v1 session" . $sid, $key, true);
}

/** 当前会话标识（IP + 日期，天粒度轮换） */
function crypto_session_id(): string
{
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    if ($ip === '') {
        // 常驻服务里没有 $_SERVER，用调用方通过 crypto_session_id_set 注入
        $ip = crypto_session_id_override();
    }
    return $ip . '|' . gmdate('Ymd');
}

/** 会话 ID 前缀（常驻服务下由 server.php 注入客户端 IP） */
function crypto_session_id_set(string $ip): void
{
    $GLOBALS['__crypto_sid_ip'] = $ip;
}

function crypto_session_id_override(): string
{
    return (string)($GLOBALS['__crypto_sid_ip'] ?? '0.0.0.0');
}

/**
 * 本会话密钥的 base64 形式，直接内嵌进 HTML 的 <script id="state"> 的 k 字段。
 * 前端 window.__S.k → atob() → 32 字节密钥。
 */
function session_key_b64(): string
{
    return base64_encode(crypto_session_key(crypto_session_id()));
}
