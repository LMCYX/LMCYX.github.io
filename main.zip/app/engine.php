<?php
/**
 * 业务引擎：所有判定都在这里。
 *
 * 练习流程（需求 6 的修复）：
 *   start   → 服务端抽 10 题，一次性下发，客户端同页显示全部 10 题
 *   作答    → 客户端本地记录每题耗时，不逐题请求
 *   submit  → 客户端一次性提交 10 题的答案 + 每题耗时
 *             服务端统一判分、算连对加成、写排行榜
 *
 * 反作弊：答案只存在于服务端题库，客户端提交的只有选项和耗时；
 *         耗时做了合理范围校验；会话只能提交一次。
 */

declare(strict_types=1);

function handle_request(Request $req): Response
{
    $res = new Response();
    $ipkey = client_ip_key($req->ip);
    $user  = ensure_user($ipkey, (string)$req->ip);

    $action = (string)($req->data['a'] ?? 'view');
    $token  = (string)($req->data['t'] ?? '');

    $state = compute_state($ipkey, $user, $token, $action, $req->data, $res);
    $user  = ensure_user($ipkey, (string)$req->ip);
    $res->setBody(render_page($state, $user, $req));
    return $res;
}

/** 计算这一帧的页面状态 */
function compute_state(string $ipkey, array $user, string $token, string $action, array $data, Response $res): array
{
    $notice = '';
    $boardUnit = '';
    $session = $token !== '' ? load_session($token) : null;

    if ($session && $session['ipkey'] !== $ipkey) {
        $session = null;
        $token = '';
        $notice = '会话已失效，请重新开始。';
    }
    if (!$session) $token = '';

    switch ($action) {
        /* ---------- 切换科目 ---------- */
        case 'subject':
            $sj = (string)($data['s'] ?? 'phy');
            if (isset(subjects()[$sj])) {
                with_lock('users', function (array $users) use ($ipkey, $sj) {
                    if (isset($users[$ipkey])) $users[$ipkey]['subject'] = $sj;
                    return $users;
                });
                $user['subject'] = $sj;
            }
            break;

        /* ---------- 设置昵称（IP + 昵称登录） ---------- */
        case 'setnick':
            $r = set_nickname($ipkey, (string)($data['nick'] ?? ''));
            $notice = (string)($r['notice'] ?? '');
            break;

        /* ---------- 开始练习（10 题）/ 单元总测（20 题） ---------- */
        case 'start':
        case 'starttest':
            $uid = (string)($data['u'] ?? '');
            if (unit_meta($uid) === null) { $notice = '单元不存在。'; break; }
            if (unit_size($uid) === 0) { $notice = '该单元题库尚未载入。'; break; }
            // 单元总测（starttest）= 抽 20 题；普通练习 = 10 题
            $want = ($action === 'starttest') ? 20 : 10;
            // 把「已首次做对」的题号传进去，优先抽没做过的，避免重复
            $done = unit_done_qids($ipkey, $uid);
            $qids = draw_questions($uid, $want, $done);
            $token = create_session($ipkey, $uid, $qids, ($action === 'starttest') ? 1 : 0);
            $res->token = $token;
            $session = load_session($token);
            $notice = '';
            break;

        /* ---------- 统一提交 10 题 ---------- *
         * 客户端格式：a=submit, c0..c9=选项, m0..m9=该题耗时(ms)
         */
        case 'submit':
            if (!$session) { $notice = '没有进行中的练习。'; break; }
            if ((int)$session['done'] === 1) { $notice = '本次练习已提交。'; break; }

            $uid  = (string)$session['unit_id'];
            // 跨单元会话（每日一练/错题重练）用 [[unit,qid],...] 的形式
            $pairs = session_pairs($session);
            $qids  = array_map(fn($p) => (int)$p[1], $pairs);

            // 收集客户端提交的答案与耗时
            $answers = [];
            foreach ($qids as $i => $qid) {
                $cRaw = $data['c' . $i] ?? '-1';
                $mRaw = $data['m' . $i] ?? '0';
                $c = (int)$cRaw;
                $m = (int)$mRaw;
                if ($c < 0 || $c > 3) $c = -1;
                // 耗时合理性：0 ~ 30 分钟，超出就按上限记，避免伪造
                if ($m < 0) $m = 0;
                if ($m > 1800000) $m = 1800000;
                $answers[$i] = ['c' => $c, 'ms' => $m];
            }

            // 取该单元的题，交给评分函数。
            // 注意：必须用【打乱后】的版本，因为客户端看到的就是打乱后的选项，
            // 提交上来的下标也是基于打乱后的顺序。用会话令牌做种子，
            // 保证和渲染时用的是同一套顺序。
            // 注意：跨单元会话里同一个 qid 可能出现在不同单元，
            // 所以 bank 用 "unit:qid" 做键，不能只用 qid。
            $seed = (string)$session['token'];
            $bank = [];
            $mixed = !empty($session['mixed']);
            foreach ($pairs as $p) {
                $pu = (string)$p[0];
                $pq = (int)$p[1];
                $q = shuffled_question($pu, $pq, $seed);
                if ($q === null) continue;
                $bank[$mixed ? ($pu . ':' . $pq) : $pq] = $q;
            }

            // 提交前先拍一张榜单快照，用于结算页展示"这次涨了哪些值"
            $beforeRank = user_rank($ipkey);
            $beforeRows = leaderboard_rows(false);
            $beforeMe   = null;
            foreach ($beforeRows as $r0) {
                if ($r0['ipkey'] === $ipkey) { $beforeMe = $r0; break; }
            }

            // 跨单元会话：bank 键是 "unit:qid"，要把对应的键一并传进去
            $keys = [];
            foreach ($pairs as $p) {
                $keys[] = $mixed ? ((string)$p[0] . ':' . (int)$p[1]) : (int)$p[1];
            }
            $result = score_answers($qids, $answers, $bank, $keys);

            // 记录首次做对；同时维护错题本
            //   答错 → 记进错题本（下次可以专门重练）
            //   答对 → 从错题本里移除（说明已经会了）
            $firstHits = 0;
            foreach ($result['detail'] as $d) {
                // 每题的实际单元：跨单元会话要看 pairs
                $du = $pairs[(int)$d['i']][0] ?? $uid;
                if (!empty($d['ok'])) {
                    if (mark_first_correct($ipkey, $du, (int)$d['qid'])) $firstHits++;
                    wrong_remove($ipkey, $du, (int)$d['qid']);
                } else {
                    wrong_add($ipkey, $du, (int)$d['qid'], (int)($d['chosen'] ?? -1));
                }
            }

            $elapsed = max(0, time() - (int)$session['started_at']) * 1000;

            $session['done']     = 1;
            $session['ended_at'] = time();
            $session['result']   = $result;
            $session['answers']  = $answers;
            $session['first_hits'] = $firstHits;
            save_session($session);

            // 跨单元会话在排行榜里用它的名字（每日一练/错题重练）
            $runUnit = !empty($session['mixed'])
                ? ('mixed:' . (string)($session['unit_name'] ?? '综合'))
                : $uid;
            record_run($ipkey, (string)$user['label'], $runUnit, $result, $firstHits, $elapsed);

            // 提交后再拍一张，算出变化量
            $afterRank = user_rank($ipkey);
            $afterRows = leaderboard_rows(false);
            $afterMe   = null;
            foreach ($afterRows as $r1) {
                if ($r1['ipkey'] === $ipkey) { $afterMe = $r1; break; }
            }
            $session['delta'] = [
                'rank_before' => $beforeRank,
                'rank_after'  => $afterRank,
                'score_before'=> $beforeMe ? (int)$beforeMe['score']    : 0,
                'score_after' => $afterMe  ? (int)$afterMe['score']     : (int)$result['score'],
                'acc_before'  => $beforeMe ? $beforeMe['accuracy']      : null,
                'acc_after'   => $afterMe  ? $afterMe['accuracy']       : null,
                'spd_before'  => $beforeMe ? $beforeMe['avg_ms']        : null,
                'spd_after'   => $afterMe  ? $afterMe['avg_ms']         : (int)$result['avg_ms'],
                'online_after'=> $afterMe  ? (int)($afterMe['online_ms'] ?? 0) : 0,
                'first_hits'  => $firstHits,
            ];
            save_session($session);

            $notice = '已提交：答对 ' . $result['correct'] . '/' . $result['total']
                    . '，得分 ' . $result['score'];
            break;

        /* ---------- 纯页面切换 ---------- *
         * 这些 action 只决定渲染哪个视图，数据已经在 state 里备好了。
         */
        case 'wrong':
        case 'favs':
        case 'trend':
        case 'online':
        case 'stats':
            break;

        /* ---------- 导出数据 ---------- */
        case 'export':
            $fmt = (string)($data['fmt'] ?? 'csv');
            $res->download = [
                'name' => ($fmt === 'json' ? '我的练习数据.json' : '我的成绩.csv'),
                'type' => ($fmt === 'json' ? 'application/json; charset=utf-8' : 'text/csv; charset=utf-8'),
                'body' => ($fmt === 'json' ? export_json($ipkey) : export_csv($ipkey)),
            ];
            // 导出后停在成绩页
            $state_action = 'trend';
            break;

        /* ---------- 每日一练：抽今天该做的题并打卡 ---------- *
         * 优先从错题本里抽（针对性复习），不够再用普通抽题补。
         */
        case 'daily':
            $daily_checkin = daily_checkin($ipkey);   // 先打卡
            $d = daily_info($ipkey);

            // 错题优先
            $pool = [];
            foreach (wrong_list($ipkey, 40) as $w) $pool[] = [$w['unit_id'], $w['qid']];

            $picked = [];      // [unitId, qid]
            foreach ($pool as $p) {
                if (count($picked) >= 10) break;
                $picked[] = $p;
            }

            // 不够 10 题：从各学科随机补（优先没做对过的）
            if (count($picked) < 10) {
                $need = 10 - count($picked);
                $uidList = unit_ids();
                shuffle($uidList);
                foreach ($uidList as $u2) {
                    if ($need <= 0) break;
                    if (unit_size($u2) === 0) continue;
                    $done = unit_done_qids($ipkey, $u2);
                    $qids = draw_questions($u2, min($need, 10), $done);
                    foreach ($qids as $q2) {
                        $picked[] = [$u2, (int)$q2];
                        $need--;
                        if ($need <= 0) break;
                    }
                }
            }

            if (!$picked) { $notice = '暂时抽不出题目。'; break; }

            // 每日一练可能跨单元，所以按「单元:题号」记一个特殊会话
            $token = create_mixed_session($ipkey, $picked, '每日一练');
            $res->token = $token;
            $session = load_session($token);
            $notice = $daily_checkin ? ('打卡成功！连续 ' . $d['streak'] . ' 天') : '今天已经打过卡了。';
            break;

        /* ---------- 从错题本重练 ---------- */
        case 'wrongredo':
            $pool = [];
            foreach (wrong_list($ipkey, 20) as $w) $pool[] = [$w['unit_id'], $w['qid']];
            if (!$pool) { $notice = '错题本是空的，很厉害。'; break; }
            $token = create_mixed_session($ipkey, $pool, '错题重练');
            $res->token = $token;
            $session = load_session($token);
            $notice = '';
            break;

        /* ---------- 从收藏重练 ---------- */
        case 'favredo':
            $pool = [];
            foreach (fav_list($ipkey, 20) as $w) $pool[] = [$w['unit_id'], $w['qid']];
            if (!$pool) { $notice = '还没有收藏任何题目。'; break; }
            $token = create_mixed_session($ipkey, $pool, '收藏重练');
            $res->token = $token;
            $session = load_session($token);
            $notice = '';
            break;

        /* ---------- 收藏 / 取消收藏 ---------- */
        case 'fav':
            $fu = (string)($data['u'] ?? '');
            $fq = (int)($data['q'] ?? -1);
            if ($fu !== '' && $fq >= 0) {
                $on = fav_toggle($ipkey, $fu, $fq);
                $notice = $on ? '已收藏，可在「收藏」里重练。' : '已取消收藏。';
            }
            break;

        /* ---------- 排行榜 ---------- */
        case 'board':
            // u 现在是【科目代号】（phy/bio/mor/inter），空 = 总榜
            $b = (string)($data['u'] ?? '');
            $boardUnit = in_array($b, ['phy', 'bio', 'mor'], true) ? $b : '';
            break;

        /* ---------- 结束（放弃）本次练习 ---------- */
        case 'quit':
            if ($session && (int)$session['done'] === 0) {
                $session['done'] = 1;
                $session['ended_at'] = time();
                save_session($session);
                $notice = '已结束本次练习（未提交，不计成绩）。';
            }
            break;
    }

    // 注意：这些字段必须带上，否则页面渲染时拿不到（会退回默认值）
    $state = [
        'action'     => $action,
        'notice'     => $notice,
        'token'      => $token,
        'session'    => $session,
        'ipkey'      => $ipkey,
        'board_unit' => $boardUnit,
        'nick'       => (string)($user['nick'] ?? ''),
        'ip'         => (string)($user['ip'] ?? ''),
        'subject'    => (string)($user['subject'] ?? 'phy'),
        // 首次进入强制设置昵称：服务端判断有没有昵称
        'need_nick'  => trim((string)($user['nick'] ?? '')) === '',
        'site_name'  => SITE_NAME,
        'site_sub'   => SITE_SUB,

        // ---- 扩展功能的展示数据 ----
        'wrong_n'    => wrong_count($ipkey),
        'fav_n'      => fav_count($ipkey),
        'daily'      => daily_info($ipkey),
        'trend'      => trend_series($ipkey, 30),
        'trend_stat' => trend_stats($ipkey),
        'site_stat'  => site_stats(),
        'online_n'   => online_count(),
        'online'     => online_users(30),
        'wrong_list' => wrong_list($ipkey, 60),
        'fav_list'   => fav_list($ipkey, 60),
        'hot'        => hot_units(6),
    ];

    /* ---------- 聊天室 ---------- */
    if ($action === 'chat' || $action === 'chat_send') {

        if ($action === 'chat_send') {
            $r = chat_post($ipkey, (string)$user['label'], (string)($data['text'] ?? ''));
            $notice = (string)($r['notice'] ?? '');
        }


        $state['action']       = 'chat';
        $state['chat_msgs']    = chat_load();
    }

    $state['notice'] = $notice;

    return $state;
}
