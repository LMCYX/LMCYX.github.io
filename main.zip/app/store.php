<?php
/**
 * 存储层 · 零扩展版（纯文件 + 文件锁）
 *
 * 数据结构（都在 data/ 下，纯 JSON 文件）：
 *     users.json        用户与设置
 *     progress.json     首次做对记录   {ipkey: {"unit:qid": 时间}}
 *     sessions.json     进行中的练习会话（一次 10 题）
 *     runs.json         历次练习成绩（排行榜用）
 *
 * users.json 里每人记录：
 *     online_ms   累计在线时长（毫秒）
 *     last_tick   上次计入在线的时间戳（用于增量累加）
 *     created_at / seen_at
 *
 * 只依赖 PHP 内置能力：file_* / flock / json_* / random_bytes / hash
 */

declare(strict_types=1);

/* ------------------------------------------------------------------ *
 *  路径与基础设施
 * ------------------------------------------------------------------ */
function data_dir(): string
{
    static $dir = null;
    if ($dir !== null) return $dir;
    $dir = getenv('PHYS_DATA_DIR') ?: (__DIR__ . '/../data');
    if (!is_dir($dir)) @mkdir($dir, 0777, true);
    return $dir;
}

function data_file(string $name): string
{
    return data_dir() . '/' . $name . '.json';
}

/**
 * 读 JSON。带「请求内缓存」：同一文件在同一请求里只读盘+解码一次。
 * 大页面会重复读 users/runs/progress 十几次，这层缓存能省掉绝大部分 IO。
 */
function json_read(string $file): array
{
    static $cache = [];
    static $ver = -1;

    // 版本号变了就整体失效（写入后由 json_cache_flush 递增）
    $now = $GLOBALS['__json_cache_ver'] ?? 0;
    if ($now !== $ver) { $cache = []; $ver = $now; }

    if (array_key_exists($file, $cache)) return $cache[$file];

    if (!is_file($file)) { $cache[$file] = []; return []; }
    $raw = @file_get_contents($file);
    if ($raw === false || $raw === '') { $cache[$file] = []; return []; }
    $d = json_decode($raw, true);
    $cache[$file] = is_array($d) ? $d : [];
    return $cache[$file];
}

/** 让缓存失效（任何写入之后都要调用） */
function json_cache_flush(?string $file = null): void
{
    // 用静态函数内的引用技巧清空 json_read 的缓存
    static $noop = null;
    // PHP 没有直接暴露另一个函数的静态变量，这里用一个「版本号」间接实现
    $GLOBALS['__json_cache_ver'] = ($GLOBALS['__json_cache_ver'] ?? 0) + 1;
}

/**
 * 加锁读-改-写。$fn 收到当前数据，返回要写回的数据（返回 null 表示不写）。
 */
function with_lock(string $name, callable $fn)
{
    $file = data_file($name);
    $lock = $file . '.lock';

    $lf = @fopen($lock, 'c');
    if ($lf === false) {
        $cur = json_read($file);
        $new = $fn($cur);
        if ($new !== null) {
            @file_put_contents($file, json_encode($new, JSON_UNESCAPED_UNICODE), LOCK_EX);
            json_cache_flush();
        }
        return $new ?? $cur;
    }

    @flock($lf, LOCK_EX);
    try {
        $cur = json_read($file);
        $new = $fn($cur);
        if ($new !== null) {
            $tmp = $file . '.' . getmypid() . '.tmp';
            @file_put_contents($tmp, json_encode($new, JSON_UNESCAPED_UNICODE));
            @rename($tmp, $file);
            json_cache_flush();          // 写完立刻让读缓存失效
        }
        return $new ?? $cur;
    } finally {
        @flock($lf, LOCK_UN);
        @fclose($lf);
    }
}

/* ------------------------------------------------------------------ *
 *  用户（IP 登录）
 * ------------------------------------------------------------------ */
/**
 * 取得（或创建）当前 IP 对应的用户。
 *
 * 登录方式：IP + 昵称
 *   - IP 决定「你是谁」（同一 IP 就是同一个人，换 IP 就是新用户）
 *   - 昵称是显示名，用户可自己设置；没设置时默认显示 IP
 *
 * 返回数组里：
 *   ipkey  内部标识（IP 的哈希，用作存储键）
 *   ip     真实 IP（明文，用于展示）
 *   nick   用户设置的昵称（可能为空）
 *   label  最终显示名 = 昵称 ?: IP
 *   named  是否已设置昵称
 */
function ensure_user(string $ipkey, string $ip = ''): array
{
    $now  = time();
    $ipTx = $ip !== '' ? ip_label($ip) : ip_label_from_key($ipkey);
    $found = null;

    with_lock('users', function (array $users) use ($ipkey, $now, $ipTx, &$found) {
        if (isset($users[$ipkey])) {
            $found = $users[$ipkey];
            $users[$ipkey]['seen_at'] = $now;
            if (($users[$ipkey]['ip'] ?? '') !== $ipTx) {
                $users[$ipkey]['ip'] = $ipTx;
                $found['ip'] = $ipTx;
            }
        } else {
            $found = [
                'ipkey'      => $ipkey,
                'ip'         => $ipTx,
                'nick'       => '',
                'online_ms'  => 0,
                'last_tick'  => $now,
                'created_at' => $now,
                'seen_at'    => $now,
            ];
            $users[$ipkey] = $found;
        }

        /* ---- 累计在线时长 ----
           每次请求都把「距离上次计入」的间隔累加进去。
           间隔超过 ONLINE_GAP 秒（默认 120 秒）视为掉线/离开，
           只计入一个心跳间隔，避免"关掉网页一星期后再打开"
           把一整周都算成在线。 */
        $gap = $now - (int)($users[$ipkey]['last_tick'] ?? $now);
        if ($gap < 0) $gap = 0;
        if ($gap > ONLINE_GAP) $gap = ONLINE_GAP;
        $users[$ipkey]['online_ms'] = (int)($users[$ipkey]['online_ms'] ?? 0) + $gap * 1000;
        $users[$ipkey]['last_tick'] = $now;
        $found['online_ms'] = $users[$ipkey]['online_ms'];

        $users[$ipkey]['label'] = user_display_name($users[$ipkey]);
        $found['label'] = $users[$ipkey]['label'];
        return $users;
    });

    return $found;
}

/** 心跳间隔上限（秒）：两次请求相隔超过这个值，只按这个值计入在线 */
const ONLINE_GAP = 120;

/** 显示名 = 昵称（若有）否则 IP */
function user_display_name(array $u): string
{
    $nick = trim((string)($u['nick'] ?? ''));
    if ($nick !== '') return $nick;
    return (string)($u['ip'] ?? ip_label_from_key((string)($u['ipkey'] ?? '')));
}

/**
 * 设置昵称。返回 ['ok'=>bool,'notice'=>string]
 * 规则：1~16 个字符，不能是纯空白；同名允许（以 IP 区分身份）。
 */
function set_nickname(string $ipkey, string $nick): array
{
    $nick = trim($nick);
    // 去掉控制字符
    $nick = preg_replace('/[\x00-\x1F\x7F]/u', '', $nick) ?? '';
    $nick = trim($nick);

    if ($nick === '') {
        return ['ok' => false, 'notice' => '昵称不能为空。'];
    }
    // UTF-8 安全截断到 16 字符
    if (function_exists('utf8_cut')) {
        $nick = utf8_cut($nick, 16);
    } else {
        // 兜底：按字符数粗切（不依赖 mbstring）
        if (preg_match_all('/./us', $nick, $mm) && count($mm[0]) > 16) {
            $nick = implode('', array_slice($mm[0], 0, 16));
        }
    }

    with_lock('users', function (array $users) use ($ipkey, $nick) {
        if (!isset($users[$ipkey])) {
            $users[$ipkey] = ['ipkey' => $ipkey, 'ip' => ip_label_from_key($ipkey),
                              'nick' => '', 'online_ms' => 0, 'last_tick' => time(),
                              'created_at' => time(), 'seen_at' => time()];
        }
        $users[$ipkey]['nick']  = $nick;
        $users[$ipkey]['label'] = user_display_name($users[$ipkey]);
        return $users;
    });

    return ['ok' => true, 'notice' => '昵称已保存：' . $nick];
}

/** 仅在拿不到原始 IP 时兜底（正常情况下显示真实 IP） */
function ip_label_from_key(string $ipkey): string
{
    return 'IP-' . strtoupper(substr($ipkey, 0, 8));
}

/** 记录「首次做对」 */
function mark_first_correct(string $ipkey, string $unitId, int $qid): bool
{
    $isNew = false;
    with_lock('progress', function (array $p) use ($ipkey, $unitId, $qid, &$isNew) {
        $key = $unitId . ':' . $qid;
        if (!isset($p[$ipkey])) $p[$ipkey] = [];
        if (isset($p[$ipkey][$key])) return null;
        $p[$ipkey][$key] = time();
        $isNew = true;
        return $p;
    });
    return $isNew;
}

function unit_progress(string $ipkey, string $unitId): int
{
    $p = json_read(data_file('progress'));
    $n = 0;
    foreach (($p[$ipkey] ?? []) as $k => $_) {
        if (strpos((string)$k, $unitId . ':') === 0) $n++;
    }
    return $n;
}

/** 某用户在某单元【已首次做对】的题号列表 */
function unit_done_qids(string $ipkey, string $unitId): array
{
    $p = json_read(data_file('progress'));
    $out = [];
    $prefix = $unitId . ':';
    foreach (($p[$ipkey] ?? []) as $k => $_) {
        $k = (string)$k;
        if (strpos($k, $prefix) === 0) $out[] = (int)substr($k, strlen($prefix));
    }
    return $out;
}

function all_progress(string $ipkey): array
{
    $p = json_read(data_file('progress'));
    $out = [];
    foreach (($p[$ipkey] ?? []) as $k => $_) {
        $u = explode(':', (string)$k)[0];
        $out[$u] = ($out[$u] ?? 0) + 1;
    }
    return $out;
}

/* ------------------------------------------------------------------ *
 *  练习会话
 *
 *  一次练习 = 10 道题，一次性下发给客户端，全部做完再统一提交。
 *  服务端记录每题的作答耗时（客户端上报毫秒数，服务端做合理范围校验）。
 * ------------------------------------------------------------------ */
function create_session(string $ipkey, string $unitId, array $qids, int $isTest = 0): string
{
    $token = bin2hex(random_bytes(16));
    with_lock('sessions', function (array $s) use ($token, $ipkey, $unitId, $qids, $isTest) {
        $s[$token] = [
            'token'      => $token,
            'ipkey'      => $ipkey,
            'unit_id'    => $unitId,
            'qids'       => implode(',', $qids),
            'is_test'    => $isTest,
            'answers'    => [],       // 每题: ['c'=>选项, 'ms'=>耗时毫秒]
            'done'       => 0,
            'started_at' => time(),
            'ended_at'   => null,
            'result'     => null,     // 提交后的结算结果
        ];
        return $s;
    });
    return $token;
}

/**
 * 创建「跨单元」会话（每日一练 / 错题重练 / 收藏重练）。
 *
 * 普通会话只有一个 unit_id，题号是纯数字；
 * 这里的题目可能来自不同单元，所以把题号存成 "unitId:qid" 列表，
 * 并额外存一个 mixed=1 标记，渲染/判分时走另一条分支。
 *
 * @param array $pairs [[unitId, qid], ...]
 */
function create_mixed_session(string $ipkey, array $pairs, string $label = ''): string
{
    $token = bin2hex(random_bytes(16));

    $list = [];
    foreach ($pairs as $p) {
        if (!is_array($p) || count($p) < 2) continue;
        $list[] = (string)$p[0] . ':' . (int)$p[1];
    }

    with_lock('sessions', function (array $s) use ($token, $ipkey, $list, $label) {
        $s[$token] = [
            'token'      => $token,
            'ipkey'      => $ipkey,
            'unit_id'    => '',              // 跨单元，没有单一 unit
            'unit_name'  => $label,
            'qids'       => implode(',', $list),   // 这里是 "unit:qid" 串
            'mixed'      => 1,
            'is_test'    => 0,
            'answers'    => [],
            'done'       => 0,
            'started_at' => time(),
            'ended_at'   => null,
            'result'     => null,
        ];
        return $s;
    });
    return $token;
}

/**
 * 把会话里的题号解析成 [[unitId, qid], ...]。
 * 普通会话（unit_id 有值）返回 [[unitId, qid], ...]；
 * 跨单元会话直接解析 "unit:qid"。
 */
function session_pairs(array $session): array
{
    $out = [];
    $raw = (string)($session['qids'] ?? '');
    if ($raw === '') return $out;

    if (!empty($session['mixed'])) {
        foreach (explode(',', $raw) as $item) {
            $item = trim($item);
            if ($item === '') continue;
            $pos = strrpos($item, ':');
            if ($pos === false) continue;
            $out[] = [substr($item, 0, $pos), (int)substr($item, $pos + 1)];
        }
        return $out;
    }

    $uid = (string)($session['unit_id'] ?? '');
    foreach (explode(',', $raw) as $q) {
        $q = trim($q);
        if ($q === '') continue;
        $out[] = [$uid, (int)$q];
    }
    return $out;
}

function load_session(string $token): ?array
{
    $s = json_read(data_file('sessions'));
    return $s[$token] ?? null;
}

function save_session(array $s): void
{
    with_lock('sessions', function (array $all) use ($s) {
        $all[$s['token']] = $s;
        return $all;
    });
}

/**
 * 结算并写入成绩榜。
 *
 * 评分规则（服务端计算，客户端改不了）：
 *   - 每答对一题：基础 1 分
 *   - 连对加成：第 N 连对额外 +N 分（即连对第 1 题 +0，第 2 题 +1，第 3 题 +2…）
 *   - 答错清零连对
 *   - 分数 = 所有得分之和
 */
/**
 * @param array $qids    题号列表（普通会话是纯数字，跨单元会话也传纯题号）
 * @param array $answers 每题 ['c'=>选项,'ms'=>耗时]
 * @param array $bank    题号 => 题目（打乱后）。跨单元会话传 "unit:qid" 做键时，
 *                       调用方要保证 $qids[$i] 能对上 —— 见下面的 $keys 参数说明。
 * @param array $keys    可选：与 $qids 一一对应的 bank 键。不传就用 $qids 本身。
 */
function score_answers(array $qids, array $answers, array $bank, array $keys = []): array
{
    $correct = 0;
    $score   = 0;
    $streak  = 0;
    $times   = [];      // 只统计答对的题
    $detail  = [];

    foreach ($qids as $i => $qid) {
        $a = $answers[$i] ?? null;
        // 跨单元会话里 bank 的键是 "unit:qid"，所以允许调用方另给一份键
        $bk = $keys[$i] ?? $qid;
        $q  = $bank[$bk] ?? ($bank[$qid] ?? null);
        if ($q === null) continue;

        $choice = $a !== null ? (int)($a['c'] ?? -1) : -1;
        $ms     = $a !== null ? (int)($a['ms'] ?? 0) : 0;

        $ok = ($choice === (int)$q['ans']);
        $gain = 0;

        if ($ok) {
            $correct++;
            $streak++;
            // 连对加成：第 2 连对 +1，第 3 连对 +2 …（第 1 题无加成）
            $bonus = $streak - 1;
            $gain = 1 + $bonus;
            $score += $gain;
            if ($ms > 0) $times[] = $ms;
        } else {
            $streak = 0;
        }

        $detail[] = [
            'i'      => $i,            // 下标（错题本要按它找回单元）
            'qid'    => (int)$qid,
            'choice' => $choice,
            'chosen' => $choice,       // 语义化别名
            'ok'     => $ok,
            'gain'   => $gain,
            'ms'     => $ms,
        ];
    }

    $avgMs = count($times) > 0 ? (int)round(array_sum($times) / count($times)) : 0;

    return [
        'correct' => $correct,
        'total'   => count($qids),
        'score'   => $score,
        'avg_ms'  => $avgMs,
        'detail'  => $detail,
    ];
}

/**
 * 写入成绩榜。
 *
 * runs.json 里每条记录：
 *   ipkey, label, unit_id, correct, total, score, avg_ms, first_hits, at
 *
 * 排行榜取每个用户的【最好一次】成绩参与排序。
 */
function record_run(string $ipkey, string $label, string $unitId, array $r, int $firstHits, int $elapsedMs): void
{
    with_lock('runs', function (array $runs) use ($ipkey, $label, $unitId, $r, $firstHits, $elapsedMs) {
        $runs[] = [
            'ipkey'      => $ipkey,
            'label'      => $label,
            'unit_id'    => $unitId,
            'correct'    => (int)$r['correct'],
            'total'      => (int)$r['total'],
            'score'      => (int)$r['score'],
            'avg_ms'     => (int)$r['avg_ms'],
            'first_hits' => $firstHits,
            'ms'         => $elapsedMs,
            'at'         => time(),
        ];
        if (count($runs) > 8000) $runs = array_slice($runs, -8000);
        return $runs;
    });
}

function now_ts(): int { return time(); }
