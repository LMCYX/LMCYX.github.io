<?php
/**
 * 网页聊天室 · 零扩展版（纯文件 + 文件锁）
 *
 * 数据（都在 data/ 下）：
 *     chat.json        消息列表，数组，按时间从旧到新
 *                      [{"id":1,"ipkey":"abc","label":"用户-ABC123","text":"你好","at":1789990000}]
 *     chat_rate.json   每个 IP 的最后发送时间 {ipkey: 时间戳}
 *
 * 全部写入都走 store.php 的 with_lock()，用 flock 排他锁保护，
 * 读-改-写一次原子完成；读操作直接 json_read()。
 *
 * 安全：消息文本一律「先截断、再交给 views.php 的 e() 转义」输出，
 * 这里只负责清洗与长度控制，不产出任何 HTML。
 */

declare(strict_types=1);

/* ------------------------------------------------------------------ *
 *  容量与频率限制参数
 * ------------------------------------------------------------------ */
// 消息不再设上限（按需求：聊天室存储无限条消息）。
// 只保留一个安全阀：文件异常膨胀时才做保护性截断，
// 正常使用永远不会触发。
const CHAT_HARD_LIMIT = 200000;
const CHAT_TEXT_MAX = 500;   // 单条消息最长多少个字符
const CHAT_GAP_SEC  = 1;     // 同一 IP 两次发送的最小间隔（秒）

/* ------------------------------------------------------------------ *
 *  UTF-8 安全截断（不依赖 mbstring）
 *
 *  思路：先按「字符」走一遍，数到第 $max 个字符时就地切开。
 *  一个字符的首字节决定了它占几个字节（与 mb_substr 同规则）：
 *      0xxxxxxx            → 1 字节（ASCII）
 *      110xxxxx 10xxxxxx   → 2 字节
 *      1110xxxx 10xxxxxx…  → 3 字节（汉字在这里）
 *      11110xxx …          → 4 字节（emoji 等）
 *  这样既不切开多字节字符，也不会把半个汉字留在末尾。
 *  遇到非法字节按 1 字节跳过，保证函数总能返回合法结果。
 * ------------------------------------------------------------------ */
function utf8_cut(string $s, int $max): string
{
    if ($max <= 0) return '';
    if (function_exists('mb_substr')) return mb_substr($s, 0, $max, 'UTF-8');   // 有 mbstring 就用，行为一致

    $len = strlen($s);
    $o = 0;      // 字节游标
    $n = 0;      // 已数过的字符数
    while ($o < $len && $n < $max) {
        $b = ord($s[$o]);
        if ($b < 0x80)             $step = 1;
        elseif (($b & 0xE0) === 0xC0) $step = 2;
        elseif (($b & 0xF0) === 0xE0) $step = 3;
        elseif (($b & 0xF8) === 0xF0) $step = 4;
        else                          $step = 1;   // 非法首字节，当单字节跳过
        if ($o + $step > $len) break;              // 末尾不完整，直接停
        $o += $step;
        $n++;
    }
    return substr($s, 0, $o);
}

/* ------------------------------------------------------------------ *
 *  读取
 * ------------------------------------------------------------------ */
/** 读全部消息（最多 CHAT_HARD_LIMIT 条） */
function chat_load(): array
{
    $list = json_read(data_file('chat'));
    if (count($list) > CHAT_HARD_LIMIT) $list = array_slice($list, -CHAT_HARD_LIMIT);
    return array_values($list);
}

/* ------------------------------------------------------------------ *
 *  频率限制
 *  同一 IP 每秒最多 1 条：只记「最后发送时间」，
 *  与当前时间差小于 CHAT_GAP_SEC 就拒绝。
 * ------------------------------------------------------------------ */
function chat_rate_ok(string $ipkey): bool
{
    $rate = json_read(data_file('chat_rate'));
    $last = (int)($rate[$ipkey] ?? 0);
    return (time() - $last) >= CHAT_GAP_SEC;
}

/** 记录本次发送时间（只在真正落库后调用） */
function chat_rate_touch(string $ipkey, int $at): void
{
    with_lock('chat_rate', function (array $rate) use ($ipkey, $at) {
        $rate[$ipkey] = $at;
        // 顺手清掉 1 小时没说话的记录，避免文件无限增长
        if (count($rate) > 2000) {
            $keep = [];
            foreach ($rate as $k => $t) {
                if ($at - (int)$t < 3600) $keep[$k] = $t;
            }
            $rate = $keep;
        }
        return $rate;
    });
}

/* ------------------------------------------------------------------ *
 *  发送
 *  返回 ['ok'=>bool, 'notice'=>string]
 * ------------------------------------------------------------------ */
function chat_post(string $ipkey, string $label, string $text): array
{
    // 1) 清洗：去掉首尾空白与不可见字符，空消息直接拒绝
    $text = trim($text);
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text) ?? '';
    $text = trim($text);
    if ($text === '') {
        return ['ok' => false, 'notice' => '消息不能为空。'];
    }

    // 2) UTF-8 安全截断到 500 字符（超长不报错，截断即可）
    $text = utf8_cut($text, CHAT_TEXT_MAX);
    if ($text === '') {
        return ['ok' => false, 'notice' => '消息内容无效，请重新输入。'];
    }

    // 3) 频率限制：同一 IP 每秒最多 1 条
    if (!chat_rate_ok($ipkey)) {
        return ['ok' => false, 'notice' => '发送太快了，同一用户每秒最多 1 条，请稍候再发。'];
    }

    // 4) 加锁写入：自增 id + 只保留最近 CHAT_HARD_LIMIT 条
    $at = time();
    $msg = null;
    with_lock('chat', function (array $list) use ($ipkey, $label, $text, $at, &$msg) {
        $maxId = 0;
        foreach ($list as $m) {
            $id = (int)($m['id'] ?? 0);
            if ($id > $maxId) $maxId = $id;
        }
        $msg = [
            'id'    => $maxId + 1,
            'ipkey' => $ipkey,
            'label' => $label,
            'text'  => $text,
            'at'    => $at,
        ];
        $list[] = $msg;
        // 超出上限时丢弃最旧的
        if (count($list) > CHAT_HARD_LIMIT) $list = array_slice($list, -CHAT_HARD_LIMIT);
        return $list;
    });

    chat_rate_touch($ipkey, $at);

    return ['ok' => true, 'notice' => '已发送。'];
}

/** 时间戳 → 展示用短时间（依托 date()，PHP 内置，不依赖 intl） */
function chat_time_text(int $at): string
{
    if ($at <= 0) return '—';
    $today = date('Y-m-d', $at) === date('Y-m-d');
    return $today ? date('H:i', $at) : date('m-d H:i', $at);
}

/* ------------------------------------------------------------------ *
 *  聊天室发文件（需求：聊天室可以发网盘文件）
 * ------------------------------------------------------------------ *
 *  两种方式：
 *    1) 上传新文件并发送 —— 先存进云盘，再发一条带 file 字段的消息
 *    2) 发送已有文件   —— 从云盘挑一个已上传的文件分享出去
 *
 *  消息结构里多两个可选字段：
 *    'file' => ['id'=>云盘文件id, 'name'=>文件名, 'size'=>字节数]
 *  文本消息不带 file 字段（保持向后兼容）。
 * ------------------------------------------------------------------ */

/**
 * 发送一条「文件消息」。
 *
 * @param string $ipkey     发送者
 * @param string $label     发送者显示名（IP）
 * @param array  $file      云盘文件信息 ['id','name','size']
 * @param string $caption   附带文字（可为空）
 */
function chat_post_file(string $ipkey, string $label, array $file, string $caption = ''): array
{
    $id   = (string)($file['id'] ?? '');
    $name = (string)($file['name'] ?? '');
    $size = (int)($file['size'] ?? 0);

    if ($id === '' || $name === '') {
        return ['ok' => false, 'notice' => '文件信息不完整。'];
    }

    // 附言：走和文本消息一样的清洗与截断
    $caption = trim($caption);
    $caption = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $caption) ?? '';
    $caption = utf8_cut(trim($caption), CHAT_TEXT_MAX);

    // 频率限制与文本消息共用（避免用文件刷屏）
    if (!chat_rate_ok($ipkey)) {
        return ['ok' => false, 'notice' => '发送太快了，同一用户每秒最多 1 条，请稍候再发。'];
    }

    $at  = time();
    $msg = null;
    with_lock('chat', function (array $list) use ($ipkey, $label, $id, $name, $size, $caption, $at, &$msg) {
        $maxId = 0;
        foreach ($list as $m) {
            $mid = (int)($m['id'] ?? 0);
            if ($mid > $maxId) $maxId = $mid;
        }
        $msg = [
            'id'    => $maxId + 1,
            'ipkey' => $ipkey,
            'label' => $label,
            'text'  => $caption,
            'file'  => ['id' => $id, 'name' => $name, 'size' => $size],
            'at'    => $at,
        ];
        $list[] = $msg;
        if (count($list) > CHAT_HARD_LIMIT) $list = array_slice($list, -CHAT_HARD_LIMIT);
        return $list;
    });

    chat_rate_touch($ipkey, $at);

    return ['ok' => true, 'notice' => '文件已发送。'];
}

/** 人类可读体积（聊天室显示用；cloud.php 里也有一份，这里独立避免依赖） */
function chat_size_text(int $bytes): string
{
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1024 * 1024) return round($bytes / 1024, 1) . ' KB';
    if ($bytes < 1024 * 1024 * 1024) return round($bytes / 1048576, 1) . ' MB';
    return round($bytes / 1073741824, 2) . ' GB';
}
