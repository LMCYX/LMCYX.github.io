<?php
/**
 * 扩展功能集合。
 *
 * 这里放的都是"不改变主流程"的附加能力，每个功能一块，互不依赖：
 *
 *   1. 错题本        —— 自动收集做错的题，可一键重练
 *   2. 每日一练/签到  —— 连续打卡天数、今日是否已练
 *   3. 成绩趋势      —— 每次成绩的折线图（数据在这里，画图在 JS）
 *   4. 收藏          —— 把题目加进"待复习"
 *   5. 全站统计      —— 总题数、总作答、最活跃用户
 *   6. 在线状态      —— 谁在线上、最近在干什么
 *   7. 数据导出      —— 把自己的成绩导成 CSV
 *
 * 设计原则：全部基于已有的 JSON 文件存储 + flock，
 * 不引入任何数据库、不依赖任何 PHP 扩展。
 */

declare(strict_types=1);

/* ================================================================== *
 *  1. 错题本
 * ================================================================== *
 *  存在 data/wrong.json，结构：
 *    { "<ipkey>": { "<unitId>:<qid>": {"n": 错次数, "t": 最后时间, "c": 最后选错项} } }
 *  答对一次就从错题本里移除（说明已经会了）。
 */

function wrong_file(): string { return data_file('wrong'); }

/** 记录一道错题 */
function wrong_add(string $ipkey, string $unitId, int $qid, int $chosen): void
{
    $k = $unitId . ':' . $qid;
    with_lock('wrong', function (array $all) use ($ipkey, $k, $chosen) {
        if (!isset($all[$ipkey])) $all[$ipkey] = [];
        $cur = $all[$ipkey][$k] ?? ['n' => 0];
        $all[$ipkey][$k] = [
            'n' => (int)($cur['n'] ?? 0) + 1,
            't' => time(),
            'c' => $chosen,
        ];
        // 每个人的错题最多留 300 条，防止文件无限长
        if (count($all[$ipkey]) > 300) {
            uasort($all[$ipkey], fn($a, $b) => ((int)($b['t'] ?? 0)) <=> ((int)($a['t'] ?? 0)));
            $all[$ipkey] = array_slice($all[$ipkey], 0, 300, true);
        }
        return $all;
    });
}

/** 答对了就从错题本移除 */
function wrong_remove(string $ipkey, string $unitId, int $qid): void
{
    $k = $unitId . ':' . $qid;
    with_lock('wrong', function (array $all) use ($ipkey, $k) {
        if (isset($all[$ipkey][$k])) unset($all[$ipkey][$k]);
        return $all;
    });
}

/** 取某人的错题列表（按错误次数从多到少） */
function wrong_list(string $ipkey, int $limit = 200): array
{
    $all = json_read(wrong_file());
    $mine = $all[$ipkey] ?? [];
    if (!is_array($mine)) return [];

    $rows = [];
    foreach ($mine as $k => $v) {
        $pos = strrpos((string)$k, ':');
        if ($pos === false) continue;
        $uid = substr((string)$k, 0, $pos);
        $qid = (int)substr((string)$k, $pos + 1);
        $meta = unit_meta($uid);
        if ($meta === null) continue;          // 单元被删了就跳过
        $q = get_question($uid, $qid);
        if ($q === null) continue;
        $rows[] = [
            'unit_id'   => $uid,
            'unit_name' => (string)($meta['name'] ?? $uid),
            'subject'   => subject_of($uid),
            'qid'       => $qid,
            'q'         => (string)$q['q'],
            'n'         => (int)($v['n'] ?? 1),
            't'         => (int)($v['t'] ?? 0),
        ];
    }
    usort($rows, function ($a, $b) {
        if ($a['n'] !== $b['n']) return $b['n'] <=> $a['n'];
        return $b['t'] <=> $a['t'];
    });
    return array_slice($rows, 0, $limit);
}

function wrong_count(string $ipkey): int
{
    $all = json_read(wrong_file());
    return isset($all[$ipkey]) && is_array($all[$ipkey]) ? count($all[$ipkey]) : 0;
}

/* ================================================================== *
 *  2. 每日一练 / 签到
 * ================================================================== *
 *  存在 users.json 里的 daily 字段（跟用户走，不用额外文件）：
 *    daily: { "last": "2026-09-28", "streak": 5, "best": 9, "total": 31 }
 */

/** 今天的日期串（服务器本地时区） */
function today_str(): string { return date('Y-m-d'); }

/** 两个日期相差几天 */
function days_between(string $a, string $b): int
{
    $ta = strtotime($a . ' 00:00:00');
    $tb = strtotime($b . ' 00:00:00');
    if ($ta === false || $tb === false) return 9999;
    return (int)round(($tb - $ta) / 86400);
}

/**
 * 打卡。返回是否"今天第一次"。
 * 连续规则：昨天打过 → streak+1；否则从 1 重新开始。
 */
function daily_checkin(string $ipkey): bool
{
    $today = today_str();
    $first = false;

    with_lock('users', function (array $users) use ($ipkey, $today, &$first) {
        if (!isset($users[$ipkey])) return $users;
        $d = $users[$ipkey]['daily'] ?? ['last' => '', 'streak' => 0, 'best' => 0, 'total' => 0];

        if (($d['last'] ?? '') === $today) return $users;   // 今天已经打过

        $first = true;
        $gap = days_between((string)($d['last'] ?? ''), $today);
        $streak = ($gap === 1) ? ((int)($d['streak'] ?? 0) + 1) : 1;

        $users[$ipkey]['daily'] = [
            'last'   => $today,
            'streak' => $streak,
            'best'   => max((int)($d['best'] ?? 0), $streak),
            'total'  => (int)($d['total'] ?? 0) + 1,
        ];
        return $users;
    });

    return $first;
}

/** 取某人的签到数据（顺带算出"今天是否已打"） */
function daily_info(string $ipkey): array
{
    $users = json_read(data_file('users'));
    $d = $users[$ipkey]['daily'] ?? [];
    $last = (string)($d['last'] ?? '');
    $today = today_str();

    // 断签了：显示时的连续天数要归零，但历史 best 保留
    $alive = ($last === $today) || (days_between($last, $today) === 1);

    return [
        'last'     => $last,
        'streak'   => $alive ? (int)($d['streak'] ?? 0) : 0,
        'best'     => (int)($d['best'] ?? 0),
        'total'    => (int)($d['total'] ?? 0),
        'today'    => ($last === $today),
        'alive'    => $alive,
    ];
}

/* ================================================================== *
 *  3. 成绩趋势（数据）
 * ================================================================== */

/** 取最近 N 次成绩，按时间正序（给折线图用） */
function trend_series(string $ipkey, int $limit = 30): array
{
    $runs = json_read(data_file('runs'));
    $mine = [];
    foreach ($runs as $r) {
        if ((string)($r['ipkey'] ?? '') !== $ipkey) continue;
        $mine[] = [
            't'       => (int)($r['at'] ?? 0),
            'score'   => (int)($r['score'] ?? 0),
            'correct' => (int)($r['correct'] ?? 0),
            'total'   => (int)($r['total'] ?? 0),
            'unit'    => (string)($r['unit_id'] ?? ''),
        ];
    }
    usort($mine, fn($a, $b) => $a['t'] <=> $b['t']);
    return array_slice($mine, -$limit);
}

/** 汇总：次数、总分、最高分、平均正确率 */
function trend_stats(string $ipkey): array
{
    $runs = json_read(data_file('runs'));
    $n = 0; $sum = 0; $best = 0; $cSum = 0; $tSum = 0;
    foreach ($runs as $r) {
        if ((string)($r['ipkey'] ?? '') !== $ipkey) continue;
        $n++;
        $sum += (int)($r['score'] ?? 0);
        $best = max($best, (int)($r['score'] ?? 0));
        $cSum += (int)($r['correct'] ?? 0);
        $tSum += (int)($r['total'] ?? 0);
    }
    return [
        'runs'    => $n,
        'total'   => $sum,
        'best'    => $best,
        'avg'     => $n > 0 ? (int)round($sum / $n) : 0,
        'acc'     => $tSum > 0 ? (int)round($cSum / $tSum * 100) : 0,
    ];
}

/* ================================================================== *
 *  4. 收藏（待复习）
 * ================================================================== *
 *  存在 data/favs.json： { "<ipkey>": ["<unitId>:<qid>", ...] }
 */

function fav_file(): string { return data_file('favs'); }

function fav_toggle(string $ipkey, string $unitId, int $qid): bool
{
    $k = $unitId . ':' . $qid;
    $now = false;
    with_lock('favs', function (array $all) use ($ipkey, $k, &$now) {
        if (!isset($all[$ipkey]) || !is_array($all[$ipkey])) $all[$ipkey] = [];
        $i = array_search($k, $all[$ipkey], true);
        if ($i === false) { $all[$ipkey][] = $k; $now = true; }
        else { array_splice($all[$ipkey], $i, 1); $now = false; }
        return $all;
    });
    return $now;
}

function fav_keys(string $ipkey): array
{
    $all = json_read(fav_file());
    $m = $all[$ipkey] ?? [];
    return is_array($m) ? array_values($m) : [];
}

function fav_has(string $ipkey, string $unitId, int $qid): bool
{
    return in_array($unitId . ':' . $qid, fav_keys($ipkey), true);
}

function fav_count(string $ipkey): int { return count(fav_keys($ipkey)); }

/** 收藏的题（带题干，和错题本一个格式） */
function fav_list(string $ipkey, int $limit = 200): array
{
    $rows = [];
    foreach (fav_keys($ipkey) as $k) {
        $pos = strrpos($k, ':');
        if ($pos === false) continue;
        $uid = substr($k, 0, $pos);
        $qid = (int)substr($k, $pos + 1);
        $meta = unit_meta($uid);
        if ($meta === null) continue;
        $q = get_question($uid, $qid);
        if ($q === null) continue;
        $rows[] = [
            'unit_id'   => $uid,
            'unit_name' => (string)($meta['name'] ?? $uid),
            'subject'   => subject_of($uid),
            'qid'       => $qid,
            'q'         => (string)$q['q'],
        ];
    }
    return array_slice($rows, 0, $limit);
}

/* ================================================================== *
 *  5. 全站统计
 * ================================================================== */

function site_stats(): array
{
    $users = json_read(data_file('users'));
    $runs  = json_read(data_file('runs'));
    $prog  = json_read(data_file('progress'));
    $chat  = json_read(data_file('chat'));

    // 题库总量
    $qTotal = 0; $units = 0;
    foreach (unit_ids() as $uid) {
        $n = unit_size($uid);
        if ($n > 0) { $qTotal += $n; $units++; }
    }

    // 总作答次数 / 总答对
    $answers = 0; $correct = 0;
    foreach ($runs as $r) { $answers += (int)($r['total'] ?? 0); $correct += (int)($r['correct'] ?? 0); }

    // 最活跃：按 runs 数量
    $byUser = [];
    foreach ($runs as $r) {
        $k = (string)($r['ipkey'] ?? '');
        if ($k === '') continue;
        if (!isset($byUser[$k])) $byUser[$k] = ['n' => 0, 'score' => 0];
        $byUser[$k]['n']++;
        $byUser[$k]['score'] += (int)($r['score'] ?? 0);
    }
    $topActor = null;
    foreach ($byUser as $k => $v) {
        if ($topActor === null || $v['n'] > $topActor['n']) {
            $topActor = ['ipkey' => $k, 'n' => $v['n'], 'score' => $v['score']];
        }
    }
    if ($topActor !== null) {
        $u = $users[$topActor['ipkey']] ?? [];
        $topActor['name'] = trim((string)($u['nick'] ?? '')) !== ''
            ? (string)$u['nick']
            : (string)($u['ip'] ?? ip_label_from_key($topActor['ipkey']));
    }

    // 被做对过的题（去重）
    $doneSet = [];
    foreach ($prog as $ipk => $unitsOf) {
        if (!is_array($unitsOf)) continue;
        foreach ($unitsOf as $uid => $qids) {
            if (!is_array($qids)) continue;
            foreach ($qids as $qid => $_) $doneSet[$uid . ':' . $qid] = true;
        }
    }

    return [
        'users'      => count($users),
        'units'      => $units,
        'questions'  => $qTotal,
        'runs'       => count($runs),
        'answers'    => $answers,
        'correct'    => $correct,
        'accuracy'   => $answers > 0 ? (int)round($correct / $answers * 100) : 0,
        'chats'      => is_array($chat) ? count($chat) : 0,
        'covered'    => count($doneSet),
        'coverage'   => $qTotal > 0 ? (int)round(count($doneSet) / $qTotal * 100) : 0,
        'top'        => $topActor,
    ];
}

/* ================================================================== *
 *  6. 在线状态
 * ================================================================== *
 *  没有额外的"心跳文件"：users.json 里每次请求都会更新 seen_at，
 *  所以直接按 seen_at 判断谁在线。
 */

const ONLINE_WINDOW = 120;   // 秒：2 分钟内有过请求就算在线

function online_users(int $limit = 30): array
{
    $users = json_read(data_file('users'));
    $now = time();
    $rows = [];
    foreach ($users as $k => $u) {
        $seen = (int)($u['seen_at'] ?? 0);
        if ($seen <= 0) continue;
        $rows[] = [
            'ipkey'  => (string)$k,
            'name'   => user_display_name($u),
            'ip'     => (string)($u['ip'] ?? ''),
            'seen'   => $seen,
            'ago'    => max(0, $now - $seen),
            'online' => ($now - $seen) <= ONLINE_WINDOW,
            'online_ms' => (int)($u['online_ms'] ?? 0),
        ];
    }
    usort($rows, fn($a, $b) => $b['seen'] <=> $a['seen']);

    // 在线的排前面
    $on  = array_values(array_filter($rows, fn($r) => $r['online']));
    $off = array_values(array_filter($rows, fn($r) => !$r['online']));
    return array_slice(array_merge($on, $off), 0, $limit);
}

function online_count(): int
{
    $users = json_read(data_file('users'));
    $now = time(); $n = 0;
    foreach ($users as $u) {
        if (($now - (int)($u['seen_at'] ?? 0)) <= ONLINE_WINDOW) $n++;
    }
    return $n;
}

/** 最热门的单元：按被练习次数排序 */
function hot_units(int $limit = 6): array
{
    $runs = json_read(data_file('runs'));
    $cnt = [];
    foreach ($runs as $r) {
        $u = (string)($r['unit_id'] ?? '');
        if ($u === '') continue;
        $cnt[$u] = ($cnt[$u] ?? 0) + 1;
    }
    arsort($cnt);
    $out = [];
    foreach (array_slice($cnt, 0, $limit, true) as $uid => $n) {
        $meta = unit_meta((string)$uid);
        if ($meta === null) continue;
        $out[] = [
            'unit_id' => (string)$uid,
            'name'    => (string)($meta['name'] ?? $uid),
            'subject' => subject_of((string)$uid),
            'runs'    => $n,
        ];
    }
    return $out;
}

/* ================================================================== *
 *  7. 数据导出
 * ================================================================== */

/** 把某人的成绩导成 CSV 文本 */
function export_csv(string $ipkey): string
{
    $runs = json_read(data_file('runs'));
    $mine = [];
    foreach ($runs as $r) {
        if ((string)($r['ipkey'] ?? '') !== $ipkey) continue;
        $mine[] = $r;
    }
    usort($mine, fn($a, $b) => ((int)($a['at'] ?? 0)) <=> ((int)($b['at'] ?? 0)));

    // 加 BOM，Excel 打开中文不乱码
    $out = "\xEF\xBB\xBF";
    $out .= "时间,单元,单元名,学科,得分,答对,总题数,正确率(%),平均每题耗时(ms),首次做对\n";

    foreach ($mine as $r) {
        $uid  = (string)($r['unit_id'] ?? '');
        $meta = unit_meta($uid);
        $total = (int)($r['total'] ?? 0);
        $corr  = (int)($r['correct'] ?? 0);
        $acc   = $total > 0 ? (int)round($corr / $total * 100) : 0;

        $out .= implode(',', [
            date('Y-m-d H:i:s', (int)($r['at'] ?? 0)),
            csv_cell($uid),
            csv_cell((string)($meta['name'] ?? $uid)),
            csv_cell(subject_name(subject_of($uid))),
            (int)($r['score'] ?? 0),
            $corr,
            $total,
            $acc,
            (int)($r['avg_ms'] ?? 0),
            (int)($r['first_hits'] ?? 0),
        ]) . "\n";
    }

    if (!$mine) $out .= "（还没有成绩记录）\n";
    return $out;
}

/** CSV 单元格转义：含逗号/引号/换行就加引号 */
function csv_cell(string $s): string
{
    if (preg_match('/[",\r\n]/', $s)) {
        return '"' . str_replace('"', '""', $s) . '"';
    }
    return $s;
}

/** 把某人的完整数据导成 JSON（备份用） */
function export_json(string $ipkey): string
{
    $users = json_read(data_file('users'));
    $u = $users[$ipkey] ?? [];
    unset($u['ipkey']);   // 不导出内部键

    $runs = [];
    foreach (json_read(data_file('runs')) as $r) {
        if ((string)($r['ipkey'] ?? '') === $ipkey) {
            unset($r['ipkey']);
            $runs[] = $r;
        }
    }

    $prog = json_read(data_file('progress'))[$ipkey] ?? [];
    $wrong = [];
    foreach (wrong_list($ipkey) as $w) {
        $wrong[] = ['unit' => $w['unit_id'], 'qid' => $w['qid'], 'times' => $w['n']];
    }

    return json_encode([
        'exported_at' => date('c'),
        'site'        => SITE_NAME,
        'user'        => $u,
        'daily'       => daily_info($ipkey),
        'stats'       => trend_stats($ipkey),
        'runs'        => $runs,
        'progress'    => $prog,
        'wrong'       => $wrong,
        'favorites'   => fav_keys($ipkey),
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}
